# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'sectionlist_export.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)
import tupc_bg_rc

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(714, 588)
        Dialog.setMinimumSize(QSize(714, 588))
        Dialog.setMaximumSize(QSize(972, 712))
        Dialog.setStyleSheet(u"#Dialog{\n"
"\n"
"	border-image: url(:/resources/tupc_bg.png);\n"
"}")
        self.gridLayout = QGridLayout(Dialog)
        self.gridLayout.setObjectName(u"gridLayout")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label_57 = QLabel(Dialog)
        self.label_57.setObjectName(u"label_57")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(True)
        self.label_57.setFont(font)
        self.label_57.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout.addWidget(self.label_57, 0, Qt.AlignHCenter)

        self.label_6 = QLabel(Dialog)
        self.label_6.setObjectName(u"label_6")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(12)
        font1.setBold(True)
        font1.setItalic(True)
        self.label_6.setFont(font1)
        self.label_6.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout.addWidget(self.label_6)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.chosen_section_line = QLineEdit(Dialog)
        self.chosen_section_line.setObjectName(u"chosen_section_line")
        self.chosen_section_line.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout.addWidget(self.chosen_section_line)

        self.choose_btn = QPushButton(Dialog)
        self.choose_btn.setObjectName(u"choose_btn")
        self.choose_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout.addWidget(self.choose_btn)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_5 = QLabel(Dialog)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font1)
        self.label_5.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_2.addWidget(self.label_5)

        self.user_id_line = QLineEdit(Dialog)
        self.user_id_line.setObjectName(u"user_id_line")
        self.user_id_line.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_2.addWidget(self.user_id_line)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_7 = QLabel(Dialog)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setFont(font1)
        self.label_7.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_3.addWidget(self.label_7)

        self.email_to_send_line = QLineEdit(Dialog)
        self.email_to_send_line.setObjectName(u"email_to_send_line")
        self.email_to_send_line.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_3.addWidget(self.email_to_send_line)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.send_btn_Excel = QPushButton(Dialog)
        self.send_btn_Excel.setObjectName(u"send_btn_Excel")
        self.send_btn_Excel.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_6.addWidget(self.send_btn_Excel, 0, Qt.AlignLeft)

        self.send_btn_PDF = QPushButton(Dialog)
        self.send_btn_PDF.setObjectName(u"send_btn_PDF")
        self.send_btn_PDF.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_6.addWidget(self.send_btn_PDF, 0, Qt.AlignRight)


        self.verticalLayout.addLayout(self.horizontalLayout_6)


        self.gridLayout.addLayout(self.verticalLayout, 0, 0, 1, 1)

        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.label_56 = QLabel(Dialog)
        self.label_56.setObjectName(u"label_56")
        self.label_56.setFont(font)
        self.label_56.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.label_56.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.label_56)

        self.section_list = QListWidget(Dialog)
        self.section_list.setObjectName(u"section_list")
        self.section_list.setMinimumSize(QSize(351, 400))
        self.section_list.setMaximumSize(QSize(16777215, 16777215))
        font2 = QFont()
        font2.setFamilies([u"Sitka Small"])
        font2.setBold(True)
        self.section_list.setFont(font2)
        self.section_list.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);\n"
"\n"
"QListWidget::item:selected {\n"
"    background-color: #0078d7; /* selection color */\n"
"    color: white;              /* text color on selection */\n"
"}\n"
"")

        self.verticalLayout_3.addWidget(self.section_list)


        self.gridLayout.addLayout(self.verticalLayout_3, 0, 1, 2, 1)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label_58 = QLabel(Dialog)
        self.label_58.setObjectName(u"label_58")
        self.label_58.setFont(font)
        self.label_58.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_2.addWidget(self.label_58, 0, Qt.AlignHCenter)

        self.label_8 = QLabel(Dialog)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font1)
        self.label_8.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_2.addWidget(self.label_8)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.chosen_section_download = QLineEdit(Dialog)
        self.chosen_section_download.setObjectName(u"chosen_section_download")
        self.chosen_section_download.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_4.addWidget(self.chosen_section_download)

        self.choose_btn_download = QPushButton(Dialog)
        self.choose_btn_download.setObjectName(u"choose_btn_download")
        self.choose_btn_download.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_4.addWidget(self.choose_btn_download)


        self.verticalLayout_2.addLayout(self.horizontalLayout_4)

        self.verticalSpacer_3 = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_2.addItem(self.verticalSpacer_3)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.download_btn_pdf = QPushButton(Dialog)
        self.download_btn_pdf.setObjectName(u"download_btn_pdf")
        self.download_btn_pdf.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_5.addWidget(self.download_btn_pdf, 0, Qt.AlignLeft)

        self.download_btn_excel = QPushButton(Dialog)
        self.download_btn_excel.setObjectName(u"download_btn_excel")
        self.download_btn_excel.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_5.addWidget(self.download_btn_excel, 0, Qt.AlignRight)


        self.verticalLayout_2.addLayout(self.horizontalLayout_5)

        self.verticalSpacer = QSpacerItem(20, 38, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_2.addItem(self.verticalSpacer)


        self.gridLayout.addLayout(self.verticalLayout_2, 1, 0, 1, 1)

#if QT_CONFIG(shortcut)
        self.label_6.setBuddy(self.chosen_section_line)
        self.label_5.setBuddy(self.user_id_line)
        self.label_7.setBuddy(self.email_to_send_line)
        self.label_8.setBuddy(self.chosen_section_download)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label_57.setText(QCoreApplication.translate("Dialog", u"Export Section", None))
        self.label_6.setText(QCoreApplication.translate("Dialog", u"Choose Section:", None))
        self.choose_btn.setText(QCoreApplication.translate("Dialog", u"Choose", None))
        self.label_5.setText(QCoreApplication.translate("Dialog", u"User:", None))
        self.user_id_line.setPlaceholderText(QCoreApplication.translate("Dialog", u"TUPC-ID only", None))
        self.label_7.setText(QCoreApplication.translate("Dialog", u"Email:", None))
        self.email_to_send_line.setPlaceholderText("")
        self.send_btn_Excel.setText(QCoreApplication.translate("Dialog", u"Send Excel", None))
        self.send_btn_PDF.setText(QCoreApplication.translate("Dialog", u"Send PDF", None))
        self.label_56.setText(QCoreApplication.translate("Dialog", u"Sections List", None))
        self.label_58.setText(QCoreApplication.translate("Dialog", u"Download Section", None))
        self.label_8.setText(QCoreApplication.translate("Dialog", u"Choose Section:", None))
        self.choose_btn_download.setText(QCoreApplication.translate("Dialog", u"Choose", None))
        self.download_btn_pdf.setText(QCoreApplication.translate("Dialog", u"Download PDF", None))
        self.download_btn_excel.setText(QCoreApplication.translate("Dialog", u"Download Excel", None))
    # retranslateUi

