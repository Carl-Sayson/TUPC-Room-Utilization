# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Edit_students.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(786, 602)
        Form.setMaximumSize(QSize(1248, 735))
        Form.setStyleSheet(u"QWidget {\n"
"        background: qlineargradient(\n"
"            x1: 0, y1: 0, x2: 0, y2: 1,\n"
"            stop: 0 #ffffff,    /* White at the top */\n"
"            stop: 1 #ff0000     /* Red at the bottom */\n"
"        );\n"
"    }")
        self.gridLayout_3 = QGridLayout(Form)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.frame = QFrame(Form)
        self.frame.setObjectName(u"frame")
        self.frame.setMinimumSize(QSize(764, 580))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.label_34 = QLabel(self.frame)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setMaximumSize(QSize(16777215, 109))
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(12)
        self.label_34.setFont(font)
        self.label_34.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.gridLayout.addWidget(self.label_34, 0, 0, 1, 1)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label_8 = QLabel(self.frame)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font)
        self.label_8.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout.addWidget(self.label_8)

        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.sort_student_section = QComboBox(self.frame)
        self.sort_student_section.addItem("")
        self.sort_student_section.addItem("")
        self.sort_student_section.setObjectName(u"sort_student_section")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        self.sort_student_section.setFont(font1)
        self.sort_student_section.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.horizontalLayout_12.addWidget(self.sort_student_section)

        self.search_bar_stdnt_insched = QLineEdit(self.frame)
        self.search_bar_stdnt_insched.setObjectName(u"search_bar_stdnt_insched")
        self.search_bar_stdnt_insched.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_12.addWidget(self.search_bar_stdnt_insched)

        self.search_stdnt_insched_btn = QPushButton(self.frame)
        self.search_stdnt_insched_btn.setObjectName(u"search_stdnt_insched_btn")
        self.search_stdnt_insched_btn.setFont(font1)
        self.search_stdnt_insched_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_12.addWidget(self.search_stdnt_insched_btn)


        self.verticalLayout.addLayout(self.horizontalLayout_12)

        self.list_students_schedule = QListWidget(self.frame)
        self.list_students_schedule.setObjectName(u"list_students_schedule")
        self.list_students_schedule.setMinimumSize(QSize(360, 233))
        self.list_students_schedule.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);\n"
"QListWidget::item:selected {\n"
"    background-color: #0078d7; /* selection color */\n"
"    color: white;              /* text color on selection */\n"
"}\n"
"")

        self.verticalLayout.addWidget(self.list_students_schedule)


        self.gridLayout.addLayout(self.verticalLayout, 0, 1, 3, 1)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.sort_student_section_2 = QComboBox(self.frame)
        self.sort_student_section_2.addItem("")
        self.sort_student_section_2.addItem("")
        self.sort_student_section_2.setObjectName(u"sort_student_section_2")
        self.sort_student_section_2.setFont(font1)
        self.sort_student_section_2.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.horizontalLayout.addWidget(self.sort_student_section_2)

        self.search_bar_sections = QLineEdit(self.frame)
        self.search_bar_sections.setObjectName(u"search_bar_sections")
        self.search_bar_sections.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout.addWidget(self.search_bar_sections)

        self.search_stdnt_sections_btn_2 = QPushButton(self.frame)
        self.search_stdnt_sections_btn_2.setObjectName(u"search_stdnt_sections_btn_2")
        self.search_stdnt_sections_btn_2.setFont(font1)
        self.search_stdnt_sections_btn_2.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout.addWidget(self.search_stdnt_sections_btn_2)


        self.gridLayout.addLayout(self.horizontalLayout, 1, 0, 1, 1)

        self.gridLayout_2 = QGridLayout()
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.list_sections_schedule = QListWidget(self.frame)
        self.list_sections_schedule.setObjectName(u"list_sections_schedule")
        self.list_sections_schedule.setMinimumSize(QSize(365, 280))
        self.list_sections_schedule.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);\n"
"QListWidget::item:selected {\n"
"    background-color: #0078d7; /* selection color */\n"
"    color: white;              /* text color on selection */\n"
"}\n"
"")

        self.gridLayout_2.addWidget(self.list_sections_schedule, 1, 0, 1, 2)

        self.remove_section = QPushButton(self.frame)
        self.remove_section.setObjectName(u"remove_section")
        self.remove_section.setMinimumSize(QSize(100, 40))
        self.remove_section.setFont(font1)
        self.remove_section.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout_2.addWidget(self.remove_section, 2, 1, 1, 1, Qt.AlignRight)

        self.add_section_btn = QPushButton(self.frame)
        self.add_section_btn.setObjectName(u"add_section_btn")
        self.add_section_btn.setMinimumSize(QSize(100, 40))
        self.add_section_btn.setFont(font1)
        self.add_section_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout_2.addWidget(self.add_section_btn, 2, 0, 1, 1, Qt.AlignLeft)


        self.gridLayout.addLayout(self.gridLayout_2, 2, 0, 1, 1)


        self.gridLayout_3.addWidget(self.frame, 0, 0, 1, 1)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Dialog", None))
        self.label_34.setText(QCoreApplication.translate("Form", u"Add / Remove Section", None))
        self.label_8.setText(QCoreApplication.translate("Form", u"Enrolled Students:", None))
        self.sort_student_section.setItemText(0, QCoreApplication.translate("Form", u"A-Z", None))
        self.sort_student_section.setItemText(1, QCoreApplication.translate("Form", u"Z-A", None))

        self.sort_student_section.setCurrentText(QCoreApplication.translate("Form", u"A-Z", None))
        self.search_stdnt_insched_btn.setText(QCoreApplication.translate("Form", u"Search", None))
        self.sort_student_section_2.setItemText(0, QCoreApplication.translate("Form", u"A-Z", None))
        self.sort_student_section_2.setItemText(1, QCoreApplication.translate("Form", u"Z-A", None))

        self.sort_student_section_2.setCurrentText(QCoreApplication.translate("Form", u"A-Z", None))
        self.search_stdnt_sections_btn_2.setText(QCoreApplication.translate("Form", u"Search", None))
        self.remove_section.setText(QCoreApplication.translate("Form", u"Remove Section", None))
        self.add_section_btn.setText(QCoreApplication.translate("Form", u"Add Section", None))
    # retranslateUi

