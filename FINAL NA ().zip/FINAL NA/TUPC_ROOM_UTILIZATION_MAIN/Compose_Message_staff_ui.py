# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Compose_Message_staff.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPlainTextEdit, QPushButton, QSizePolicy,
    QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(951, 660)
        Form.setMaximumSize(QSize(1200, 720))
        Form.setStyleSheet(u"QWidget {\n"
"        background: qlineargradient(\n"
"            x1: 0, y1: 0, x2: 0, y2: 1,\n"
"            stop: 0 #ffffff,    /* White at the top */\n"
"            stop: 1 #ff0000     /* Red at the bottom */\n"
"        );\n"
"    }")
        self.gridLayout_2 = QGridLayout(Form)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.frame = QFrame(Form)
        self.frame.setObjectName(u"frame")
        self.frame.setMinimumSize(QSize(500, 450))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.label_47 = QLabel(self.frame)
        self.label_47.setObjectName(u"label_47")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(True)
        self.label_47.setFont(font)
        self.label_47.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.gridLayout.addWidget(self.label_47, 0, 0, 1, 1)

        self.type_report = QComboBox(self.frame)
        self.type_report.addItem("")
        self.type_report.addItem("")
        self.type_report.setObjectName(u"type_report")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(9)
        font1.setBold(True)
        font1.setItalic(True)
        self.type_report.setFont(font1)
        self.type_report.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.gridLayout.addWidget(self.type_report, 0, 2, 1, 2)

        self.label_48 = QLabel(self.frame)
        self.label_48.setObjectName(u"label_48")
        font2 = QFont()
        font2.setFamilies([u"Sitka Small Semibold"])
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setItalic(True)
        self.label_48.setFont(font2)
        self.label_48.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.gridLayout.addWidget(self.label_48, 1, 0, 1, 1)

        self.selected_room = QLineEdit(self.frame)
        self.selected_room.setObjectName(u"selected_room")
        font3 = QFont()
        font3.setFamilies([u"Sitka Small"])
        font3.setPointSize(8)
        font3.setBold(True)
        self.selected_room.setFont(font3)
        self.selected_room.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.gridLayout.addWidget(self.selected_room, 1, 1, 1, 2)

        self.choose_rm_btn = QPushButton(self.frame)
        self.choose_rm_btn.setObjectName(u"choose_rm_btn")
        font4 = QFont()
        font4.setFamilies([u"Sitka Small Semibold"])
        font4.setPointSize(10)
        font4.setBold(True)
        font4.setItalic(True)
        self.choose_rm_btn.setFont(font4)
        self.choose_rm_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout.addWidget(self.choose_rm_btn, 1, 3, 1, 1)

        self.label_49 = QLabel(self.frame)
        self.label_49.setObjectName(u"label_49")
        self.label_49.setFont(font2)
        self.label_49.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.gridLayout.addWidget(self.label_49, 2, 0, 1, 2)

        self.message_report = QPlainTextEdit(self.frame)
        self.message_report.setObjectName(u"message_report")
        font5 = QFont()
        font5.setFamilies([u"Sitka Small"])
        font5.setPointSize(9)
        font5.setBold(True)
        self.message_report.setFont(font5)
        self.message_report.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.message_report.setFrameShape(QFrame.Box)
        self.message_report.setFrameShadow(QFrame.Plain)
        self.message_report.setOverwriteMode(False)

        self.gridLayout.addWidget(self.message_report, 3, 0, 1, 4)

        self.send_btn_composed_msg = QPushButton(self.frame)
        self.send_btn_composed_msg.setObjectName(u"send_btn_composed_msg")
        self.send_btn_composed_msg.setFont(font2)
        self.send_btn_composed_msg.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout.addWidget(self.send_btn_composed_msg, 4, 3, 1, 1)


        self.gridLayout_2.addWidget(self.frame, 0, 0, 2, 1)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.comboBox = QComboBox(Form)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        font6 = QFont()
        font6.setFamilies([u"Sitka Small Semibold"])
        font6.setBold(True)
        font6.setItalic(True)
        self.comboBox.setFont(font6)
        self.comboBox.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.horizontalLayout_19.addWidget(self.comboBox)

        self.search_bar_room_report_staff = QLineEdit(Form)
        self.search_bar_room_report_staff.setObjectName(u"search_bar_room_report_staff")
        self.search_bar_room_report_staff.setFont(font3)
        self.search_bar_room_report_staff.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_19.addWidget(self.search_bar_room_report_staff)

        self.search_room_report_staff_btn = QPushButton(Form)
        self.search_room_report_staff_btn.setObjectName(u"search_room_report_staff_btn")
        self.search_room_report_staff_btn.setFont(font4)
        self.search_room_report_staff_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_19.addWidget(self.search_room_report_staff_btn)


        self.gridLayout_2.addLayout(self.horizontalLayout_19, 0, 1, 1, 1)

        self.room_list_report_staff = QListWidget(Form)
        self.room_list_report_staff.setObjectName(u"room_list_report_staff")
        self.room_list_report_staff.setMinimumSize(QSize(422, 451))
        font7 = QFont()
        font7.setFamilies([u"Sitka Small"])
        font7.setBold(True)
        self.room_list_report_staff.setFont(font7)
        self.room_list_report_staff.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.gridLayout_2.addWidget(self.room_list_report_staff, 1, 1, 1, 1)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Dialog", None))
        self.label_47.setText(QCoreApplication.translate("Form", u"Staff Report:", None))
        self.type_report.setItemText(0, QCoreApplication.translate("Form", u"Damage Report", None))
        self.type_report.setItemText(1, QCoreApplication.translate("Form", u"Maintenance Report", None))

        self.label_48.setText(QCoreApplication.translate("Form", u"Selected Room", None))
#if QT_CONFIG(tooltip)
        self.choose_rm_btn.setToolTip(QCoreApplication.translate("Form", u"Send", None))
#endif // QT_CONFIG(tooltip)
        self.choose_rm_btn.setText(QCoreApplication.translate("Form", u"Choose", None))
        self.label_49.setText(QCoreApplication.translate("Form", u"Report Details:", None))
        self.message_report.setPlainText("")
#if QT_CONFIG(tooltip)
        self.send_btn_composed_msg.setToolTip(QCoreApplication.translate("Form", u"Send", None))
#endif // QT_CONFIG(tooltip)
        self.send_btn_composed_msg.setText(QCoreApplication.translate("Form", u"Send", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("Form", u"A-Z", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("Form", u"Z-A", None))

#if QT_CONFIG(tooltip)
        self.search_room_report_staff_btn.setToolTip(QCoreApplication.translate("Form", u"Search", None))
#endif // QT_CONFIG(tooltip)
        self.search_room_report_staff_btn.setText(QCoreApplication.translate("Form", u"Search", None))
    # retranslateUi

