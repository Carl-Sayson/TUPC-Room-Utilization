# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'HowToReg_Staff.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QFrame, QGridLayout,
    QLabel, QPushButton, QSizePolicy, QSpacerItem,
    QWidget)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(480, 430)
        Dialog.setMinimumSize(QSize(480, 430))
        Dialog.setMaximumSize(QSize(480, 430))
        self.frame_3 = QFrame(Dialog)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setGeometry(QRect(-10, 0, 1021, 41))
        self.frame_3.setMaximumSize(QSize(9999999, 140))
        self.frame_3.setStyleSheet(u"background: qlineargradient(\n"
"        x1: 0, y1: 0,\n"
"        x2: 1, y2: 0,\n"
"        stop: 0 #8B0000,\n"
"        stop: 0.5 #BB3F3F,\n"
"        stop: 1 #8B0000\n"
"    );\n"
"    border: none;\n"
"    padding: 0px;\n"
"")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame_3)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setHorizontalSpacing(0)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.layoutWidget = QWidget(Dialog)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(30, 55, 424, 307))
        self.gridLayout_2 = QGridLayout(self.layoutWidget)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalSpacer = QSpacerItem(20, 28, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_2.addItem(self.verticalSpacer, 0, 1, 1, 1)

        self.line = QFrame(self.layoutWidget)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.gridLayout_2.addWidget(self.line, 1, 0, 1, 1)

        self.label_4 = QLabel(self.layoutWidget)
        self.label_4.setObjectName(u"label_4")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(False)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"qproperty-alignment: AlignCenter;\n"
"")

        self.gridLayout_2.addWidget(self.label_4, 1, 1, 1, 2)

        self.Login_lbl_5 = QLabel(self.layoutWidget)
        self.Login_lbl_5.setObjectName(u"Login_lbl_5")
        self.Login_lbl_5.setMaximumSize(QSize(1111, 1111))
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(9)
        font1.setBold(True)
        font1.setItalic(False)
        self.Login_lbl_5.setFont(font1)
        self.Login_lbl_5.setStyleSheet(u"QLabel {\n"
"    qproperty-alignment: AlignLeft;\n"
"}\n"
"border: none;\n"
"    padding: 0px;\n"
"    margin: 0px;\n"
"    background: transparent;")
        self.Login_lbl_5.setAlignment(Qt.AlignLeading)

        self.gridLayout_2.addWidget(self.Login_lbl_5, 2, 0, 1, 4)

        self.line_2 = QFrame(self.layoutWidget)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setFrameShape(QFrame.Shape.HLine)
        self.line_2.setFrameShadow(QFrame.Shadow.Sunken)

        self.gridLayout_2.addWidget(self.line_2, 3, 0, 1, 4)

        self.verticalSpacer_2 = QSpacerItem(20, 38, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_2.addItem(self.verticalSpacer_2, 4, 2, 1, 1)

        self.Login_lbl_4 = QLabel(self.layoutWidget)
        self.Login_lbl_4.setObjectName(u"Login_lbl_4")
        self.Login_lbl_4.setMaximumSize(QSize(1111, 1111))
        self.Login_lbl_4.setFont(font1)
        self.Login_lbl_4.setStyleSheet(u" qproperty-alignment: AlignLeft;\n"
"border: none;\n"
"    padding: 0px;\n"
"    margin: 0px;\n"
"    background: transparent;")
        self.Login_lbl_4.setAlignment(Qt.AlignLeading)

        self.gridLayout_2.addWidget(self.Login_lbl_4, 5, 0, 1, 4)

        self.choose_btn_download = QPushButton(Dialog)
        self.choose_btn_download.setObjectName(u"choose_btn_download")
        self.choose_btn_download.setGeometry(QRect(380, 380, 91, 40))
        self.choose_btn_download.setMaximumSize(QSize(380, 720))
        font2 = QFont()
        font2.setFamilies([u"Sitka Heading Semibold"])
        font2.setPointSize(10)
        font2.setBold(True)
        font2.setItalic(False)
        self.choose_btn_download.setFont(font2)
        self.choose_btn_download.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label_4.setText(QCoreApplication.translate("Dialog", u"How to register STAFF", None))
        self.Login_lbl_5.setText(QCoreApplication.translate("Dialog", u"1. Click \u201cStaff\u201d button\n"
"2. Click \u201cManage Staff\u201d  button\n"
"3. Click the \u201cEdit Staff\u201d button on the upper left \n"
"4. Input the first name, last name, Email, ID number\n"
"5. click \u201cgenerate password\u201d button\n"
"6. Click \u201csave\u201d button\n"
"", None))
        self.Login_lbl_4.setText(QCoreApplication.translate("Dialog", u"Technological University of the Philippines \u2013 Cavite\n"
"\u00a9 Copyright (C) 2025 Sayson, Cuadra, Montoya", None))
        self.choose_btn_download.setText(QCoreApplication.translate("Dialog", u"Close", None))
    # retranslateUi

