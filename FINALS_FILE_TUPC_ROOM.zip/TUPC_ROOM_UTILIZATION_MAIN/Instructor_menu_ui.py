# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Instructor_menu.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMainWindow, QPlainTextEdit, QPushButton,
    QSizePolicy, QSpacerItem, QStackedWidget, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1009, 659)
        MainWindow.setStyleSheet(u"QWidget {\n"
"        background: qlineargradient(\n"
"            x1: 0, y1: 0, x2: 0, y2: 1,\n"
"            stop: 0 #ffffff,    /* White at the top */\n"
"            stop: 1 #ff0000     /* Red at the bottom */\n"
"        );\n"
"    }")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.horizontalLayout = QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(20)
        font.setBold(True)
        font.setItalic(True)
        self.label.setFont(font)
        self.label.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_2.addWidget(self.label)

        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(16)
        font1.setBold(True)
        font1.setItalic(True)
        self.label_2.setFont(font1)
        self.label_2.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_2.addWidget(self.label_2)


        self.gridLayout.addLayout(self.verticalLayout_2, 0, 0, 1, 1)


        self.verticalLayout_3.addWidget(self.frame)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.instructor_sched_btn = QPushButton(self.centralwidget)
        self.instructor_sched_btn.setObjectName(u"instructor_sched_btn")
        self.instructor_sched_btn.setMinimumSize(QSize(100, 40))
        font2 = QFont()
        font2.setFamilies([u"Sitka Small Semibold"])
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setItalic(True)
        self.instructor_sched_btn.setFont(font2)
        self.instructor_sched_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.instructor_sched_btn)

        self.instructor_info_btn = QPushButton(self.centralwidget)
        self.instructor_info_btn.setObjectName(u"instructor_info_btn")
        self.instructor_info_btn.setMinimumSize(QSize(100, 40))
        self.instructor_info_btn.setFont(font2)
        self.instructor_info_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.instructor_info_btn)

        self.instructor_inbox_btn = QPushButton(self.centralwidget)
        self.instructor_inbox_btn.setObjectName(u"instructor_inbox_btn")
        self.instructor_inbox_btn.setMinimumSize(QSize(100, 40))
        self.instructor_inbox_btn.setFont(font2)
        self.instructor_inbox_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.instructor_inbox_btn)


        self.verticalLayout_3.addLayout(self.verticalLayout)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer)

        self.logout_btn = QPushButton(self.centralwidget)
        self.logout_btn.setObjectName(u"logout_btn")
        self.logout_btn.setMinimumSize(QSize(100, 40))
        self.logout_btn.setFont(font2)
        self.logout_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_3.addWidget(self.logout_btn)


        self.horizontalLayout.addLayout(self.verticalLayout_3)

        self.frame_2 = QFrame(self.centralwidget)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setMinimumSize(QSize(801, 637))
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.gridLayout_3 = QGridLayout(self.frame_2)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.instructor_menu_stackedwidget = QStackedWidget(self.frame_2)
        self.instructor_menu_stackedwidget.setObjectName(u"instructor_menu_stackedwidget")
        self.instructor_menu_stackedwidgetPage1_2 = QWidget()
        self.instructor_menu_stackedwidgetPage1_2.setObjectName(u"instructor_menu_stackedwidgetPage1_2")
        self.gridLayout_2 = QGridLayout(self.instructor_menu_stackedwidgetPage1_2)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.instructor_room_sched_table = QTableWidget(self.instructor_menu_stackedwidgetPage1_2)
        if (self.instructor_room_sched_table.columnCount() < 5):
            self.instructor_room_sched_table.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.instructor_room_sched_table.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.instructor_room_sched_table.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.instructor_room_sched_table.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.instructor_room_sched_table.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.instructor_room_sched_table.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.instructor_room_sched_table.setObjectName(u"instructor_room_sched_table")
        self.instructor_room_sched_table.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.gridLayout_2.addWidget(self.instructor_room_sched_table, 1, 0, 1, 1)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_58 = QLabel(self.instructor_menu_stackedwidgetPage1_2)
        self.label_58.setObjectName(u"label_58")
        font3 = QFont()
        font3.setFamilies([u"Sitka Small Semibold"])
        font3.setPointSize(14)
        font3.setBold(True)
        font3.setItalic(False)
        self.label_58.setFont(font3)
        self.label_58.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_8.addWidget(self.label_58)

        self.accessed_room_instructor = QLineEdit(self.instructor_menu_stackedwidgetPage1_2)
        self.accessed_room_instructor.setObjectName(u"accessed_room_instructor")
        self.accessed_room_instructor.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        self.accessed_room_instructor.setReadOnly(True)

        self.horizontalLayout_8.addWidget(self.accessed_room_instructor)

        self.horizontalSpacer_9 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_8.addItem(self.horizontalSpacer_9)


        self.gridLayout_2.addLayout(self.horizontalLayout_8, 0, 0, 1, 1)

        self.instructor_menu_stackedwidget.addWidget(self.instructor_menu_stackedwidgetPage1_2)
        self.instructor_menu_stackedwidgetPage2_2 = QWidget()
        self.instructor_menu_stackedwidgetPage2_2.setObjectName(u"instructor_menu_stackedwidgetPage2_2")
        self.gridLayout_4 = QGridLayout(self.instructor_menu_stackedwidgetPage2_2)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.horizontalSpacer = QSpacerItem(70, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.gridLayout_4.addItem(self.horizontalSpacer, 0, 0, 1, 1)

        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_8.addItem(self.verticalSpacer_3)

        self.label_10 = QLabel(self.instructor_menu_stackedwidgetPage2_2)
        self.label_10.setObjectName(u"label_10")
        font4 = QFont()
        font4.setFamilies([u"Sitka Small Semibold"])
        font4.setPointSize(14)
        font4.setBold(True)
        font4.setItalic(True)
        self.label_10.setFont(font4)
        self.label_10.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_8.addWidget(self.label_10)

        self.line = QFrame(self.instructor_menu_stackedwidgetPage2_2)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_8.addWidget(self.line)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_8.addItem(self.verticalSpacer_5)

        self.verticalLayout_14 = QVBoxLayout()
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.label_13 = QLabel(self.instructor_menu_stackedwidgetPage2_2)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setFont(font2)
        self.label_13.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_14.addWidget(self.label_13, 0, Qt.AlignLeft)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.verticalLayout_13 = QVBoxLayout()
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.first_name_lineedit_nstrctrinfo = QLineEdit(self.instructor_menu_stackedwidgetPage2_2)
        self.first_name_lineedit_nstrctrinfo.setObjectName(u"first_name_lineedit_nstrctrinfo")
        self.first_name_lineedit_nstrctrinfo.setMaximumSize(QSize(700, 16777215))
        font5 = QFont()
        font5.setFamilies([u"Sitka Small"])
        font5.setBold(True)
        self.first_name_lineedit_nstrctrinfo.setFont(font5)
        self.first_name_lineedit_nstrctrinfo.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.verticalLayout_13.addWidget(self.first_name_lineedit_nstrctrinfo)

        self.label_30 = QLabel(self.instructor_menu_stackedwidgetPage2_2)
        self.label_30.setObjectName(u"label_30")
        font6 = QFont()
        font6.setFamilies([u"Sitka Small Semibold"])
        font6.setPointSize(9)
        font6.setBold(True)
        font6.setItalic(True)
        self.label_30.setFont(font6)
        self.label_30.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_13.addWidget(self.label_30)


        self.horizontalLayout_6.addLayout(self.verticalLayout_13)

        self.horizontalSpacer_3 = QSpacerItem(30, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_6.addItem(self.horizontalSpacer_3)

        self.verticalLayout_12 = QVBoxLayout()
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.last_name_lineedit_nstrctrinfo = QLineEdit(self.instructor_menu_stackedwidgetPage2_2)
        self.last_name_lineedit_nstrctrinfo.setObjectName(u"last_name_lineedit_nstrctrinfo")
        self.last_name_lineedit_nstrctrinfo.setMaximumSize(QSize(700, 16777215))
        self.last_name_lineedit_nstrctrinfo.setFont(font5)
        self.last_name_lineedit_nstrctrinfo.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.verticalLayout_12.addWidget(self.last_name_lineedit_nstrctrinfo)

        self.label_12 = QLabel(self.instructor_menu_stackedwidgetPage2_2)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setFont(font6)
        self.label_12.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_12.addWidget(self.label_12)


        self.horizontalLayout_6.addLayout(self.verticalLayout_12)


        self.verticalLayout_14.addLayout(self.horizontalLayout_6)


        self.verticalLayout_8.addLayout(self.verticalLayout_14)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.label_28 = QLabel(self.instructor_menu_stackedwidgetPage2_2)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setFont(font2)
        self.label_28.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_6.addWidget(self.label_28)

        self.email_nstrctr_lineedit_info_4 = QLineEdit(self.instructor_menu_stackedwidgetPage2_2)
        self.email_nstrctr_lineedit_info_4.setObjectName(u"email_nstrctr_lineedit_info_4")
        self.email_nstrctr_lineedit_info_4.setMaximumSize(QSize(700, 16777215))
        self.email_nstrctr_lineedit_info_4.setFont(font5)
        self.email_nstrctr_lineedit_info_4.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.verticalLayout_6.addWidget(self.email_nstrctr_lineedit_info_4)

        self.verticalSpacer_20 = QSpacerItem(20, 13, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_6.addItem(self.verticalSpacer_20)


        self.horizontalLayout_4.addLayout(self.verticalLayout_6)

        self.horizontalSpacer_19 = QSpacerItem(30, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_19)

        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.label_29 = QLabel(self.instructor_menu_stackedwidgetPage2_2)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setFont(font2)
        self.label_29.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_7.addWidget(self.label_29)

        self.tupc_id_lineedit_info_4 = QLineEdit(self.instructor_menu_stackedwidgetPage2_2)
        self.tupc_id_lineedit_info_4.setObjectName(u"tupc_id_lineedit_info_4")
        self.tupc_id_lineedit_info_4.setMaximumSize(QSize(700, 16777215))
        self.tupc_id_lineedit_info_4.setFont(font5)
        self.tupc_id_lineedit_info_4.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.verticalLayout_7.addWidget(self.tupc_id_lineedit_info_4)

        self.verticalSpacer_21 = QSpacerItem(20, 13, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_7.addItem(self.verticalSpacer_21)


        self.horizontalLayout_4.addLayout(self.verticalLayout_7)


        self.verticalLayout_8.addLayout(self.horizontalLayout_4)

        self.change_pass = QPushButton(self.instructor_menu_stackedwidgetPage2_2)
        self.change_pass.setObjectName(u"change_pass")
        self.change_pass.setMinimumSize(QSize(100, 40))
        self.change_pass.setFont(font2)
        self.change_pass.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_8.addWidget(self.change_pass, 0, Qt.AlignHCenter)


        self.gridLayout_4.addLayout(self.verticalLayout_8, 0, 1, 1, 1)

        self.horizontalSpacer_2 = QSpacerItem(70, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.gridLayout_4.addItem(self.horizontalSpacer_2, 0, 2, 1, 1)

        self.verticalSpacer_2 = QSpacerItem(17, 125, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_4.addItem(self.verticalSpacer_2, 1, 1, 1, 1)

        self.instructor_menu_stackedwidget.addWidget(self.instructor_menu_stackedwidgetPage2_2)
        self.instructor_menu_stackedwidgetPage3_2 = QWidget()
        self.instructor_menu_stackedwidgetPage3_2.setObjectName(u"instructor_menu_stackedwidgetPage3_2")
        self.gridLayout_6 = QGridLayout(self.instructor_menu_stackedwidgetPage3_2)
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.gridLayout_18 = QGridLayout()
        self.gridLayout_18.setObjectName(u"gridLayout_18")
        self.verticalLayout_55 = QVBoxLayout()
        self.verticalLayout_55.setObjectName(u"verticalLayout_55")
        self.label_43 = QLabel(self.instructor_menu_stackedwidgetPage3_2)
        self.label_43.setObjectName(u"label_43")
        font7 = QFont()
        font7.setFamilies([u"Sitka Small Semibold"])
        font7.setPointSize(14)
        self.label_43.setFont(font7)
        self.label_43.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_55.addWidget(self.label_43)

        self.listsent_received_inbox_instructor = QListWidget(self.instructor_menu_stackedwidgetPage3_2)
        self.listsent_received_inbox_instructor.setObjectName(u"listsent_received_inbox_instructor")
        font8 = QFont()
        font8.setFamilies([u"Sitka Text"])
        font8.setPointSize(9)
        self.listsent_received_inbox_instructor.setFont(font8)
        self.listsent_received_inbox_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.listsent_received_inbox_instructor.setFrameShape(QFrame.Box)
        self.listsent_received_inbox_instructor.setFrameShadow(QFrame.Plain)

        self.verticalLayout_55.addWidget(self.listsent_received_inbox_instructor)


        self.gridLayout_18.addLayout(self.verticalLayout_55, 0, 0, 1, 1)

        self.verticalLayout_54 = QVBoxLayout()
        self.verticalLayout_54.setObjectName(u"verticalLayout_54")
        self.label_44 = QLabel(self.instructor_menu_stackedwidgetPage3_2)
        self.label_44.setObjectName(u"label_44")
        self.label_44.setFont(font7)
        self.label_44.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_54.addWidget(self.label_44)

        self.received_message_instructor = QPlainTextEdit(self.instructor_menu_stackedwidgetPage3_2)
        self.received_message_instructor.setObjectName(u"received_message_instructor")
        self.received_message_instructor.setFont(font8)
        self.received_message_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.received_message_instructor.setFrameShape(QFrame.Box)
        self.received_message_instructor.setFrameShadow(QFrame.Plain)
        self.received_message_instructor.setTextInteractionFlags(Qt.TextSelectableByKeyboard|Qt.TextSelectableByMouse)

        self.verticalLayout_54.addWidget(self.received_message_instructor)

        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.del_messages_instructor = QPushButton(self.instructor_menu_stackedwidgetPage3_2)
        self.del_messages_instructor.setObjectName(u"del_messages_instructor")
        self.del_messages_instructor.setMinimumSize(QSize(120, 60))
        self.del_messages_instructor.setFont(font2)
        self.del_messages_instructor.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_17.addWidget(self.del_messages_instructor)

        self.horizontalSpacer_12 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_17.addItem(self.horizontalSpacer_12)

        self.send_message_instructor_btn = QPushButton(self.instructor_menu_stackedwidgetPage3_2)
        self.send_message_instructor_btn.setObjectName(u"send_message_instructor_btn")
        self.send_message_instructor_btn.setMinimumSize(QSize(120, 60))
        self.send_message_instructor_btn.setFont(font2)
        self.send_message_instructor_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_17.addWidget(self.send_message_instructor_btn, 0, Qt.AlignRight)


        self.verticalLayout_54.addLayout(self.horizontalLayout_17)


        self.gridLayout_18.addLayout(self.verticalLayout_54, 0, 1, 1, 1)


        self.gridLayout_6.addLayout(self.gridLayout_18, 0, 0, 1, 1)

        self.instructor_menu_stackedwidget.addWidget(self.instructor_menu_stackedwidgetPage3_2)

        self.gridLayout_3.addWidget(self.instructor_menu_stackedwidget, 0, 0, 1, 1)


        self.horizontalLayout.addWidget(self.frame_2)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        self.instructor_menu_stackedwidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Welcome", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Instructor", None))
#if QT_CONFIG(tooltip)
        self.instructor_sched_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Schedule", None))
#endif // QT_CONFIG(tooltip)
        self.instructor_sched_btn.setText(QCoreApplication.translate("MainWindow", u"Schedule", None))
#if QT_CONFIG(tooltip)
        self.instructor_info_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Information", None))
#endif // QT_CONFIG(tooltip)
        self.instructor_info_btn.setText(QCoreApplication.translate("MainWindow", u"Information", None))
#if QT_CONFIG(tooltip)
        self.instructor_inbox_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Inbox", None))
#endif // QT_CONFIG(tooltip)
        self.instructor_inbox_btn.setText(QCoreApplication.translate("MainWindow", u"Inbox", None))
#if QT_CONFIG(tooltip)
        self.logout_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Logout", None))
#endif // QT_CONFIG(tooltip)
        self.logout_btn.setText(QCoreApplication.translate("MainWindow", u"Logout", None))
        ___qtablewidgetitem = self.instructor_room_sched_table.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"Monday", None));
        ___qtablewidgetitem1 = self.instructor_room_sched_table.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Tuesday", None));
        ___qtablewidgetitem2 = self.instructor_room_sched_table.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Wednesday", None));
        ___qtablewidgetitem3 = self.instructor_room_sched_table.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"Thursday", None));
        ___qtablewidgetitem4 = self.instructor_room_sched_table.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Friday", None));
        self.label_58.setText(QCoreApplication.translate("MainWindow", u"Room Access Status:", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Instructor Information", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"Name:", None))
        self.first_name_lineedit_nstrctrinfo.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Juan", None))
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"First Name", None))
        self.last_name_lineedit_nstrctrinfo.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Luna", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Last Name", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"Email:", None))
        self.email_nstrctr_lineedit_info_4.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Juan.Luna@gsfe.tupcavite.edu.ph", None))
        self.label_29.setText(QCoreApplication.translate("MainWindow", u"TUPC-ID:", None))
        self.tupc_id_lineedit_info_4.setPlaceholderText(QCoreApplication.translate("MainWindow", u"TUPC-25-123456", None))
        self.change_pass.setText(QCoreApplication.translate("MainWindow", u"Change Password", None))
        self.label_43.setText(QCoreApplication.translate("MainWindow", u"Room Requests", None))
        self.label_44.setText(QCoreApplication.translate("MainWindow", u"Received Message", None))
        self.received_message_instructor.setPlainText("")
        self.del_messages_instructor.setText(QCoreApplication.translate("MainWindow", u"Delete", None))
        self.send_message_instructor_btn.setText(QCoreApplication.translate("MainWindow", u"Compose", None))
    # retranslateUi

