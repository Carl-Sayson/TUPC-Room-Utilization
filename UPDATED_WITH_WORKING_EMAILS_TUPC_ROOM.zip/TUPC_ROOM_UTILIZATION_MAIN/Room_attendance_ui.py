# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Room_attendance.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QFrame, QGridLayout,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(867, 810)
        Form.setMinimumSize(QSize(627, 672))
        Form.setMaximumSize(QSize(867, 810))
        self.gridLayout = QGridLayout(Form)
        self.gridLayout.setObjectName(u"gridLayout")
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_58 = QLabel(Form)
        self.label_58.setObjectName(u"label_58")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(False)
        self.label_58.setFont(font)
        self.label_58.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_3.addWidget(self.label_58)

        self.accessed_room = QLineEdit(Form)
        self.accessed_room.setObjectName(u"accessed_room")
        self.accessed_room.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        self.accessed_room.setReadOnly(True)

        self.horizontalLayout_3.addWidget(self.accessed_room)


        self.gridLayout.addLayout(self.horizontalLayout_3, 0, 0, 1, 1)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label_59 = QLabel(Form)
        self.label_59.setObjectName(u"label_59")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(12)
        font1.setBold(True)
        font1.setItalic(False)
        self.label_59.setFont(font1)
        self.label_59.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_2.addWidget(self.label_59, 0, Qt.AlignHCenter)

        self.frame = QFrame(Form)
        self.frame.setObjectName(u"frame")
        self.frame.setMinimumSize(QSize(300, 325))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)

        self.verticalLayout_2.addWidget(self.frame)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_57 = QLabel(Form)
        self.label_57.setObjectName(u"label_57")
        self.label_57.setFont(font)
        self.label_57.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_6.addWidget(self.label_57)

        self.users_scanned = QLineEdit(Form)
        self.users_scanned.setObjectName(u"users_scanned")
        self.users_scanned.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        self.users_scanned.setReadOnly(True)

        self.horizontalLayout_6.addWidget(self.users_scanned)


        self.verticalLayout_2.addLayout(self.horizontalLayout_6)

        self.list_attendance = QTableWidget(Form)
        if (self.list_attendance.columnCount() < 2):
            self.list_attendance.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.list_attendance.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.list_attendance.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        if (self.list_attendance.rowCount() < 1):
            self.list_attendance.setRowCount(1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.list_attendance.setVerticalHeaderItem(0, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.list_attendance.setItem(0, 0, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.list_attendance.setItem(0, 1, __qtablewidgetitem4)
        self.list_attendance.setObjectName(u"list_attendance")
        font2 = QFont()
        font2.setPointSize(10)
        self.list_attendance.setFont(font2)
        self.list_attendance.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.list_attendance.setFrameShadow(QFrame.Plain)
        self.list_attendance.setEditTriggers(QAbstractItemView.AnyKeyPressed|QAbstractItemView.DoubleClicked|QAbstractItemView.EditKeyPressed|QAbstractItemView.SelectedClicked)
        self.list_attendance.horizontalHeader().setDefaultSectionSize(130)

        self.verticalLayout_2.addWidget(self.list_attendance)

        self.export_btn = QPushButton(Form)
        self.export_btn.setObjectName(u"export_btn")
        self.export_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_2.addWidget(self.export_btn, 0, Qt.AlignRight)


        self.gridLayout.addLayout(self.verticalLayout_2, 0, 1, 3, 1)

        self.line = QFrame(Form)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.gridLayout.addWidget(self.line, 1, 0, 1, 1)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.label_17 = QLabel(Form)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setFont(font)
        self.label_17.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_6.addWidget(self.label_17, 0, Qt.AlignHCenter)

        self.list_registered_stdnt_instructor_sched = QTableWidget(Form)
        if (self.list_registered_stdnt_instructor_sched.columnCount() < 2):
            self.list_registered_stdnt_instructor_sched.setColumnCount(2)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.list_registered_stdnt_instructor_sched.setHorizontalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.list_registered_stdnt_instructor_sched.setHorizontalHeaderItem(1, __qtablewidgetitem6)
        if (self.list_registered_stdnt_instructor_sched.rowCount() < 1):
            self.list_registered_stdnt_instructor_sched.setRowCount(1)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.list_registered_stdnt_instructor_sched.setVerticalHeaderItem(0, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.list_registered_stdnt_instructor_sched.setItem(0, 0, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.list_registered_stdnt_instructor_sched.setItem(0, 1, __qtablewidgetitem9)
        self.list_registered_stdnt_instructor_sched.setObjectName(u"list_registered_stdnt_instructor_sched")
        self.list_registered_stdnt_instructor_sched.setFont(font2)
        self.list_registered_stdnt_instructor_sched.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.list_registered_stdnt_instructor_sched.setFrameShadow(QFrame.Plain)
        self.list_registered_stdnt_instructor_sched.setEditTriggers(QAbstractItemView.AnyKeyPressed|QAbstractItemView.DoubleClicked|QAbstractItemView.EditKeyPressed|QAbstractItemView.SelectedClicked)
        self.list_registered_stdnt_instructor_sched.horizontalHeader().setDefaultSectionSize(130)

        self.verticalLayout_6.addWidget(self.list_registered_stdnt_instructor_sched)


        self.gridLayout.addLayout(self.verticalLayout_6, 2, 0, 1, 1)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label_58.setText(QCoreApplication.translate("Form", u"Accessed Room:", None))
        self.label_59.setText(QCoreApplication.translate("Form", u"Attendance Graph", None))
        self.label_57.setText(QCoreApplication.translate("Form", u"User Scanned:", None))
        ___qtablewidgetitem = self.list_attendance.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Form", u"Student Name", None));
        ___qtablewidgetitem1 = self.list_attendance.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Form", u"Student ID", None));
        ___qtablewidgetitem2 = self.list_attendance.verticalHeaderItem(0)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("Form", u"1.", None));

        __sortingEnabled = self.list_attendance.isSortingEnabled()
        self.list_attendance.setSortingEnabled(False)
        self.list_attendance.setSortingEnabled(__sortingEnabled)

        self.export_btn.setText(QCoreApplication.translate("Form", u"Export", None))
        self.label_17.setText(QCoreApplication.translate("Form", u"Registered Students", None))
        ___qtablewidgetitem3 = self.list_registered_stdnt_instructor_sched.horizontalHeaderItem(0)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("Form", u"Student Name", None));
        ___qtablewidgetitem4 = self.list_registered_stdnt_instructor_sched.horizontalHeaderItem(1)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("Form", u"Student ID", None));
        ___qtablewidgetitem5 = self.list_registered_stdnt_instructor_sched.verticalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("Form", u"1.", None));

        __sortingEnabled1 = self.list_registered_stdnt_instructor_sched.isSortingEnabled()
        self.list_registered_stdnt_instructor_sched.setSortingEnabled(False)
        self.list_registered_stdnt_instructor_sched.setSortingEnabled(__sortingEnabled1)

    # retranslateUi

