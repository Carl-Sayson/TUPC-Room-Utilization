# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Log_in.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QPushButton,
    QSizePolicy, QSpacerItem, QVBoxLayout, QWidget)
import tupc_bg_rc

class Ui_Log_In(object):
    def setupUi(self, Log_In):
        if not Log_In.objectName():
            Log_In.setObjectName(u"Log_In")
        Log_In.resize(1102, 668)
        Log_In.setStyleSheet(u"#centralwidget{\n"
"border-image: url(:/resources/tupc_bg_gradient.png);\n"
"}\n"
"\n"
"\n"
"\n"
"")
        self.centralwidget = QWidget(Log_In)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout_2 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.frame_3 = QFrame(self.centralwidget)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setMaximumSize(QSize(9999999, 140))
        self.frame_3.setStyleSheet(u"background: qlineargradient(\n"
"        x1: 0, y1: 0,\n"
"        x2: 1, y2: 0,\n"
"        stop: 0 #8B0000,\n"
"        stop: 0.5 #BB3F3F,\n"
"        stop: 1 #8B0000\n"
"    );\n"
"    border: none;\n"
"    padding: 0px;\n"
"")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame_3)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setHorizontalSpacing(0)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.title_screen = QLabel(self.frame_3)
        self.title_screen.setObjectName(u"title_screen")
        self.title_screen.setMinimumSize(QSize(1102, 58))
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(25)
        font.setBold(True)
        self.title_screen.setFont(font)
        self.title_screen.setStyleSheet(u"color: white;\n"
"font-family:  \"Sitka Small Semibold\";\n"
"    font-weight: bold;\n"
"    font-size: 25pt;\n"
"    border: none;\n"
"    background: transparent;")
        self.title_screen.setAlignment(Qt.AlignCenter)

        self.gridLayout.addWidget(self.title_screen, 0, 1, 1, 1)

        self.greetings = QLabel(self.frame_3)
        self.greetings.setObjectName(u"greetings")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(22)
        font1.setBold(True)
        self.greetings.setFont(font1)
        self.greetings.setStyleSheet(u"color: white;\n"
"font-family: \"Sitka Small Semibold\";\n"
"    font-weight: bold;\n"
"    font-size: 22pt;\n"
"    border: none;\n"
"    background: transparent;")

        self.gridLayout.addWidget(self.greetings, 1, 1, 1, 1, Qt.AlignHCenter)


        self.verticalLayout_2.addWidget(self.frame_3)

        self.frame_2 = QFrame(self.centralwidget)
        self.frame_2.setObjectName(u"frame_2")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_2.sizePolicy().hasHeightForWidth())
        self.frame_2.setSizePolicy(sizePolicy)
        self.frame_2.setMinimumSize(QSize(431, 550))
        self.frame_2.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.gridLayout_4 = QGridLayout(self.frame_2)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.verticalSpacer = QSpacerItem(17, 60, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.gridLayout_4.addItem(self.verticalSpacer, 1, 1, 1, 1)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_4.addItem(self.horizontalSpacer_3, 2, 0, 1, 1)

        self.frame_4 = QFrame(self.frame_2)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setMaximumSize(QSize(520, 420))
        self.frame_4.setStyleSheet(u"QFrame {\n"
"    \n"
"	\n"
"	\n"
"	\n"
"	\n"
"	background-color: rgb(202, 28, 34);\n"
"    border: 1px solid #dcdcdc;\n"
"    border-radius: 40px;\n"
"   \n"
"    \n"
"}\n"
"")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.gridLayout_3 = QGridLayout(self.frame_4)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.frame = QFrame(self.frame_4)
        self.frame.setObjectName(u"frame")
        self.frame.setMinimumSize(QSize(470, 341))
        self.frame.setMaximumSize(QSize(500, 400))
        self.frame.setStyleSheet(u"QFrame {\n"
"    background-color: #ffffff;\n"
"    border: 1px solid #dcdcdc;\n"
"    border-radius: 30px;\n"
"    padding: 20px;\n"
"    \n"
"}\n"
"")
        self.frame.setFrameShape(QFrame.NoFrame)
        self.frame.setFrameShadow(QFrame.Plain)
        self.gridLayout_2 = QGridLayout(self.frame)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.username = QLineEdit(self.frame)
        self.username.setObjectName(u"username")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(10)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.username.sizePolicy().hasHeightForWidth())
        self.username.setSizePolicy(sizePolicy1)
        self.username.setMaximumSize(QSize(700, 16777215))
        self.username.setBaseSize(QSize(2, 0))
        font2 = QFont()
        font2.setFamilies([u"Sitka Small"])
        font2.setBold(True)
        self.username.setFont(font2)
        self.username.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_2.addWidget(self.username)

        self.horizontalSpacer = QSpacerItem(88, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)


        self.verticalLayout_3.addLayout(self.horizontalLayout_2)


        self.gridLayout_2.addLayout(self.verticalLayout_3, 1, 0, 1, 1)

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.password = QLineEdit(self.frame)
        self.password.setObjectName(u"password")
        self.password.setBaseSize(QSize(2, 0))
        self.password.setFont(font2)
        self.password.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        self.password.setEchoMode(QLineEdit.Password)

        self.horizontalLayout.addWidget(self.password)

        self.show_new = QPushButton(self.frame)
        self.show_new.setObjectName(u"show_new")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.show_new.sizePolicy().hasHeightForWidth())
        self.show_new.setSizePolicy(sizePolicy2)
        self.show_new.setMaximumSize(QSize(88, 16777215))
        font3 = QFont()
        font3.setFamilies([u"Sitka Text Semibold"])
        font3.setPointSize(7)
        font3.setBold(True)
        self.show_new.setFont(font3)
        self.show_new.setStyleSheet(u"QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")
        icon = QIcon()
        icon.addFile(u"../../../../../../../Downloads/eye.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.show_new.setIcon(icon)
        self.show_new.setIconSize(QSize(0, 41))

        self.horizontalLayout.addWidget(self.show_new)


        self.verticalLayout_5.addLayout(self.horizontalLayout)


        self.gridLayout_2.addLayout(self.verticalLayout_5, 2, 0, 1, 1)

        self.login = QPushButton(self.frame)
        self.login.setObjectName(u"login")
        self.login.setBaseSize(QSize(75, 75))
        font4 = QFont()
        font4.setFamilies([u"Sitka Small Semibold"])
        font4.setPointSize(12)
        font4.setBold(True)
        font4.setItalic(True)
        self.login.setFont(font4)
        self.login.setMouseTracking(False)
        self.login.setAcceptDrops(False)
        self.login.setLayoutDirection(Qt.LeftToRight)
        self.login.setStyleSheet(u"QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout_2.addWidget(self.login, 3, 0, 1, 1, Qt.AlignHCenter)

        self.Login_lbl = QLabel(self.frame)
        self.Login_lbl.setObjectName(u"Login_lbl")
        self.Login_lbl.setMaximumSize(QSize(413, 85))
        font5 = QFont()
        font5.setFamilies([u"Sitka Small Semibold"])
        font5.setPointSize(18)
        font5.setBold(True)
        font5.setItalic(True)
        self.Login_lbl.setFont(font5)
        self.Login_lbl.setStyleSheet(u"\n"
"border: none;\n"
"    padding: 0px;\n"
"    margin: 0px;\n"
"    background: transparent;")
        self.Login_lbl.setAlignment(Qt.AlignCenter)

        self.gridLayout_2.addWidget(self.Login_lbl, 0, 0, 1, 1)


        self.gridLayout_3.addWidget(self.frame, 0, 0, 1, 1)


        self.gridLayout_4.addWidget(self.frame_4, 2, 1, 2, 1)

        self.horizontalSpacer_4 = QSpacerItem(283, 17, QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_4.addItem(self.horizontalSpacer_4, 3, 2, 1, 1)

        self.verticalSpacer_2 = QSpacerItem(20, 70, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.gridLayout_4.addItem(self.verticalSpacer_2, 4, 1, 1, 1)


        self.verticalLayout_2.addWidget(self.frame_2)

        Log_In.setCentralWidget(self.centralwidget)

        self.retranslateUi(Log_In)

        QMetaObject.connectSlotsByName(Log_In)
    # setupUi

    def retranslateUi(self, Log_In):
        Log_In.setWindowTitle(QCoreApplication.translate("Log_In", u"MainWindow", None))
        self.title_screen.setText(QCoreApplication.translate("Log_In", u"TUPC-ROOM UTILIZATION", None))
        self.greetings.setText(QCoreApplication.translate("Log_In", u"Greetings User!", None))
        self.username.setPlaceholderText(QCoreApplication.translate("Log_In", u"Username", None))
        self.password.setInputMask("")
        self.password.setText("")
        self.password.setPlaceholderText(QCoreApplication.translate("Log_In", u"Password", None))
        self.show_new.setText(QCoreApplication.translate("Log_In", u"Show", None))
        self.login.setText(QCoreApplication.translate("Log_In", u"Login", None))
#if QT_CONFIG(shortcut)
        self.login.setShortcut(QCoreApplication.translate("Log_In", u"Return", None))
#endif // QT_CONFIG(shortcut)
        self.Login_lbl.setText(QCoreApplication.translate("Log_In", u"Login into your Account", None))
    # retranslateUi

