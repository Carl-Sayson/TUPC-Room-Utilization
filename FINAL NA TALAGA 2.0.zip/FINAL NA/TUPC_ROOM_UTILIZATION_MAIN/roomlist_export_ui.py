# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'roomlist_export.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)
import tupc_bg_rc

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(714, 588)
        Dialog.setMinimumSize(QSize(714, 588))
        Dialog.setMaximumSize(QSize(714, 588))
        Dialog.setStyleSheet(u"#Dialog{\n"
"border-image: url(:/resources/tupc_bg.png);\n"
"}")
        self.gridLayout = QGridLayout(Dialog)
        self.gridLayout.setObjectName(u"gridLayout")
        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer_4)

        self.label_58 = QLabel(Dialog)
        self.label_58.setObjectName(u"label_58")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(True)
        self.label_58.setFont(font)
        self.label_58.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_2.addWidget(self.label_58, 0, Qt.AlignHCenter)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_2.addItem(self.verticalSpacer_5)

        self.label_8 = QLabel(Dialog)
        self.label_8.setObjectName(u"label_8")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(12)
        font1.setBold(True)
        font1.setItalic(True)
        self.label_8.setFont(font1)
        self.label_8.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_2.addWidget(self.label_8)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.chosen_room_download = QLineEdit(Dialog)
        self.chosen_room_download.setObjectName(u"chosen_room_download")
        self.chosen_room_download.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_4.addWidget(self.chosen_room_download)

        self.choose_btn_download = QPushButton(Dialog)
        self.choose_btn_download.setObjectName(u"choose_btn_download")
        self.choose_btn_download.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_4.addWidget(self.choose_btn_download)


        self.verticalLayout_2.addLayout(self.horizontalLayout_4)

        self.verticalSpacer_3 = QSpacerItem(20, 15, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_2.addItem(self.verticalSpacer_3)

        self.download_btn = QPushButton(Dialog)
        self.download_btn.setObjectName(u"download_btn")
        self.download_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_2.addWidget(self.download_btn, 0, Qt.AlignHCenter)

        self.verticalSpacer = QSpacerItem(20, 75, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer_2)


        self.gridLayout.addLayout(self.verticalLayout_2, 0, 0, 1, 1)

        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.label_56 = QLabel(Dialog)
        self.label_56.setObjectName(u"label_56")
        self.label_56.setFont(font)
        self.label_56.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.label_56.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.label_56)

        self.room_list = QListWidget(Dialog)
        self.room_list.setObjectName(u"room_list")
        self.room_list.setMinimumSize(QSize(351, 400))
        font2 = QFont()
        font2.setFamilies([u"Sitka Small"])
        font2.setBold(True)
        self.room_list.setFont(font2)
        self.room_list.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);\n"
"\n"
"QListWidget::item:selected {\n"
"    background-color: #0078d7; /* selection color */\n"
"    color: white;              /* text color on selection */\n"
"}\n"
"")

        self.verticalLayout_3.addWidget(self.room_list)


        self.gridLayout.addLayout(self.verticalLayout_3, 0, 1, 1, 1)

#if QT_CONFIG(shortcut)
        self.label_8.setBuddy(self.chosen_room_download)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label_58.setText(QCoreApplication.translate("Dialog", u"Download Schedule", None))
        self.label_8.setText(QCoreApplication.translate("Dialog", u"Choose Room:", None))
        self.choose_btn_download.setText(QCoreApplication.translate("Dialog", u"Choose", None))
        self.download_btn.setText(QCoreApplication.translate("Dialog", u"Download", None))
        self.label_56.setText(QCoreApplication.translate("Dialog", u"Room List", None))
    # retranslateUi

