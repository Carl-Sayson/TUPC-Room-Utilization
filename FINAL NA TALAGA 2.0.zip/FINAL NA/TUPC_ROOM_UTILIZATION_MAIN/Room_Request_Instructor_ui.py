# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Room_Request_Instructor.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QFrame, QGridLayout,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton,
    QSizePolicy, QStackedWidget, QTableWidget, QTableWidgetItem,
    QTimeEdit, QVBoxLayout, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(925, 720)
        Form.setMaximumSize(QSize(1200, 720))
        Form.setStyleSheet(u"QWidget {\n"
"        background: qlineargradient(\n"
"            x1: 0, y1: 0, x2: 0, y2: 1,\n"
"            stop: 0 #ffffff,    /* White at the top */\n"
"            stop: 1 #ff0000     /* Red at the bottom */\n"
"        );\n"
"    }")
        self.gridLayout = QGridLayout(Form)
        self.gridLayout.setObjectName(u"gridLayout")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label_48 = QLabel(Form)
        self.label_48.setObjectName(u"label_48")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(True)
        self.label_48.setFont(font)
        self.label_48.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout.addWidget(self.label_48)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label_8 = QLabel(Form)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font)
        self.label_8.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_5.addWidget(self.label_8)

        self.lineEdit = QLineEdit(Form)
        self.lineEdit.setObjectName(u"lineEdit")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(8)
        font1.setBold(True)
        font1.setItalic(True)
        self.lineEdit.setFont(font1)
        self.lineEdit.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_5.addWidget(self.lineEdit)

        self.choose_rm_btn = QPushButton(Form)
        self.choose_rm_btn.setObjectName(u"choose_rm_btn")
        self.choose_rm_btn.setFont(font1)
        self.choose_rm_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_5.addWidget(self.choose_rm_btn)


        self.verticalLayout.addLayout(self.horizontalLayout_5)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_5 = QLabel(Form)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font)
        self.label_5.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_3.addWidget(self.label_5)

        self.instructor_day_edit_comboBox = QComboBox(Form)
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.setObjectName(u"instructor_day_edit_comboBox")
        font2 = QFont()
        font2.setFamilies([u"Sitka Small Semibold"])
        font2.setBold(True)
        font2.setItalic(True)
        self.instructor_day_edit_comboBox.setFont(font2)
        self.instructor_day_edit_comboBox.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.horizontalLayout_3.addWidget(self.instructor_day_edit_comboBox)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setSpacing(7)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.label_6 = QLabel(Form)
        self.label_6.setObjectName(u"label_6")
        font3 = QFont()
        font3.setFamilies([u"Sitka Small Semibold"])
        font3.setPointSize(12)
        font3.setBold(True)
        font3.setItalic(True)
        self.label_6.setFont(font3)
        self.label_6.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_7.addWidget(self.label_6, 0, Qt.AlignHCenter)

        self.start_time_instructor = QTimeEdit(Form)
        self.start_time_instructor.setObjectName(u"start_time_instructor")
        self.start_time_instructor.setFont(font2)
        self.start_time_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.verticalLayout_7.addWidget(self.start_time_instructor)


        self.horizontalLayout_4.addLayout(self.verticalLayout_7)

        self.label_9 = QLabel(Form)
        self.label_9.setObjectName(u"label_9")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_9.sizePolicy().hasHeightForWidth())
        self.label_9.setSizePolicy(sizePolicy)
        font4 = QFont()
        font4.setPointSize(12)
        self.label_9.setFont(font4)
        self.label_9.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.label_9.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_4.addWidget(self.label_9)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setSpacing(7)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.label_7 = QLabel(Form)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setFont(font3)
        self.label_7.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_6.addWidget(self.label_7, 0, Qt.AlignHCenter)

        self.final_time_instructor = QTimeEdit(Form)
        self.final_time_instructor.setObjectName(u"final_time_instructor")
        self.final_time_instructor.setFont(font2)
        self.final_time_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.verticalLayout_6.addWidget(self.final_time_instructor)


        self.horizontalLayout_4.addLayout(self.verticalLayout_6)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.label_47 = QLabel(Form)
        self.label_47.setObjectName(u"label_47")
        font5 = QFont()
        font5.setFamilies([u"Sitka Small Semibold"])
        font5.setPointSize(10)
        font5.setBold(True)
        font5.setItalic(True)
        self.label_47.setFont(font5)
        self.label_47.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout.addWidget(self.label_47)

        self.room_request_instructor = QPlainTextEdit(Form)
        self.room_request_instructor.setObjectName(u"room_request_instructor")
        self.room_request_instructor.setMinimumSize(QSize(262, 388))
        font6 = QFont()
        font6.setFamilies([u"Sitka Small"])
        font6.setPointSize(9)
        font6.setBold(True)
        self.room_request_instructor.setFont(font6)
        self.room_request_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.room_request_instructor.setFrameShape(QFrame.Box)
        self.room_request_instructor.setFrameShadow(QFrame.Plain)
        self.room_request_instructor.setOverwriteMode(False)

        self.verticalLayout.addWidget(self.room_request_instructor)


        self.gridLayout.addLayout(self.verticalLayout, 0, 0, 1, 1)

        self.stackedWidget = QStackedWidget(Form)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setMinimumSize(QSize(392, 628))
        self.sched_view_for_request = QWidget()
        self.sched_view_for_request.setObjectName(u"sched_view_for_request")
        self.verticalLayout_2 = QVBoxLayout(self.sched_view_for_request)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.back = QPushButton(self.sched_view_for_request)
        self.back.setObjectName(u"back")
        self.back.setFont(font1)
        self.back.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_2.addWidget(self.back, 0, Qt.AlignLeft)

        self.instructor_room_sched_table_request = QTableWidget(self.sched_view_for_request)
        if (self.instructor_room_sched_table_request.columnCount() < 5):
            self.instructor_room_sched_table_request.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.instructor_room_sched_table_request.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.instructor_room_sched_table_request.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.instructor_room_sched_table_request.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.instructor_room_sched_table_request.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.instructor_room_sched_table_request.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.instructor_room_sched_table_request.setObjectName(u"instructor_room_sched_table_request")
        font7 = QFont()
        font7.setFamilies([u"Sitka Small"])
        font7.setBold(True)
        self.instructor_room_sched_table_request.setFont(font7)
        self.instructor_room_sched_table_request.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.verticalLayout_2.addWidget(self.instructor_room_sched_table_request)

        self.stackedWidget.addWidget(self.sched_view_for_request)
        self.list_rooms_request_instructor = QWidget()
        self.list_rooms_request_instructor.setObjectName(u"list_rooms_request_instructor")
        self.gridLayout_2 = QGridLayout(self.list_rooms_request_instructor)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.room_list_request_instructor = QListWidget(self.list_rooms_request_instructor)
        self.room_list_request_instructor.setObjectName(u"room_list_request_instructor")
        self.room_list_request_instructor.setFont(font7)
        self.room_list_request_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);\n"
"\n"
"QListWidget::item:selected {\n"
"    background-color: #0078d7; /* selection color */\n"
"    color: white;              /* text color on selection */\n"
"}\n"
"")

        self.gridLayout_2.addWidget(self.room_list_request_instructor, 1, 0, 1, 2)

        self.view_room = QPushButton(self.list_rooms_request_instructor)
        self.view_room.setObjectName(u"view_room")
        font8 = QFont()
        font8.setFamilies([u"Sitka Small Semibold"])
        font8.setPointSize(10)
        font8.setBold(True)
        font8.setItalic(False)
        self.view_room.setFont(font8)
        self.view_room.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout_2.addWidget(self.view_room, 2, 0, 1, 1, Qt.AlignLeft)

        self.send_btn_composed_request_instructor = QPushButton(self.list_rooms_request_instructor)
        self.send_btn_composed_request_instructor.setObjectName(u"send_btn_composed_request_instructor")
        self.send_btn_composed_request_instructor.setFont(font8)
        self.send_btn_composed_request_instructor.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout_2.addWidget(self.send_btn_composed_request_instructor, 2, 1, 1, 1, Qt.AlignRight)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.sort_room = QComboBox(self.list_rooms_request_instructor)
        self.sort_room.addItem("")
        self.sort_room.addItem("")
        self.sort_room.setObjectName(u"sort_room")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.sort_room.sizePolicy().hasHeightForWidth())
        self.sort_room.setSizePolicy(sizePolicy1)
        self.sort_room.setMaximumSize(QSize(70, 16777215))
        self.sort_room.setFont(font2)
        self.sort_room.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.horizontalLayout_19.addWidget(self.sort_room)

        self.search_bar_room_request_instructor = QLineEdit(self.list_rooms_request_instructor)
        self.search_bar_room_request_instructor.setObjectName(u"search_bar_room_request_instructor")
        self.search_bar_room_request_instructor.setFont(font7)
        self.search_bar_room_request_instructor.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_19.addWidget(self.search_bar_room_request_instructor)

        self.search_room_request_instructor_btn = QPushButton(self.list_rooms_request_instructor)
        self.search_room_request_instructor_btn.setObjectName(u"search_room_request_instructor_btn")
        self.search_room_request_instructor_btn.setFont(font1)
        self.search_room_request_instructor_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_19.addWidget(self.search_room_request_instructor_btn)


        self.gridLayout_2.addLayout(self.horizontalLayout_19, 0, 0, 1, 2)

        self.stackedWidget.addWidget(self.list_rooms_request_instructor)

        self.gridLayout.addWidget(self.stackedWidget, 0, 1, 1, 1)


        self.retranslateUi(Form)

        self.stackedWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Dialog", None))
        self.label_48.setText(QCoreApplication.translate("Form", u"Room Request:", None))
        self.label_8.setText(QCoreApplication.translate("Form", u"Choose Room:", None))
#if QT_CONFIG(tooltip)
        self.choose_rm_btn.setToolTip(QCoreApplication.translate("Form", u"Choose", None))
#endif // QT_CONFIG(tooltip)
        self.choose_rm_btn.setText(QCoreApplication.translate("Form", u"Choose", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"Choose Day:", None))
        self.instructor_day_edit_comboBox.setItemText(0, QCoreApplication.translate("Form", u"Monday", None))
        self.instructor_day_edit_comboBox.setItemText(1, QCoreApplication.translate("Form", u"Tuesday", None))
        self.instructor_day_edit_comboBox.setItemText(2, QCoreApplication.translate("Form", u"Wednesday", None))
        self.instructor_day_edit_comboBox.setItemText(3, QCoreApplication.translate("Form", u"Thursday", None))
        self.instructor_day_edit_comboBox.setItemText(4, QCoreApplication.translate("Form", u"Friday", None))

        self.label_6.setText(QCoreApplication.translate("Form", u"Start of Class", None))
        self.label_9.setText(QCoreApplication.translate("Form", u":", None))
        self.label_7.setText(QCoreApplication.translate("Form", u"End of Class", None))
        self.label_47.setText(QCoreApplication.translate("Form", u"Message:", None))
        self.room_request_instructor.setPlainText("")
#if QT_CONFIG(tooltip)
        self.back.setToolTip(QCoreApplication.translate("Form", u"Back", None))
#endif // QT_CONFIG(tooltip)
        self.back.setText(QCoreApplication.translate("Form", u"Back", None))
        ___qtablewidgetitem = self.instructor_room_sched_table_request.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Form", u"Monday", None));
        ___qtablewidgetitem1 = self.instructor_room_sched_table_request.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Form", u"Tuesday", None));
        ___qtablewidgetitem2 = self.instructor_room_sched_table_request.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("Form", u"Wednesday", None));
        ___qtablewidgetitem3 = self.instructor_room_sched_table_request.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("Form", u"Thursday", None));
        ___qtablewidgetitem4 = self.instructor_room_sched_table_request.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("Form", u"Friday", None));
#if QT_CONFIG(tooltip)
        self.view_room.setToolTip(QCoreApplication.translate("Form", u"Send", None))
#endif // QT_CONFIG(tooltip)
        self.view_room.setText(QCoreApplication.translate("Form", u"View", None))
#if QT_CONFIG(tooltip)
        self.send_btn_composed_request_instructor.setToolTip(QCoreApplication.translate("Form", u"Send", None))
#endif // QT_CONFIG(tooltip)
        self.send_btn_composed_request_instructor.setText(QCoreApplication.translate("Form", u"Send", None))
        self.sort_room.setItemText(0, QCoreApplication.translate("Form", u"A-Z", None))
        self.sort_room.setItemText(1, QCoreApplication.translate("Form", u"Z-A", None))

#if QT_CONFIG(tooltip)
        self.search_room_request_instructor_btn.setToolTip(QCoreApplication.translate("Form", u"Search", None))
#endif // QT_CONFIG(tooltip)
        self.search_room_request_instructor_btn.setText(QCoreApplication.translate("Form", u"Search", None))
    # retranslateUi

