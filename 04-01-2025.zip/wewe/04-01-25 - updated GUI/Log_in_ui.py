# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Log_in.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QPushButton,
    QSizePolicy, QSpacerItem, QVBoxLayout, QWidget)

class Ui_Log_In(object):
    def setupUi(self, Log_In):
        if not Log_In.objectName():
            Log_In.setObjectName(u"Log_In")
        Log_In.resize(691, 785)
        Log_In.setStyleSheet(u"QWidget {\n"
"        background: qlineargradient(\n"
"            x1: 0, y1: 0, x2: 0, y2: 1,\n"
"            stop: 0 #ffffff,    /* White at the top */\n"
"            stop: 1 #ff0000     /* Red at the bottom */\n"
"        );\n"
"    }")
        self.centralwidget = QWidget(Log_In)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout_3 = QGridLayout(self.centralwidget)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.frame_3 = QFrame(self.centralwidget)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame_3)
        self.gridLayout.setObjectName(u"gridLayout")
        self.widget = QWidget(self.frame_3)
        self.widget.setObjectName(u"widget")
        self.widget.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.title_screen = QLabel(self.widget)
        self.title_screen.setObjectName(u"title_screen")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(26)
        font.setBold(True)
        font.setItalic(True)
        self.title_screen.setFont(font)
        self.title_screen.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.title_screen.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.title_screen)

        self.greetings = QLabel(self.widget)
        self.greetings.setObjectName(u"greetings")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(18)
        font1.setBold(True)
        font1.setItalic(True)
        self.greetings.setFont(font1)
        self.greetings.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout.addWidget(self.greetings, 0, Qt.AlignHCenter)


        self.gridLayout.addWidget(self.widget, 0, 0, 1, 1)


        self.gridLayout_3.addWidget(self.frame_3, 0, 0, 1, 2)

        self.frame_2 = QFrame(self.centralwidget)
        self.frame_2.setObjectName(u"frame_2")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_2.sizePolicy().hasHeightForWidth())
        self.frame_2.setSizePolicy(sizePolicy)
        self.frame_2.setMinimumSize(QSize(431, 550))
        self.frame_2.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.gridLayout_4 = QGridLayout(self.frame_2)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.verticalSpacer = QSpacerItem(20, 38, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.gridLayout_4.addItem(self.verticalSpacer, 1, 1, 1, 1)

        self.Login_lbl = QLabel(self.frame_2)
        self.Login_lbl.setObjectName(u"Login_lbl")
        self.Login_lbl.setFont(font1)
        self.Login_lbl.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.Login_lbl.setAlignment(Qt.AlignCenter)

        self.gridLayout_4.addWidget(self.Login_lbl, 0, 1, 1, 1)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_4.addItem(self.horizontalSpacer_3, 3, 0, 1, 1)

        self.gridLayout_2 = QGridLayout()
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.login = QPushButton(self.frame_2)
        self.login.setObjectName(u"login")
        self.login.setBaseSize(QSize(75, 75))
        font2 = QFont()
        font2.setFamilies([u"Sitka Small Semibold"])
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setItalic(True)
        self.login.setFont(font2)
        self.login.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 10px 30px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")
        self.login.setIconSize(QSize(20, 20))

        self.gridLayout_2.addWidget(self.login, 1, 0, 1, 1, Qt.AlignHCenter)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.pass_lbl_2 = QLabel(self.frame_2)
        self.pass_lbl_2.setObjectName(u"pass_lbl_2")
        font3 = QFont()
        font3.setFamilies([u"Sitka Small Semibold"])
        font3.setPointSize(10)
        font3.setBold(True)
        font3.setItalic(True)
        self.pass_lbl_2.setFont(font3)
        self.pass_lbl_2.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.pass_lbl_2.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.verticalLayout_3.addWidget(self.pass_lbl_2)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.username = QLineEdit(self.frame_2)
        self.username.setObjectName(u"username")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(2)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.username.sizePolicy().hasHeightForWidth())
        self.username.setSizePolicy(sizePolicy1)
        self.username.setMaximumSize(QSize(700, 16777215))
        self.username.setBaseSize(QSize(2, 0))
        font4 = QFont()
        font4.setFamilies([u"Sitka Small"])
        font4.setBold(True)
        self.username.setFont(font4)
        self.username.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_2.addWidget(self.username)

        self.horizontalSpacer = QSpacerItem(88, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)


        self.verticalLayout_3.addLayout(self.horizontalLayout_2)


        self.verticalLayout_4.addLayout(self.verticalLayout_3)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.pass_lbl = QLabel(self.frame_2)
        self.pass_lbl.setObjectName(u"pass_lbl")
        self.pass_lbl.setFont(font3)
        self.pass_lbl.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.pass_lbl.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.verticalLayout_2.addWidget(self.pass_lbl)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.password = QLineEdit(self.frame_2)
        self.password.setObjectName(u"password")
        self.password.setBaseSize(QSize(2, 0))
        self.password.setFont(font4)
        self.password.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);\n"
"border: 1px solid #000000;  /* Black border */\n"
"       border-radius: 15px;        /* Curved edges */")
        self.password.setEchoMode(QLineEdit.Password)

        self.horizontalLayout.addWidget(self.password)

        self.show_password = QPushButton(self.frame_2)
        self.show_password.setObjectName(u"show_password")
        self.show_password.setStyleSheet(u"")
        icon = QIcon()
        icon.addFile(u"../png/Showw.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.show_password.setIcon(icon)
        self.show_password.setIconSize(QSize(29, 19))

        self.horizontalLayout.addWidget(self.show_password)


        self.verticalLayout_2.addLayout(self.horizontalLayout)


        self.verticalLayout_4.addLayout(self.verticalLayout_2)


        self.gridLayout_2.addLayout(self.verticalLayout_4, 0, 0, 1, 1)


        self.gridLayout_4.addLayout(self.gridLayout_2, 3, 1, 1, 1)

        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_4.addItem(self.horizontalSpacer_4, 3, 2, 1, 1)

        self.verticalSpacer_2 = QSpacerItem(20, 200, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.gridLayout_4.addItem(self.verticalSpacer_2, 4, 1, 1, 1)


        self.gridLayout_3.addWidget(self.frame_2, 1, 0, 1, 2)

        Log_In.setCentralWidget(self.centralwidget)

        self.retranslateUi(Log_In)

        QMetaObject.connectSlotsByName(Log_In)
    # setupUi

    def retranslateUi(self, Log_In):
        Log_In.setWindowTitle(QCoreApplication.translate("Log_In", u"MainWindow", None))
#if QT_CONFIG(tooltip)
        self.title_screen.setToolTip(QCoreApplication.translate("Log_In", u"TUPC - ROOM UTILIZATION", None))
#endif // QT_CONFIG(tooltip)
        self.title_screen.setText(QCoreApplication.translate("Log_In", u"TUPC - ROOM UTILIZATION", None))
        self.greetings.setText(QCoreApplication.translate("Log_In", u"Greetings", None))
        self.Login_lbl.setText(QCoreApplication.translate("Log_In", u"Login into your Account", None))
#if QT_CONFIG(tooltip)
        self.login.setToolTip(QCoreApplication.translate("Log_In", u"Login", None))
#endif // QT_CONFIG(tooltip)
        self.login.setText(QCoreApplication.translate("Log_In", u"Login", None))
        self.pass_lbl_2.setText(QCoreApplication.translate("Log_In", u"Username", None))
#if QT_CONFIG(statustip)
        self.username.setStatusTip("")
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(accessibility)
        self.username.setAccessibleName("")
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(accessibility)
        self.username.setAccessibleDescription("")
#endif // QT_CONFIG(accessibility)
        self.username.setPlaceholderText(QCoreApplication.translate("Log_In", u"username", None))
        self.pass_lbl.setText(QCoreApplication.translate("Log_In", u"Password", None))
        self.password.setPlaceholderText(QCoreApplication.translate("Log_In", u"password", None))
#if QT_CONFIG(tooltip)
        self.show_password.setToolTip(QCoreApplication.translate("Log_In", u"unhide", None))
#endif // QT_CONFIG(tooltip)
        self.show_password.setText("")
    # retranslateUi

