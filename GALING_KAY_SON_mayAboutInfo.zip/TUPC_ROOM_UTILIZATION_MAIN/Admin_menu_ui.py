# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Admin_menu.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QAbstractScrollArea, QApplication, QComboBox,
    QFrame, QGridLayout, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMainWindow, QMenu, QMenuBar, QPlainTextEdit,
    QPushButton, QSizePolicy, QSpacerItem, QStackedWidget,
    QTabWidget, QTableWidget, QTableWidgetItem, QTimeEdit,
    QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1040, 847)
        MainWindow.setStyleSheet(u"QWidget {\n"
"        background: qlineargradient(\n"
"            x1: 0, y1: 0, x2: 0, y2: 1,\n"
"            stop: 0 #ffffff,    /* White at the top */\n"
"            stop: 1 #ff0000     /* Red at the bottom */\n"
"        );\n"
"    }")
        self.actionRoom_Schedule = QAction(MainWindow)
        self.actionRoom_Schedule.setObjectName(u"actionRoom_Schedule")
        self.actionSections = QAction(MainWindow)
        self.actionSections.setObjectName(u"actionSections")
        self.actionRoom_logs = QAction(MainWindow)
        self.actionRoom_logs.setObjectName(u"actionRoom_logs")
        self.actionRegister_Instructor = QAction(MainWindow)
        self.actionRegister_Instructor.setObjectName(u"actionRegister_Instructor")
        self.actionRegister_Student = QAction(MainWindow)
        self.actionRegister_Student.setObjectName(u"actionRegister_Student")
        self.actionRegister_Staff = QAction(MainWindow)
        self.actionRegister_Staff.setObjectName(u"actionRegister_Staff")
        self.actionRoom_Request = QAction(MainWindow)
        self.actionRoom_Request.setObjectName(u"actionRoom_Request")
        self.actionMaintenance_Damage_Report = QAction(MainWindow)
        self.actionMaintenance_Damage_Report.setObjectName(u"actionMaintenance_Damage_Report")
        self.actionAdd_Schedule = QAction(MainWindow)
        self.actionAdd_Schedule.setObjectName(u"actionAdd_Schedule")
        self.actionEdit_Schedule = QAction(MainWindow)
        self.actionEdit_Schedule.setObjectName(u"actionEdit_Schedule")
        self.actionInstructor = QAction(MainWindow)
        self.actionInstructor.setObjectName(u"actionInstructor")
        self.actionStudent = QAction(MainWindow)
        self.actionStudent.setObjectName(u"actionStudent")
        self.actionStaff = QAction(MainWindow)
        self.actionStaff.setObjectName(u"actionStaff")
        self.actionInstructor_2 = QAction(MainWindow)
        self.actionInstructor_2.setObjectName(u"actionInstructor_2")
        self.actionStudent_2 = QAction(MainWindow)
        self.actionStudent_2.setObjectName(u"actionStudent_2")
        self.actionStaff_2 = QAction(MainWindow)
        self.actionStaff_2.setObjectName(u"actionStaff_2")
        self.actionInstructor_3 = QAction(MainWindow)
        self.actionInstructor_3.setObjectName(u"actionInstructor_3")
        self.actionStudent_3 = QAction(MainWindow)
        self.actionStudent_3.setObjectName(u"actionStudent_3")
        self.actionStaff_3 = QAction(MainWindow)
        self.actionStaff_3.setObjectName(u"actionStaff_3")
        self.actionAdd_Section = QAction(MainWindow)
        self.actionAdd_Section.setObjectName(u"actionAdd_Section")
        self.actionRoom_Request_2 = QAction(MainWindow)
        self.actionRoom_Request_2.setObjectName(u"actionRoom_Request_2")
        self.actionMaintenance_Damage_Report_2 = QAction(MainWindow)
        self.actionMaintenance_Damage_Report_2.setObjectName(u"actionMaintenance_Damage_Report_2")
        self.actionAbout = QAction(MainWindow)
        self.actionAbout.setObjectName(u"actionAbout")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout_7 = QGridLayout(self.centralwidget)
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        font = QFont()
        font.setFamilies([u"Sitka Small Semibold"])
        font.setPointSize(10)
        font.setBold(True)
        font.setItalic(True)
        self.frame.setFont(font)
        self.frame.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        font1 = QFont()
        font1.setFamilies([u"Sitka Small Semibold"])
        font1.setPointSize(20)
        font1.setBold(True)
        font1.setItalic(True)
        self.label.setFont(font1)

        self.verticalLayout_2.addWidget(self.label)

        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        font2 = QFont()
        font2.setFamilies([u"Sitka Small Semibold"])
        font2.setPointSize(16)
        font2.setBold(True)
        font2.setItalic(True)
        self.label_2.setFont(font2)

        self.verticalLayout_2.addWidget(self.label_2)


        self.gridLayout.addLayout(self.verticalLayout_2, 0, 0, 1, 1)


        self.verticalLayout_3.addWidget(self.frame)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.room_btn = QPushButton(self.centralwidget)
        self.room_btn.setObjectName(u"room_btn")
        self.room_btn.setMinimumSize(QSize(100, 40))
        font3 = QFont()
        font3.setFamilies([u"Sitka Small Semibold"])
        font3.setPointSize(12)
        font3.setBold(True)
        font3.setItalic(True)
        self.room_btn.setFont(font3)
        self.room_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.room_btn)

        self.instructor_btn = QPushButton(self.centralwidget)
        self.instructor_btn.setObjectName(u"instructor_btn")
        self.instructor_btn.setMinimumSize(QSize(100, 40))
        self.instructor_btn.setFont(font3)
        self.instructor_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.instructor_btn)

        self.student_btn = QPushButton(self.centralwidget)
        self.student_btn.setObjectName(u"student_btn")
        self.student_btn.setMinimumSize(QSize(100, 40))
        self.student_btn.setFont(font3)
        self.student_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.student_btn)

        self.staff_btn = QPushButton(self.centralwidget)
        self.staff_btn.setObjectName(u"staff_btn")
        self.staff_btn.setMinimumSize(QSize(100, 40))
        self.staff_btn.setFont(font3)
        self.staff_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.staff_btn)

        self.inbox_btn = QPushButton(self.centralwidget)
        self.inbox_btn.setObjectName(u"inbox_btn")
        self.inbox_btn.setMinimumSize(QSize(100, 40))
        self.inbox_btn.setFont(font3)
        self.inbox_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout.addWidget(self.inbox_btn)


        self.verticalLayout_3.addLayout(self.verticalLayout)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer)

        self.logout_btn = QPushButton(self.centralwidget)
        self.logout_btn.setObjectName(u"logout_btn")
        self.logout_btn.setMinimumSize(QSize(100, 40))
        self.logout_btn.setFont(font3)
        self.logout_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_3.addWidget(self.logout_btn)


        self.gridLayout_7.addLayout(self.verticalLayout_3, 0, 0, 1, 1)

        self.stackedWidget = QStackedWidget(self.centralwidget)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setMinimumSize(QSize(832, 720))
        self.stackedWidgetPage1 = QWidget()
        self.stackedWidgetPage1.setObjectName(u"stackedWidgetPage1")
        self.gridLayout_2 = QGridLayout(self.stackedWidgetPage1)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.schedule_stackedwidget = QStackedWidget(self.stackedWidgetPage1)
        self.schedule_stackedwidget.setObjectName(u"schedule_stackedwidget")
        self.schedule_stackedwidget.setMinimumSize(QSize(579, 589))
        self.schedule_stackedwidgetPage1_2 = QWidget()
        self.schedule_stackedwidgetPage1_2.setObjectName(u"schedule_stackedwidgetPage1_2")
        self.gridLayout_3 = QGridLayout(self.schedule_stackedwidgetPage1_2)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.verticalLayout_58 = QVBoxLayout()
        self.verticalLayout_58.setObjectName(u"verticalLayout_58")
        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.label_3 = QLabel(self.schedule_stackedwidgetPage1_2)
        self.label_3.setObjectName(u"label_3")
        font4 = QFont()
        font4.setFamilies([u"Sitka Small Semibold"])
        font4.setPointSize(14)
        font4.setBold(True)
        font4.setItalic(True)
        self.label_3.setFont(font4)
        self.label_3.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_4.addWidget(self.label_3)


        self.verticalLayout_58.addLayout(self.verticalLayout_4)

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_5.addItem(self.verticalSpacer_3)

        self.add_rm = QPushButton(self.schedule_stackedwidgetPage1_2)
        self.add_rm.setObjectName(u"add_rm")
        self.add_rm.setMinimumSize(QSize(100, 40))
        self.add_rm.setFont(font3)
        self.add_rm.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_5.addWidget(self.add_rm)

        self.del_rm = QPushButton(self.schedule_stackedwidgetPage1_2)
        self.del_rm.setObjectName(u"del_rm")
        self.del_rm.setMinimumSize(QSize(100, 40))
        self.del_rm.setFont(font3)
        self.del_rm.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_5.addWidget(self.del_rm)

        self.edit_rm = QPushButton(self.schedule_stackedwidgetPage1_2)
        self.edit_rm.setObjectName(u"edit_rm")
        self.edit_rm.setMinimumSize(QSize(100, 40))
        self.edit_rm.setFont(font3)
        self.edit_rm.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_5.addWidget(self.edit_rm)

        self.view_sched = QPushButton(self.schedule_stackedwidgetPage1_2)
        self.view_sched.setObjectName(u"view_sched")
        self.view_sched.setMinimumSize(QSize(100, 40))
        self.view_sched.setFont(font3)
        self.view_sched.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_5.addWidget(self.view_sched)

        self.log_rm = QPushButton(self.schedule_stackedwidgetPage1_2)
        self.log_rm.setObjectName(u"log_rm")
        self.log_rm.setMinimumSize(QSize(100, 40))
        self.log_rm.setFont(font3)
        self.log_rm.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_5.addWidget(self.log_rm)


        self.verticalLayout_58.addLayout(self.verticalLayout_5)

        self.verticalSpacer_2 = QSpacerItem(20, 394, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_58.addItem(self.verticalSpacer_2)


        self.gridLayout_3.addLayout(self.verticalLayout_58, 0, 0, 2, 1)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.horizontalSpacer_14 = QSpacerItem(276, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_19.addItem(self.horizontalSpacer_14)

        self.sort_room = QComboBox(self.schedule_stackedwidgetPage1_2)
        self.sort_room.addItem("")
        self.sort_room.addItem("")
        self.sort_room.setObjectName(u"sort_room")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.sort_room.sizePolicy().hasHeightForWidth())
        self.sort_room.setSizePolicy(sizePolicy)
        self.sort_room.setMaximumSize(QSize(70, 16777215))
        font5 = QFont()
        font5.setFamilies([u"Sitka Small Semibold"])
        font5.setPointSize(9)
        font5.setBold(True)
        font5.setItalic(False)
        self.sort_room.setFont(font5)
        self.sort_room.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.horizontalLayout_19.addWidget(self.sort_room)

        self.search_bar_room = QLineEdit(self.schedule_stackedwidgetPage1_2)
        self.search_bar_room.setObjectName(u"search_bar_room")
        font6 = QFont()
        font6.setFamilies([u"Sitka Small"])
        font6.setPointSize(9)
        font6.setBold(True)
        self.search_bar_room.setFont(font6)
        self.search_bar_room.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_19.addWidget(self.search_bar_room)

        self.search_room_btn = QPushButton(self.schedule_stackedwidgetPage1_2)
        self.search_room_btn.setObjectName(u"search_room_btn")
        self.search_room_btn.setFont(font3)
        self.search_room_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_19.addWidget(self.search_room_btn)


        self.horizontalLayout_6.addLayout(self.horizontalLayout_19)


        self.gridLayout_3.addLayout(self.horizontalLayout_6, 0, 1, 1, 1)

        self.room_list = QListWidget(self.schedule_stackedwidgetPage1_2)
        self.room_list.setObjectName(u"room_list")
        self.room_list.setMinimumSize(QSize(621, 637))
        font7 = QFont()
        font7.setFamilies([u"Sitka Small"])
        font7.setBold(True)
        self.room_list.setFont(font7)
        self.room_list.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.gridLayout_3.addWidget(self.room_list, 1, 1, 1, 1)

        self.schedule_stackedwidget.addWidget(self.schedule_stackedwidgetPage1_2)
        self.schedule_stackedwidgetPage2_2 = QWidget()
        self.schedule_stackedwidgetPage2_2.setObjectName(u"schedule_stackedwidgetPage2_2")
        self.verticalLayout_64 = QVBoxLayout(self.schedule_stackedwidgetPage2_2)
        self.verticalLayout_64.setObjectName(u"verticalLayout_64")
        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.back = QPushButton(self.schedule_stackedwidgetPage2_2)
        self.back.setObjectName(u"back")
        self.back.setFont(font3)
        self.back.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_15.addWidget(self.back)

        self.label_57 = QLabel(self.schedule_stackedwidgetPage2_2)
        self.label_57.setObjectName(u"label_57")
        self.label_57.setFont(font4)
        self.label_57.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_15.addWidget(self.label_57)

        self.accessed_room_sched_lineedit = QLineEdit(self.schedule_stackedwidgetPage2_2)
        self.accessed_room_sched_lineedit.setObjectName(u"accessed_room_sched_lineedit")
        self.accessed_room_sched_lineedit.setFont(font6)
        self.accessed_room_sched_lineedit.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        self.accessed_room_sched_lineedit.setReadOnly(True)

        self.horizontalLayout_15.addWidget(self.accessed_room_sched_lineedit)

        self.horizontalSpacer_27 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_15.addItem(self.horizontalSpacer_27)


        self.verticalLayout_64.addLayout(self.horizontalLayout_15)

        self.room_sched_table = QTableWidget(self.schedule_stackedwidgetPage2_2)
        if (self.room_sched_table.columnCount() < 5):
            self.room_sched_table.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.room_sched_table.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.room_sched_table.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.room_sched_table.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.room_sched_table.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.room_sched_table.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.room_sched_table.setObjectName(u"room_sched_table")
        self.room_sched_table.setFont(font7)
        self.room_sched_table.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.verticalLayout_64.addWidget(self.room_sched_table)

        self.schedule_stackedwidget.addWidget(self.schedule_stackedwidgetPage2_2)
        self.schedule_stackedwidgetPage3_2 = QWidget()
        self.schedule_stackedwidgetPage3_2.setObjectName(u"schedule_stackedwidgetPage3_2")
        self.gridLayout_4 = QGridLayout(self.schedule_stackedwidgetPage3_2)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.edit_room_sched_table = QTableWidget(self.schedule_stackedwidgetPage3_2)
        if (self.edit_room_sched_table.columnCount() < 5):
            self.edit_room_sched_table.setColumnCount(5)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.edit_room_sched_table.setHorizontalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.edit_room_sched_table.setHorizontalHeaderItem(1, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.edit_room_sched_table.setHorizontalHeaderItem(2, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.edit_room_sched_table.setHorizontalHeaderItem(3, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.edit_room_sched_table.setHorizontalHeaderItem(4, __qtablewidgetitem9)
        self.edit_room_sched_table.setObjectName(u"edit_room_sched_table")
        self.edit_room_sched_table.setMinimumSize(QSize(351, 676))
        self.edit_room_sched_table.setMaximumSize(QSize(90000, 90000))
        self.edit_room_sched_table.setFont(font7)
        self.edit_room_sched_table.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.gridLayout_4.addWidget(self.edit_room_sched_table, 1, 3, 5, 1)

        self.verticalLayout_9 = QVBoxLayout()
        self.verticalLayout_9.setSpacing(10)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.horizontalLayout_21 = QHBoxLayout()
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.label_50 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_50.setObjectName(u"label_50")
        self.label_50.setFont(font4)
        self.label_50.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_21.addWidget(self.label_50)

        self.assign_staff = QLineEdit(self.schedule_stackedwidgetPage3_2)
        self.assign_staff.setObjectName(u"assign_staff")
        self.assign_staff.setMaximumSize(QSize(600, 16777215))
        self.assign_staff.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_21.addWidget(self.assign_staff)


        self.verticalLayout_9.addLayout(self.horizontalLayout_21)

        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.label_49 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_49.setObjectName(u"label_49")
        self.label_49.setFont(font4)
        self.label_49.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_20.addWidget(self.label_49)

        self.assign_maintenance = QLineEdit(self.schedule_stackedwidgetPage3_2)
        self.assign_maintenance.setObjectName(u"assign_maintenance")
        self.assign_maintenance.setMaximumSize(QSize(600, 16777215))
        self.assign_maintenance.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_20.addWidget(self.assign_maintenance)


        self.verticalLayout_9.addLayout(self.horizontalLayout_20)

        self.verticalSpacer_18 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_9.addItem(self.verticalSpacer_18)

        self.horizontalLayout_22 = QHBoxLayout()
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.horizontalSpacer_17 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_22.addItem(self.horizontalSpacer_17)

        self.label_51 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_51.setObjectName(u"label_51")
        self.label_51.setFont(font4)
        self.label_51.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_22.addWidget(self.label_51)

        self.day_edit_staff = QComboBox(self.schedule_stackedwidgetPage3_2)
        self.day_edit_staff.addItem("")
        self.day_edit_staff.addItem("")
        self.day_edit_staff.addItem("")
        self.day_edit_staff.addItem("")
        self.day_edit_staff.addItem("")
        self.day_edit_staff.setObjectName(u"day_edit_staff")
        self.day_edit_staff.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.horizontalLayout_22.addWidget(self.day_edit_staff)

        self.horizontalSpacer_18 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_22.addItem(self.horizontalSpacer_18)


        self.verticalLayout_9.addLayout(self.horizontalLayout_22)

        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.horizontalSpacer_19 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer_19)

        self.verticalLayout_10 = QVBoxLayout()
        self.verticalLayout_10.setSpacing(7)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.label_52 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_52.setObjectName(u"label_52")
        self.label_52.setFont(font3)
        self.label_52.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_10.addWidget(self.label_52)

        self.start_time_staff = QTimeEdit(self.schedule_stackedwidgetPage3_2)
        self.start_time_staff.setObjectName(u"start_time_staff")
        self.start_time_staff.setStyleSheet(u"color: rgb(15, 15, 15);\n"
"background-color: rgb(255, 255, 255);")

        self.verticalLayout_10.addWidget(self.start_time_staff)


        self.horizontalLayout_23.addLayout(self.verticalLayout_10)

        self.horizontalSpacer_20 = QSpacerItem(20, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer_20)

        self.label_53 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_53.setObjectName(u"label_53")
        font8 = QFont()
        font8.setPointSize(12)
        self.label_53.setFont(font8)
        self.label_53.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.label_53.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_23.addWidget(self.label_53)

        self.horizontalSpacer_21 = QSpacerItem(20, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer_21)

        self.verticalLayout_59 = QVBoxLayout()
        self.verticalLayout_59.setSpacing(7)
        self.verticalLayout_59.setObjectName(u"verticalLayout_59")
        self.label_54 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_54.setObjectName(u"label_54")
        self.label_54.setFont(font3)
        self.label_54.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_59.addWidget(self.label_54)

        self.final_time_staff = QTimeEdit(self.schedule_stackedwidgetPage3_2)
        self.final_time_staff.setObjectName(u"final_time_staff")
        self.final_time_staff.setStyleSheet(u"color: rgb(15, 15, 15);\n"
"background-color: rgb(255, 255, 255);")

        self.verticalLayout_59.addWidget(self.final_time_staff)


        self.horizontalLayout_23.addLayout(self.verticalLayout_59)

        self.horizontalSpacer_22 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer_22)


        self.verticalLayout_9.addLayout(self.horizontalLayout_23)

        self.verticalSpacer_5 = QSpacerItem(20, 60, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_9.addItem(self.verticalSpacer_5)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.remove_staff_sched = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.remove_staff_sched.setObjectName(u"remove_staff_sched")
        self.remove_staff_sched.setFont(font)
        self.remove_staff_sched.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_25.addWidget(self.remove_staff_sched, 0, Qt.AlignLeft)

        self.clear_fills_staff = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.clear_fills_staff.setObjectName(u"clear_fills_staff")
        self.clear_fills_staff.setFont(font)
        self.clear_fills_staff.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_25.addWidget(self.clear_fills_staff)

        self.horizontalSpacer_29 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_25.addItem(self.horizontalSpacer_29)

        self.change_staff_sched = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.change_staff_sched.setObjectName(u"change_staff_sched")
        font9 = QFont()
        font9.setFamilies([u"Sitka Small"])
        font9.setPointSize(10)
        font9.setBold(True)
        self.change_staff_sched.setFont(font9)
        self.change_staff_sched.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_25.addWidget(self.change_staff_sched, 0, Qt.AlignRight)

        self.add_sched_staff = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.add_sched_staff.setObjectName(u"add_sched_staff")
        self.add_sched_staff.setFont(font)
        self.add_sched_staff.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_25.addWidget(self.add_sched_staff, 0, Qt.AlignRight)


        self.verticalLayout_9.addLayout(self.horizontalLayout_25)


        self.gridLayout_4.addLayout(self.verticalLayout_9, 5, 0, 1, 2)

        self.line_9 = QFrame(self.schedule_stackedwidgetPage3_2)
        self.line_9.setObjectName(u"line_9")
        self.line_9.setFrameShape(QFrame.Shape.VLine)
        self.line_9.setFrameShadow(QFrame.Shadow.Sunken)

        self.gridLayout_4.addWidget(self.line_9, 0, 2, 7, 1)

        self.label_56 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_56.setObjectName(u"label_56")
        self.label_56.setFont(font4)
        self.label_56.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.gridLayout_4.addWidget(self.label_56, 0, 0, 1, 1)

        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setSpacing(10)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_4 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font4)
        self.label_4.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_2.addWidget(self.label_4)

        self.assign_instructor = QLineEdit(self.schedule_stackedwidgetPage3_2)
        self.assign_instructor.setObjectName(u"assign_instructor")
        self.assign_instructor.setMaximumSize(QSize(600, 16777215))
        self.assign_instructor.setFont(font6)
        self.assign_instructor.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_2.addWidget(self.assign_instructor)


        self.verticalLayout_8.addLayout(self.horizontalLayout_2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label_8 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font4)
        self.label_8.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout.addWidget(self.label_8)

        self.assign_subject = QLineEdit(self.schedule_stackedwidgetPage3_2)
        self.assign_subject.setObjectName(u"assign_subject")
        self.assign_subject.setMaximumSize(QSize(600, 16777215))
        self.assign_subject.setFont(font6)
        self.assign_subject.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout.addWidget(self.assign_subject)


        self.verticalLayout_8.addLayout(self.horizontalLayout)

        self.verticalSpacer_17 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_8.addItem(self.verticalSpacer_17)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer)

        self.label_5 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font4)
        self.label_5.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_3.addWidget(self.label_5)

        self.instructor_day_edit_comboBox = QComboBox(self.schedule_stackedwidgetPage3_2)
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.addItem("")
        self.instructor_day_edit_comboBox.setObjectName(u"instructor_day_edit_comboBox")
        font10 = QFont()
        font10.setFamilies([u"Sitka Small Semibold"])
        font10.setPointSize(9)
        font10.setBold(True)
        font10.setItalic(True)
        self.instructor_day_edit_comboBox.setFont(font10)
        self.instructor_day_edit_comboBox.setStyleSheet(u"color: rgb(15, 15, 15);\n"
"background-color: rgb(255, 255, 255);")

        self.horizontalLayout_3.addWidget(self.instructor_day_edit_comboBox)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_2)


        self.verticalLayout_8.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_7)

        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setSpacing(7)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.label_6 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setFont(font3)
        self.label_6.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_7.addWidget(self.label_6)

        self.start_time_instructor = QTimeEdit(self.schedule_stackedwidgetPage3_2)
        self.start_time_instructor.setObjectName(u"start_time_instructor")
        font11 = QFont()
        font11.setFamilies([u"Sitka Small Semibold"])
        font11.setBold(True)
        font11.setItalic(True)
        self.start_time_instructor.setFont(font11)
        self.start_time_instructor.setStyleSheet(u"color: rgb(15, 15, 15);\n"
"background-color: rgb(255, 255, 255);")

        self.verticalLayout_7.addWidget(self.start_time_instructor)


        self.horizontalLayout_4.addLayout(self.verticalLayout_7)

        self.horizontalSpacer_15 = QSpacerItem(20, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_15)

        self.label_9 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font8)
        self.label_9.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")
        self.label_9.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_4.addWidget(self.label_9)

        self.horizontalSpacer_16 = QSpacerItem(20, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_16)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setSpacing(7)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.label_7 = QLabel(self.schedule_stackedwidgetPage3_2)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setFont(font3)
        self.label_7.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_6.addWidget(self.label_7)

        self.final_time_instructor = QTimeEdit(self.schedule_stackedwidgetPage3_2)
        self.final_time_instructor.setObjectName(u"final_time_instructor")
        self.final_time_instructor.setStyleSheet(u"color: rgb(15, 15, 15);\n"
"background-color: rgb(255, 255, 255);")

        self.verticalLayout_6.addWidget(self.final_time_instructor)


        self.horizontalLayout_4.addLayout(self.verticalLayout_6)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_8)


        self.verticalLayout_8.addLayout(self.horizontalLayout_4)

        self.add_student = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.add_student.setObjectName(u"add_student")
        self.add_student.setMinimumSize(QSize(100, 30))
        self.add_student.setFont(font3)
        self.add_student.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_8.addWidget(self.add_student, 0, Qt.AlignHCenter)

        self.verticalSpacer_19 = QSpacerItem(20, 37, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_8.addItem(self.verticalSpacer_19)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.remove_instructor_sched = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.remove_instructor_sched.setObjectName(u"remove_instructor_sched")
        self.remove_instructor_sched.setFont(font)
        self.remove_instructor_sched.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_24.addWidget(self.remove_instructor_sched)

        self.clear_fills_instructor = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.clear_fills_instructor.setObjectName(u"clear_fills_instructor")
        self.clear_fills_instructor.setFont(font)
        self.clear_fills_instructor.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_24.addWidget(self.clear_fills_instructor)

        self.horizontalSpacer_28 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_24.addItem(self.horizontalSpacer_28)

        self.change_instructor_sched = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.change_instructor_sched.setObjectName(u"change_instructor_sched")
        self.change_instructor_sched.setFont(font)
        self.change_instructor_sched.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_24.addWidget(self.change_instructor_sched)

        self.add_sched_instructor = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.add_sched_instructor.setObjectName(u"add_sched_instructor")
        self.add_sched_instructor.setFont(font)
        self.add_sched_instructor.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_24.addWidget(self.add_sched_instructor)


        self.verticalLayout_8.addLayout(self.horizontalLayout_24)


        self.gridLayout_4.addLayout(self.verticalLayout_8, 2, 0, 1, 2)

        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.MinimumExpanding)

        self.gridLayout_4.addItem(self.verticalSpacer_6, 3, 1, 1, 1)

        self.line_11 = QFrame(self.schedule_stackedwidgetPage3_2)
        self.line_11.setObjectName(u"line_11")
        self.line_11.setFrameShape(QFrame.Shape.HLine)
        self.line_11.setFrameShadow(QFrame.Shadow.Sunken)

        self.gridLayout_4.addWidget(self.line_11, 4, 0, 1, 2)

        self.back_2 = QPushButton(self.schedule_stackedwidgetPage3_2)
        self.back_2.setObjectName(u"back_2")
        self.back_2.setFont(font)
        self.back_2.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.gridLayout_4.addWidget(self.back_2, 6, 0, 1, 1, Qt.AlignLeft)

        self.schedule_stackedwidget.addWidget(self.schedule_stackedwidgetPage3_2)
        self.schedule_stackedwidgetPage4_2 = QWidget()
        self.schedule_stackedwidgetPage4_2.setObjectName(u"schedule_stackedwidgetPage4_2")
        self.verticalLayout_61 = QVBoxLayout(self.schedule_stackedwidgetPage4_2)
        self.verticalLayout_61.setObjectName(u"verticalLayout_61")
        self.back_3 = QPushButton(self.schedule_stackedwidgetPage4_2)
        self.back_3.setObjectName(u"back_3")
        self.back_3.setFont(font3)
        self.back_3.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.verticalLayout_61.addWidget(self.back_3, 0, Qt.AlignLeft)

        self.horizontalLayout_10 = QHBoxLayout()
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.label_55 = QLabel(self.schedule_stackedwidgetPage4_2)
        self.label_55.setObjectName(u"label_55")
        self.label_55.setFont(font4)
        self.label_55.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_10.addWidget(self.label_55)

        self.accessed_room_logs_lineedit = QLineEdit(self.schedule_stackedwidgetPage4_2)
        self.accessed_room_logs_lineedit.setObjectName(u"accessed_room_logs_lineedit")
        self.accessed_room_logs_lineedit.setFont(font6)
        self.accessed_room_logs_lineedit.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        self.accessed_room_logs_lineedit.setReadOnly(True)

        self.horizontalLayout_10.addWidget(self.accessed_room_logs_lineedit)

        self.horizontalSpacer_25 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_10.addItem(self.horizontalSpacer_25)


        self.verticalLayout_61.addLayout(self.horizontalLayout_10)

        self.selected_room_log = QTableWidget(self.schedule_stackedwidgetPage4_2)
        if (self.selected_room_log.columnCount() < 3):
            self.selected_room_log.setColumnCount(3)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.selected_room_log.setHorizontalHeaderItem(0, __qtablewidgetitem10)
        __qtablewidgetitem11 = QTableWidgetItem()
        self.selected_room_log.setHorizontalHeaderItem(1, __qtablewidgetitem11)
        __qtablewidgetitem12 = QTableWidgetItem()
        self.selected_room_log.setHorizontalHeaderItem(2, __qtablewidgetitem12)
        self.selected_room_log.setObjectName(u"selected_room_log")
        self.selected_room_log.setFont(font7)
        self.selected_room_log.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")

        self.verticalLayout_61.addWidget(self.selected_room_log)

        self.schedule_stackedwidget.addWidget(self.schedule_stackedwidgetPage4_2)

        self.gridLayout_2.addWidget(self.schedule_stackedwidget, 1, 0, 1, 1)

        self.stackedWidget.addWidget(self.stackedWidgetPage1)
        self.stackedWidgetPage2 = QWidget()
        self.stackedWidgetPage2.setObjectName(u"stackedWidgetPage2")
        self.gridLayout_6 = QGridLayout(self.stackedWidgetPage2)
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.gridLayout_5 = QGridLayout()
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.verticalLayout_11 = QVBoxLayout()
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.label_10 = QLabel(self.stackedWidgetPage2)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setMaximumSize(QSize(16777215, 109))
        self.label_10.setFont(font4)
        self.label_10.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_11.addWidget(self.label_10)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.manage_student = QPushButton(self.stackedWidgetPage2)
        self.manage_student.setObjectName(u"manage_student")
        self.manage_student.setMinimumSize(QSize(35, 35))
        self.manage_student.setFont(font3)
        self.manage_student.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_5.addWidget(self.manage_student)

        self.horizontalSpacer_26 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_26)

        self.label_11 = QLabel(self.stackedWidgetPage2)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setFont(font3)
        self.label_11.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_5.addWidget(self.label_11)

        self.sort_student = QComboBox(self.stackedWidgetPage2)
        self.sort_student.addItem("")
        self.sort_student.addItem("")
        self.sort_student.addItem("")
        self.sort_student.addItem("")
        self.sort_student.addItem("")
        self.sort_student.addItem("")
        self.sort_student.setObjectName(u"sort_student")
        self.sort_student.setFont(font10)
        self.sort_student.setStyleSheet(u"background-color: rgb(255, 255, 255);color: rgb(15, 15, 15);")

        self.horizontalLayout_5.addWidget(self.sort_student)

        self.search_bar_stdnt = QLineEdit(self.stackedWidgetPage2)
        self.search_bar_stdnt.setObjectName(u"search_bar_stdnt")
        self.search_bar_stdnt.setMinimumSize(QSize(10, 5))
        self.search_bar_stdnt.setFont(font6)
        self.search_bar_stdnt.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_5.addWidget(self.search_bar_stdnt)

        self.search_student_btn = QPushButton(self.stackedWidgetPage2)
        self.search_student_btn.setObjectName(u"search_student_btn")
        self.search_student_btn.setFont(font3)
        self.search_student_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_5.addWidget(self.search_student_btn)


        self.verticalLayout_11.addLayout(self.horizontalLayout_5)


        self.gridLayout_5.addLayout(self.verticalLayout_11, 0, 0, 1, 1)

        self.list_registered_stdnt = QTableWidget(self.stackedWidgetPage2)
        if (self.list_registered_stdnt.columnCount() < 6):
            self.list_registered_stdnt.setColumnCount(6)
        __qtablewidgetitem13 = QTableWidgetItem()
        self.list_registered_stdnt.setHorizontalHeaderItem(0, __qtablewidgetitem13)
        __qtablewidgetitem14 = QTableWidgetItem()
        self.list_registered_stdnt.setHorizontalHeaderItem(1, __qtablewidgetitem14)
        __qtablewidgetitem15 = QTableWidgetItem()
        self.list_registered_stdnt.setHorizontalHeaderItem(2, __qtablewidgetitem15)
        __qtablewidgetitem16 = QTableWidgetItem()
        self.list_registered_stdnt.setHorizontalHeaderItem(3, __qtablewidgetitem16)
        __qtablewidgetitem17 = QTableWidgetItem()
        self.list_registered_stdnt.setHorizontalHeaderItem(4, __qtablewidgetitem17)
        __qtablewidgetitem18 = QTableWidgetItem()
        self.list_registered_stdnt.setHorizontalHeaderItem(5, __qtablewidgetitem18)
        if (self.list_registered_stdnt.rowCount() < 1):
            self.list_registered_stdnt.setRowCount(1)
        __qtablewidgetitem19 = QTableWidgetItem()
        self.list_registered_stdnt.setVerticalHeaderItem(0, __qtablewidgetitem19)
        __qtablewidgetitem20 = QTableWidgetItem()
        self.list_registered_stdnt.setItem(0, 0, __qtablewidgetitem20)
        __qtablewidgetitem21 = QTableWidgetItem()
        self.list_registered_stdnt.setItem(0, 1, __qtablewidgetitem21)
        __qtablewidgetitem22 = QTableWidgetItem()
        self.list_registered_stdnt.setItem(0, 2, __qtablewidgetitem22)
        self.list_registered_stdnt.setObjectName(u"list_registered_stdnt")
        self.list_registered_stdnt.setMinimumSize(QSize(808, 513))
        self.list_registered_stdnt.setFont(font9)
        self.list_registered_stdnt.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.list_registered_stdnt.setFrameShape(QFrame.StyledPanel)
        self.list_registered_stdnt.setFrameShadow(QFrame.Plain)
        self.list_registered_stdnt.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
        self.list_registered_stdnt.setEditTriggers(QAbstractItemView.AnyKeyPressed|QAbstractItemView.DoubleClicked|QAbstractItemView.EditKeyPressed|QAbstractItemView.SelectedClicked)
        self.list_registered_stdnt.setShowGrid(True)
        self.list_registered_stdnt.setGridStyle(Qt.SolidLine)
        self.list_registered_stdnt.horizontalHeader().setDefaultSectionSize(130)

        self.gridLayout_5.addWidget(self.list_registered_stdnt, 1, 0, 1, 1)


        self.gridLayout_6.addLayout(self.gridLayout_5, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.stackedWidgetPage2)
        self.stackedWidgetPage3 = QWidget()
        self.stackedWidgetPage3.setObjectName(u"stackedWidgetPage3")
        self.gridLayout_23 = QGridLayout(self.stackedWidgetPage3)
        self.gridLayout_23.setObjectName(u"gridLayout_23")
        self.gridLayout_9 = QGridLayout()
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.gridLayout_8 = QGridLayout()
        self.gridLayout_8.setObjectName(u"gridLayout_8")
        self.label_13 = QLabel(self.stackedWidgetPage3)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setMaximumSize(QSize(16777215, 109))
        self.label_13.setFont(font4)
        self.label_13.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.gridLayout_8.addWidget(self.label_13, 0, 0, 1, 1)

        self.gridLayout_15 = QGridLayout()
        self.gridLayout_15.setObjectName(u"gridLayout_15")
        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.manage_staff = QPushButton(self.stackedWidgetPage3)
        self.manage_staff.setObjectName(u"manage_staff")
        self.manage_staff.setMinimumSize(QSize(35, 35))
        self.manage_staff.setFont(font3)
        self.manage_staff.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_13.addWidget(self.manage_staff)

        self.horizontalSpacer_30 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_30)

        self.label_12 = QLabel(self.stackedWidgetPage3)
        self.label_12.setObjectName(u"label_12")
        font12 = QFont()
        font12.setFamilies([u"Sitka Heading Semibold"])
        font12.setPointSize(12)
        font12.setBold(True)
        font12.setItalic(True)
        self.label_12.setFont(font12)
        self.label_12.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_13.addWidget(self.label_12)

        self.sort_staff = QComboBox(self.stackedWidgetPage3)
        self.sort_staff.addItem("")
        self.sort_staff.addItem("")
        self.sort_staff.addItem("")
        self.sort_staff.setObjectName(u"sort_staff")
        self.sort_staff.setFont(font10)
        self.sort_staff.setStyleSheet(u"background-color: rgb(255, 255, 255);color: rgb(15, 15, 15);")

        self.horizontalLayout_13.addWidget(self.sort_staff)

        self.search_bar_staff = QLineEdit(self.stackedWidgetPage3)
        self.search_bar_staff.setObjectName(u"search_bar_staff")
        self.search_bar_staff.setFont(font6)
        self.search_bar_staff.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_13.addWidget(self.search_bar_staff)

        self.search_staff_btn = QPushButton(self.stackedWidgetPage3)
        self.search_staff_btn.setObjectName(u"search_staff_btn")
        self.search_staff_btn.setFont(font3)
        self.search_staff_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_13.addWidget(self.search_staff_btn, 0, Qt.AlignRight)


        self.gridLayout_15.addLayout(self.horizontalLayout_13, 0, 0, 1, 1)


        self.gridLayout_8.addLayout(self.gridLayout_15, 1, 0, 1, 1)


        self.gridLayout_9.addLayout(self.gridLayout_8, 0, 0, 1, 1)

        self.list_registered_staff = QTableWidget(self.stackedWidgetPage3)
        if (self.list_registered_staff.columnCount() < 3):
            self.list_registered_staff.setColumnCount(3)
        __qtablewidgetitem23 = QTableWidgetItem()
        self.list_registered_staff.setHorizontalHeaderItem(0, __qtablewidgetitem23)
        __qtablewidgetitem24 = QTableWidgetItem()
        self.list_registered_staff.setHorizontalHeaderItem(1, __qtablewidgetitem24)
        __qtablewidgetitem25 = QTableWidgetItem()
        self.list_registered_staff.setHorizontalHeaderItem(2, __qtablewidgetitem25)
        if (self.list_registered_staff.rowCount() < 1):
            self.list_registered_staff.setRowCount(1)
        __qtablewidgetitem26 = QTableWidgetItem()
        self.list_registered_staff.setVerticalHeaderItem(0, __qtablewidgetitem26)
        __qtablewidgetitem27 = QTableWidgetItem()
        self.list_registered_staff.setItem(0, 0, __qtablewidgetitem27)
        __qtablewidgetitem28 = QTableWidgetItem()
        self.list_registered_staff.setItem(0, 1, __qtablewidgetitem28)
        self.list_registered_staff.setObjectName(u"list_registered_staff")
        self.list_registered_staff.setFont(font9)
        self.list_registered_staff.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.list_registered_staff.setFrameShadow(QFrame.Plain)
        self.list_registered_staff.setEditTriggers(QAbstractItemView.AnyKeyPressed|QAbstractItemView.DoubleClicked|QAbstractItemView.EditKeyPressed|QAbstractItemView.SelectedClicked)

        self.gridLayout_9.addWidget(self.list_registered_staff, 1, 0, 1, 1)


        self.gridLayout_23.addLayout(self.gridLayout_9, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.stackedWidgetPage3)
        self.stackedWidgetPage4 = QWidget()
        self.stackedWidgetPage4.setObjectName(u"stackedWidgetPage4")
        self.gridLayout_17 = QGridLayout(self.stackedWidgetPage4)
        self.gridLayout_17.setObjectName(u"gridLayout_17")
        self.tabWidget = QTabWidget(self.stackedWidgetPage4)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setMinimumSize(QSize(0, 0))
        font13 = QFont()
        font13.setFamilies([u"Sitka Heading Semibold"])
        font13.setPointSize(14)
        font13.setBold(True)
        font13.setItalic(True)
        self.tabWidget.setFont(font13)
        self.tabWidget.setFocusPolicy(Qt.TabFocus)
        self.tabWidget.setStyleSheet(u"QTabBar::tab {\n"
"    color: black;\n"
"    padding: 5px;\n"
"    border: 1px solid gray;\n"
"    border-bottom: none;\n"
"    border-top-left-radius: 4px;\n"
"    border-top-right-radius: 4px;\n"
"}\n"
"\n"
"\n"
"QTabBar::tab:selected {\n"
"    background: white;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QTabWidget::pane {\n"
"    background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"\n"
"}")
        self.tabWidget.setTabPosition(QTabWidget.North)
        self.tabWidget.setTabShape(QTabWidget.Rounded)
        self.Roomrequest_tab = QWidget()
        self.Roomrequest_tab.setObjectName(u"Roomrequest_tab")
        self.Roomrequest_tab.setMinimumSize(QSize(0, 0))
        self.Roomrequest_tab.setMouseTracking(False)
        self.Roomrequest_tab.setTabletTracking(False)
        self.Roomrequest_tab.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.gridLayout_19 = QGridLayout(self.Roomrequest_tab)
        self.gridLayout_19.setObjectName(u"gridLayout_19")
        self.gridLayout_18 = QGridLayout()
        self.gridLayout_18.setObjectName(u"gridLayout_18")
        self.verticalLayout_55 = QVBoxLayout()
        self.verticalLayout_55.setObjectName(u"verticalLayout_55")
        self.label_43 = QLabel(self.Roomrequest_tab)
        self.label_43.setObjectName(u"label_43")
        self.label_43.setFont(font4)
        self.label_43.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_55.addWidget(self.label_43)

        self.list_requests = QListWidget(self.Roomrequest_tab)
        self.list_requests.setObjectName(u"list_requests")
        self.list_requests.setFont(font6)
        self.list_requests.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.list_requests.setFrameShape(QFrame.Box)
        self.list_requests.setFrameShadow(QFrame.Plain)

        self.verticalLayout_55.addWidget(self.list_requests)


        self.gridLayout_18.addLayout(self.verticalLayout_55, 0, 0, 1, 1)

        self.verticalLayout_54 = QVBoxLayout()
        self.verticalLayout_54.setObjectName(u"verticalLayout_54")
        self.label_44 = QLabel(self.Roomrequest_tab)
        self.label_44.setObjectName(u"label_44")
        self.label_44.setFont(font4)
        self.label_44.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_54.addWidget(self.label_44)

        self.received_request = QPlainTextEdit(self.Roomrequest_tab)
        self.received_request.setObjectName(u"received_request")
        self.received_request.setFont(font6)
        self.received_request.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.received_request.setFrameShape(QFrame.Box)
        self.received_request.setFrameShadow(QFrame.Plain)
        self.received_request.setTextInteractionFlags(Qt.TextSelectableByKeyboard|Qt.TextSelectableByMouse)

        self.verticalLayout_54.addWidget(self.received_request)

        self.line_5 = QFrame(self.Roomrequest_tab)
        self.line_5.setObjectName(u"line_5")
        self.line_5.setFrameShape(QFrame.Shape.HLine)
        self.line_5.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_54.addWidget(self.line_5)

        self.label_45 = QLabel(self.Roomrequest_tab)
        self.label_45.setObjectName(u"label_45")
        self.label_45.setFont(font4)
        self.label_45.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_54.addWidget(self.label_45)

        self.reply_requests = QPlainTextEdit(self.Roomrequest_tab)
        self.reply_requests.setObjectName(u"reply_requests")
        self.reply_requests.setFont(font6)
        self.reply_requests.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.reply_requests.setFrameShape(QFrame.Box)
        self.reply_requests.setFrameShadow(QFrame.Plain)
        self.reply_requests.setOverwriteMode(False)

        self.verticalLayout_54.addWidget(self.reply_requests)

        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.del_request = QPushButton(self.Roomrequest_tab)
        self.del_request.setObjectName(u"del_request")
        self.del_request.setMinimumSize(QSize(100, 40))
        self.del_request.setFont(font3)
        self.del_request.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_17.addWidget(self.del_request)

        self.horizontalSpacer_12 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_17.addItem(self.horizontalSpacer_12)

        self.send_message_requests_btn = QPushButton(self.Roomrequest_tab)
        self.send_message_requests_btn.setObjectName(u"send_message_requests_btn")
        self.send_message_requests_btn.setMinimumSize(QSize(100, 40))
        self.send_message_requests_btn.setFont(font3)
        self.send_message_requests_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_17.addWidget(self.send_message_requests_btn, 0, Qt.AlignRight)


        self.verticalLayout_54.addLayout(self.horizontalLayout_17)


        self.gridLayout_18.addLayout(self.verticalLayout_54, 0, 1, 1, 1)


        self.gridLayout_19.addLayout(self.gridLayout_18, 0, 0, 1, 1)

        self.tabWidget.addTab(self.Roomrequest_tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.gridLayout_21 = QGridLayout(self.tab_2)
        self.gridLayout_21.setObjectName(u"gridLayout_21")
        self.gridLayout_20 = QGridLayout()
        self.gridLayout_20.setObjectName(u"gridLayout_20")
        self.verticalLayout_57 = QVBoxLayout()
        self.verticalLayout_57.setObjectName(u"verticalLayout_57")
        self.label_48 = QLabel(self.tab_2)
        self.label_48.setObjectName(u"label_48")
        self.label_48.setFont(font4)
        self.label_48.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_57.addWidget(self.label_48)

        self.list_reports = QListWidget(self.tab_2)
        self.list_reports.setObjectName(u"list_reports")
        self.list_reports.setFont(font6)
        self.list_reports.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.list_reports.setFrameShape(QFrame.Box)
        self.list_reports.setFrameShadow(QFrame.Plain)

        self.verticalLayout_57.addWidget(self.list_reports)


        self.gridLayout_20.addLayout(self.verticalLayout_57, 0, 0, 1, 1)

        self.verticalLayout_56 = QVBoxLayout()
        self.verticalLayout_56.setObjectName(u"verticalLayout_56")
        self.label_46 = QLabel(self.tab_2)
        self.label_46.setObjectName(u"label_46")
        self.label_46.setFont(font4)
        self.label_46.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_56.addWidget(self.label_46)

        self.received_report = QPlainTextEdit(self.tab_2)
        self.received_report.setObjectName(u"received_report")
        self.received_report.setFont(font6)
        self.received_report.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.received_report.setFrameShape(QFrame.Box)
        self.received_report.setFrameShadow(QFrame.Plain)
        self.received_report.setTextInteractionFlags(Qt.TextSelectableByKeyboard|Qt.TextSelectableByMouse)

        self.verticalLayout_56.addWidget(self.received_report)

        self.line_6 = QFrame(self.tab_2)
        self.line_6.setObjectName(u"line_6")
        self.line_6.setFrameShape(QFrame.Shape.HLine)
        self.line_6.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_56.addWidget(self.line_6)

        self.label_47 = QLabel(self.tab_2)
        self.label_47.setObjectName(u"label_47")
        self.label_47.setFont(font4)
        self.label_47.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.verticalLayout_56.addWidget(self.label_47)

        self.reply_report = QPlainTextEdit(self.tab_2)
        self.reply_report.setObjectName(u"reply_report")
        self.reply_report.setFont(font6)
        self.reply_report.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.reply_report.setFrameShape(QFrame.Box)
        self.reply_report.setFrameShadow(QFrame.Plain)
        self.reply_report.setOverwriteMode(False)

        self.verticalLayout_56.addWidget(self.reply_report)

        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.del_report = QPushButton(self.tab_2)
        self.del_report.setObjectName(u"del_report")
        self.del_report.setMinimumSize(QSize(100, 40))
        self.del_report.setFont(font3)
        self.del_report.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_18.addWidget(self.del_report)

        self.horizontalSpacer_13 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_18.addItem(self.horizontalSpacer_13)

        self.send_message_report_btn = QPushButton(self.tab_2)
        self.send_message_report_btn.setObjectName(u"send_message_report_btn")
        self.send_message_report_btn.setMinimumSize(QSize(100, 40))
        self.send_message_report_btn.setFont(font3)
        self.send_message_report_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_18.addWidget(self.send_message_report_btn, 0, Qt.AlignRight)


        self.verticalLayout_56.addLayout(self.horizontalLayout_18)


        self.gridLayout_20.addLayout(self.verticalLayout_56, 0, 1, 1, 1)


        self.gridLayout_21.addLayout(self.gridLayout_20, 0, 0, 1, 1)

        self.tabWidget.addTab(self.tab_2, "")

        self.gridLayout_17.addWidget(self.tabWidget, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.stackedWidgetPage4)
        self.stackedWidgetPage5 = QWidget()
        self.stackedWidgetPage5.setObjectName(u"stackedWidgetPage5")
        self.gridLayout_14 = QGridLayout(self.stackedWidgetPage5)
        self.gridLayout_14.setObjectName(u"gridLayout_14")
        self.gridLayout_13 = QGridLayout()
        self.gridLayout_13.setObjectName(u"gridLayout_13")
        self.gridLayout_12 = QGridLayout()
        self.gridLayout_12.setObjectName(u"gridLayout_12")
        self.label_16 = QLabel(self.stackedWidgetPage5)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setMaximumSize(QSize(16777215, 109))
        self.label_16.setFont(font4)
        self.label_16.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.gridLayout_12.addWidget(self.label_16, 0, 0, 1, 1)

        self.gridLayout_22 = QGridLayout()
        self.gridLayout_22.setObjectName(u"gridLayout_22")
        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.manage_instructor = QPushButton(self.stackedWidgetPage5)
        self.manage_instructor.setObjectName(u"manage_instructor")
        self.manage_instructor.setMinimumSize(QSize(35, 35))
        self.manage_instructor.setFont(font3)
        self.manage_instructor.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_16.addWidget(self.manage_instructor)

        self.horizontalSpacer_32 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_16.addItem(self.horizontalSpacer_32)

        self.label_17 = QLabel(self.stackedWidgetPage5)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setFont(font3)
        self.label_17.setStyleSheet(u" background-color: rgba(0, 0, 0, 0); /* Fully transparent */\n"
"color: rgb(15, 15, 15);\n"
"")

        self.horizontalLayout_16.addWidget(self.label_17)

        self.sort_instructor = QComboBox(self.stackedWidgetPage5)
        self.sort_instructor.addItem("")
        self.sort_instructor.addItem("")
        self.sort_instructor.addItem("")
        self.sort_instructor.setObjectName(u"sort_instructor")
        self.sort_instructor.setFont(font10)
        self.sort_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);color: rgb(15, 15, 15);")

        self.horizontalLayout_16.addWidget(self.sort_instructor)

        self.search_bar_instructor = QLineEdit(self.stackedWidgetPage5)
        self.search_bar_instructor.setObjectName(u"search_bar_instructor")
        self.search_bar_instructor.setFont(font6)
        self.search_bar_instructor.setStyleSheet(u"border: 1px solid #000000;  /* Black border */\n"
"color: rgb(15, 15, 15);\n"
"border-radius: 15px;        /* Curved edges */\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"")

        self.horizontalLayout_16.addWidget(self.search_bar_instructor)

        self.search_instructor_btn = QPushButton(self.stackedWidgetPage5)
        self.search_instructor_btn.setObjectName(u"search_instructor_btn")
        font14 = QFont()
        font14.setFamilies([u"Sitka Small Semibold"])
        font14.setPointSize(12)
        font14.setBold(True)
        font14.setItalic(False)
        self.search_instructor_btn.setFont(font14)
        self.search_instructor_btn.setStyleSheet(u" QPushButton {\n"
"        border: none;\n"
"        background-color: #ffffff;  /* White background */\n"
"        color: rgb(15, 15, 15);             /* Text color for contrast */\n"
"        border-radius: 18px;        /* Curved edges */\n"
"		border: 1px solid #000000;  /* Black border */\n"
"        border-radius: 15px;        /* Curved edges */\n"
"        padding: 7px 25px;          /* Spacing for a balanced look */\n"
"    }\n"
"    QPushButton:hover {\n"
"        background-color: #f0f0f0;  /* Light gray hover effect */\n"
"    }\n"
"    QPushButton:pressed {\n"
"        background-color: #e0e0e0;  /* Darker press effect */\n"
"    }\n"
"")

        self.horizontalLayout_16.addWidget(self.search_instructor_btn, 0, Qt.AlignRight)


        self.gridLayout_22.addLayout(self.horizontalLayout_16, 0, 0, 1, 1)


        self.gridLayout_12.addLayout(self.gridLayout_22, 1, 0, 1, 1)


        self.gridLayout_13.addLayout(self.gridLayout_12, 1, 0, 1, 1)

        self.list_registered_instructor = QTableWidget(self.stackedWidgetPage5)
        if (self.list_registered_instructor.columnCount() < 3):
            self.list_registered_instructor.setColumnCount(3)
        __qtablewidgetitem29 = QTableWidgetItem()
        self.list_registered_instructor.setHorizontalHeaderItem(0, __qtablewidgetitem29)
        __qtablewidgetitem30 = QTableWidgetItem()
        self.list_registered_instructor.setHorizontalHeaderItem(1, __qtablewidgetitem30)
        __qtablewidgetitem31 = QTableWidgetItem()
        self.list_registered_instructor.setHorizontalHeaderItem(2, __qtablewidgetitem31)
        if (self.list_registered_instructor.rowCount() < 1):
            self.list_registered_instructor.setRowCount(1)
        __qtablewidgetitem32 = QTableWidgetItem()
        self.list_registered_instructor.setVerticalHeaderItem(0, __qtablewidgetitem32)
        self.list_registered_instructor.setObjectName(u"list_registered_instructor")
        self.list_registered_instructor.setFont(font6)
        self.list_registered_instructor.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(15, 15, 15);")
        self.list_registered_instructor.setFrameShadow(QFrame.Plain)
        self.list_registered_instructor.setEditTriggers(QAbstractItemView.AnyKeyPressed|QAbstractItemView.DoubleClicked|QAbstractItemView.EditKeyPressed|QAbstractItemView.SelectedClicked)

        self.gridLayout_13.addWidget(self.list_registered_instructor, 2, 0, 1, 1)


        self.gridLayout_14.addLayout(self.gridLayout_13, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.stackedWidgetPage5)

        self.gridLayout_7.addWidget(self.stackedWidget, 0, 1, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1040, 31))
        self.menubar.setStyleSheet(u"/* Menu Bar */\n"
"QMenuBar {\n"
"    background-color: rgb(251, 2, 2);\n"
"}\n"
"\n"
"QMenuBar::item {\n"
"    background-color: rgb(251, 2, 2);\n"
"    color: white;\n"
"    padding: 5px 15px;\n"
"}\n"
"\n"
"QMenuBar::item:selected {\n"
"    background-color: rgb(255, 80, 80);  /* lighter red on hover */\n"
"    color: white;\n"
"}\n"
"\n"
"QMenuBar::item:pressed {\n"
"    background-color: rgb(255, 60, 60);  /* slightly darker when pressed */\n"
"}\n"
"\n"
"/* Dropdown Menus */\n"
"QMenu {\n"
"    background-color: rgb(251, 2, 2);\n"
"    color: white;\n"
"    border: 1px solid white;\n"
"}\n"
"\n"
"QMenu::item {\n"
"    background-color: rgb(251, 2, 2);\n"
"    color: white;\n"
"    padding: 5px 20px;\n"
"}\n"
"\n"
"QMenu::item:selected {\n"
"    background-color: rgb(255, 80, 80);  /* lighter red hover */\n"
"    color: white;\n"
"}\n"
"\n"
"QMenu::separator {\n"
"    height: 1px;\n"
"    background: white;\n"
"    margin: 5px 10px;\n"
"}")
        self.menuHelp = QMenu(self.menubar)
        self.menuHelp.setObjectName(u"menuHelp")
        self.menuRegistration = QMenu(self.menuHelp)
        self.menuRegistration.setObjectName(u"menuRegistration")
        self.menuInbox = QMenu(self.menuHelp)
        self.menuInbox.setObjectName(u"menuInbox")
        self.menuSchedules = QMenu(self.menuHelp)
        self.menuSchedules.setObjectName(u"menuSchedules")
        self.menuRemove = QMenu(self.menuHelp)
        self.menuRemove.setObjectName(u"menuRemove")
        self.menuSchedule = QMenu(self.menuRemove)
        self.menuSchedule.setObjectName(u"menuSchedule")
        self.menuUsers = QMenu(self.menuRemove)
        self.menuUsers.setObjectName(u"menuUsers")
        self.menuInbox_2 = QMenu(self.menuRemove)
        self.menuInbox_2.setObjectName(u"menuInbox_2")
        self.menuExport = QMenu(self.menubar)
        self.menuExport.setObjectName(u"menuExport")
        MainWindow.setMenuBar(self.menubar)

        self.menubar.addAction(self.menuHelp.menuAction())
        self.menubar.addAction(self.menuExport.menuAction())
        self.menuHelp.addAction(self.menuRegistration.menuAction())
        self.menuHelp.addAction(self.menuInbox.menuAction())
        self.menuHelp.addAction(self.menuSchedules.menuAction())
        self.menuHelp.addSeparator()
        self.menuHelp.addAction(self.menuRemove.menuAction())
        self.menuHelp.addSeparator()
        self.menuHelp.addAction(self.actionAbout)
        self.menuRegistration.addAction(self.actionRegister_Instructor)
        self.menuRegistration.addAction(self.actionRegister_Student)
        self.menuRegistration.addAction(self.actionRegister_Staff)
        self.menuInbox.addAction(self.actionRoom_Request)
        self.menuInbox.addAction(self.actionMaintenance_Damage_Report)
        self.menuSchedules.addAction(self.actionAdd_Schedule)
        self.menuSchedules.addAction(self.actionEdit_Schedule)
        self.menuRemove.addAction(self.menuSchedule.menuAction())
        self.menuRemove.addAction(self.menuUsers.menuAction())
        self.menuRemove.addAction(self.menuInbox_2.menuAction())
        self.menuSchedule.addAction(self.actionInstructor_2)
        self.menuSchedule.addAction(self.actionStudent_2)
        self.menuSchedule.addAction(self.actionStaff_2)
        self.menuUsers.addAction(self.actionInstructor_3)
        self.menuUsers.addAction(self.actionStudent_3)
        self.menuUsers.addAction(self.actionStaff_3)
        self.menuInbox_2.addAction(self.actionRoom_Request_2)
        self.menuInbox_2.addAction(self.actionMaintenance_Damage_Report_2)
        self.menuExport.addAction(self.actionRoom_Schedule)
        self.menuExport.addAction(self.actionSections)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(4)
        self.schedule_stackedwidget.setCurrentIndex(0)
        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionRoom_Schedule.setText(QCoreApplication.translate("MainWindow", u"Room Schedule", None))
        self.actionSections.setText(QCoreApplication.translate("MainWindow", u"Sections", None))
        self.actionRoom_logs.setText(QCoreApplication.translate("MainWindow", u"Room logs", None))
        self.actionRegister_Instructor.setText(QCoreApplication.translate("MainWindow", u"Register Instructor", None))
        self.actionRegister_Student.setText(QCoreApplication.translate("MainWindow", u"Register Student", None))
        self.actionRegister_Staff.setText(QCoreApplication.translate("MainWindow", u"Register Staff", None))
        self.actionRoom_Request.setText(QCoreApplication.translate("MainWindow", u"Room Request", None))
        self.actionMaintenance_Damage_Report.setText(QCoreApplication.translate("MainWindow", u"Maintenance/Damage Report", None))
        self.actionAdd_Schedule.setText(QCoreApplication.translate("MainWindow", u"Add Schedule", None))
        self.actionEdit_Schedule.setText(QCoreApplication.translate("MainWindow", u"Edit Schedule", None))
        self.actionInstructor.setText(QCoreApplication.translate("MainWindow", u"Instructor", None))
        self.actionStudent.setText(QCoreApplication.translate("MainWindow", u"Student", None))
        self.actionStaff.setText(QCoreApplication.translate("MainWindow", u"Staff", None))
        self.actionInstructor_2.setText(QCoreApplication.translate("MainWindow", u"Instructor", None))
        self.actionStudent_2.setText(QCoreApplication.translate("MainWindow", u"Section", None))
        self.actionStaff_2.setText(QCoreApplication.translate("MainWindow", u"Staff", None))
        self.actionInstructor_3.setText(QCoreApplication.translate("MainWindow", u"Instructor", None))
        self.actionStudent_3.setText(QCoreApplication.translate("MainWindow", u"Student", None))
        self.actionStaff_3.setText(QCoreApplication.translate("MainWindow", u"Staff", None))
        self.actionAdd_Section.setText(QCoreApplication.translate("MainWindow", u"Add Section", None))
        self.actionRoom_Request_2.setText(QCoreApplication.translate("MainWindow", u"Room Request", None))
        self.actionMaintenance_Damage_Report_2.setText(QCoreApplication.translate("MainWindow", u"Maintenance/Damage Report", None))
        self.actionAbout.setText(QCoreApplication.translate("MainWindow", u"About", None))
#if QT_CONFIG(shortcut)
        self.actionAbout.setShortcut(QCoreApplication.translate("MainWindow", u"Ctrl+A", None))
#endif // QT_CONFIG(shortcut)
        self.label.setText(QCoreApplication.translate("MainWindow", u"Welcome", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Admin", None))
#if QT_CONFIG(tooltip)
        self.room_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Room", None))
#endif // QT_CONFIG(tooltip)
        self.room_btn.setText(QCoreApplication.translate("MainWindow", u"Room", None))
#if QT_CONFIG(tooltip)
        self.instructor_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Instructor", None))
#endif // QT_CONFIG(tooltip)
        self.instructor_btn.setText(QCoreApplication.translate("MainWindow", u"Instructor", None))
#if QT_CONFIG(tooltip)
        self.student_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Student", None))
#endif // QT_CONFIG(tooltip)
        self.student_btn.setText(QCoreApplication.translate("MainWindow", u"Student", None))
#if QT_CONFIG(tooltip)
        self.staff_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Staff", None))
#endif // QT_CONFIG(tooltip)
        self.staff_btn.setText(QCoreApplication.translate("MainWindow", u"Staff", None))
#if QT_CONFIG(tooltip)
        self.inbox_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Inbox", None))
#endif // QT_CONFIG(tooltip)
        self.inbox_btn.setText(QCoreApplication.translate("MainWindow", u"Inbox", None))
#if QT_CONFIG(tooltip)
        self.logout_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Logout", None))
#endif // QT_CONFIG(tooltip)
        self.logout_btn.setText(QCoreApplication.translate("MainWindow", u"Logout", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Room Schedule", None))
#if QT_CONFIG(tooltip)
        self.add_rm.setToolTip(QCoreApplication.translate("MainWindow", u"Add Room", None))
#endif // QT_CONFIG(tooltip)
        self.add_rm.setText(QCoreApplication.translate("MainWindow", u"Add Room", None))
#if QT_CONFIG(tooltip)
        self.del_rm.setToolTip(QCoreApplication.translate("MainWindow", u"Delete Room ", None))
#endif // QT_CONFIG(tooltip)
        self.del_rm.setText(QCoreApplication.translate("MainWindow", u"Delete Room", None))
#if QT_CONFIG(tooltip)
        self.edit_rm.setToolTip(QCoreApplication.translate("MainWindow", u"Edit Room ", None))
#endif // QT_CONFIG(tooltip)
        self.edit_rm.setText(QCoreApplication.translate("MainWindow", u"Edit Room", None))
#if QT_CONFIG(tooltip)
        self.view_sched.setToolTip(QCoreApplication.translate("MainWindow", u"View Room Schedule", None))
#endif // QT_CONFIG(tooltip)
        self.view_sched.setText(QCoreApplication.translate("MainWindow", u"View Room Schedule", None))
#if QT_CONFIG(tooltip)
        self.log_rm.setToolTip(QCoreApplication.translate("MainWindow", u"History", None))
#endif // QT_CONFIG(tooltip)
        self.log_rm.setText(QCoreApplication.translate("MainWindow", u"History", None))
        self.sort_room.setItemText(0, QCoreApplication.translate("MainWindow", u"A-Z", None))
        self.sort_room.setItemText(1, QCoreApplication.translate("MainWindow", u"Z-A", None))

#if QT_CONFIG(tooltip)
        self.search_room_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Search", None))
#endif // QT_CONFIG(tooltip)
        self.search_room_btn.setText(QCoreApplication.translate("MainWindow", u"Search", None))
#if QT_CONFIG(tooltip)
        self.back.setToolTip(QCoreApplication.translate("MainWindow", u"Back", None))
#endif // QT_CONFIG(tooltip)
        self.back.setText(QCoreApplication.translate("MainWindow", u"Back", None))
        self.label_57.setText(QCoreApplication.translate("MainWindow", u" Room: ", None))
        ___qtablewidgetitem = self.room_sched_table.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"Monday", None));
        ___qtablewidgetitem1 = self.room_sched_table.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Tuesday", None));
        ___qtablewidgetitem2 = self.room_sched_table.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Wednesday", None));
        ___qtablewidgetitem3 = self.room_sched_table.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"Thursday", None));
        ___qtablewidgetitem4 = self.room_sched_table.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Friday", None));
        ___qtablewidgetitem5 = self.edit_room_sched_table.horizontalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"Monday", None));
        ___qtablewidgetitem6 = self.edit_room_sched_table.horizontalHeaderItem(1)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"Tuesday", None));
        ___qtablewidgetitem7 = self.edit_room_sched_table.horizontalHeaderItem(2)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"Wednesday", None));
        ___qtablewidgetitem8 = self.edit_room_sched_table.horizontalHeaderItem(3)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("MainWindow", u"Thursday", None));
        ___qtablewidgetitem9 = self.edit_room_sched_table.horizontalHeaderItem(4)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("MainWindow", u"Friday", None));
        self.label_50.setText(QCoreApplication.translate("MainWindow", u"Assign Staff:", None))
        self.label_49.setText(QCoreApplication.translate("MainWindow", u"Purpose:", None))
        self.label_51.setText(QCoreApplication.translate("MainWindow", u"Choose Day:", None))
        self.day_edit_staff.setItemText(0, QCoreApplication.translate("MainWindow", u"Monday", None))
        self.day_edit_staff.setItemText(1, QCoreApplication.translate("MainWindow", u"Tuesday", None))
        self.day_edit_staff.setItemText(2, QCoreApplication.translate("MainWindow", u"Wednesday", None))
        self.day_edit_staff.setItemText(3, QCoreApplication.translate("MainWindow", u"Thursday", None))
        self.day_edit_staff.setItemText(4, QCoreApplication.translate("MainWindow", u"Friday", None))

        self.label_52.setText(QCoreApplication.translate("MainWindow", u"Start of Schedule", None))
        self.label_53.setText(QCoreApplication.translate("MainWindow", u":", None))
        self.label_54.setText(QCoreApplication.translate("MainWindow", u"End of Schedule", None))
#if QT_CONFIG(tooltip)
        self.remove_staff_sched.setToolTip(QCoreApplication.translate("MainWindow", u"Remove", None))
#endif // QT_CONFIG(tooltip)
        self.remove_staff_sched.setText(QCoreApplication.translate("MainWindow", u"Remove", None))
#if QT_CONFIG(tooltip)
        self.clear_fills_staff.setToolTip(QCoreApplication.translate("MainWindow", u"Remove", None))
#endif // QT_CONFIG(tooltip)
        self.clear_fills_staff.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
#if QT_CONFIG(tooltip)
        self.change_staff_sched.setToolTip(QCoreApplication.translate("MainWindow", u"Change", None))
#endif // QT_CONFIG(tooltip)
        self.change_staff_sched.setText(QCoreApplication.translate("MainWindow", u"Change", None))
#if QT_CONFIG(tooltip)
        self.add_sched_staff.setToolTip(QCoreApplication.translate("MainWindow", u"Add", None))
#endif // QT_CONFIG(tooltip)
        self.add_sched_staff.setText(QCoreApplication.translate("MainWindow", u"Add", None))
        self.label_56.setText(QCoreApplication.translate("MainWindow", u"Edit Room Schedule", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Assign Instructor:", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Subject Code:", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Choose Day:", None))
        self.instructor_day_edit_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Monday", None))
        self.instructor_day_edit_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Tuesday", None))
        self.instructor_day_edit_comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"Wednesday", None))
        self.instructor_day_edit_comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"Thursday", None))
        self.instructor_day_edit_comboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"Friday", None))

        self.label_6.setText(QCoreApplication.translate("MainWindow", u"Start of Class", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u":", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"End of Class", None))
#if QT_CONFIG(tooltip)
        self.add_student.setToolTip(QCoreApplication.translate("MainWindow", u"Add Students", None))
#endif // QT_CONFIG(tooltip)
        self.add_student.setText(QCoreApplication.translate("MainWindow", u"Edit Sections", None))
#if QT_CONFIG(tooltip)
        self.remove_instructor_sched.setToolTip(QCoreApplication.translate("MainWindow", u"Remove", None))
#endif // QT_CONFIG(tooltip)
        self.remove_instructor_sched.setText(QCoreApplication.translate("MainWindow", u"Remove", None))
#if QT_CONFIG(tooltip)
        self.clear_fills_instructor.setToolTip(QCoreApplication.translate("MainWindow", u"Remove", None))
#endif // QT_CONFIG(tooltip)
        self.clear_fills_instructor.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
#if QT_CONFIG(tooltip)
        self.change_instructor_sched.setToolTip(QCoreApplication.translate("MainWindow", u"Change", None))
#endif // QT_CONFIG(tooltip)
        self.change_instructor_sched.setText(QCoreApplication.translate("MainWindow", u"Change", None))
#if QT_CONFIG(tooltip)
        self.add_sched_instructor.setToolTip(QCoreApplication.translate("MainWindow", u"Add", None))
#endif // QT_CONFIG(tooltip)
        self.add_sched_instructor.setText(QCoreApplication.translate("MainWindow", u"Add", None))
#if QT_CONFIG(tooltip)
        self.back_2.setToolTip(QCoreApplication.translate("MainWindow", u"Back", None))
#endif // QT_CONFIG(tooltip)
        self.back_2.setText(QCoreApplication.translate("MainWindow", u"Back", None))
#if QT_CONFIG(tooltip)
        self.back_3.setToolTip(QCoreApplication.translate("MainWindow", u"Back", None))
#endif // QT_CONFIG(tooltip)
        self.back_3.setText(QCoreApplication.translate("MainWindow", u"Back", None))
        self.label_55.setText(QCoreApplication.translate("MainWindow", u"Accessed Room: ", None))
        ___qtablewidgetitem10 = self.selected_room_log.horizontalHeaderItem(0)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("MainWindow", u"Date and Time", None));
        ___qtablewidgetitem11 = self.selected_room_log.horizontalHeaderItem(1)
        ___qtablewidgetitem11.setText(QCoreApplication.translate("MainWindow", u"User", None));
        ___qtablewidgetitem12 = self.selected_room_log.horizontalHeaderItem(2)
        ___qtablewidgetitem12.setText(QCoreApplication.translate("MainWindow", u"Access Attempt", None));
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Student Accounts", None))
#if QT_CONFIG(tooltip)
        self.manage_student.setToolTip(QCoreApplication.translate("MainWindow", u"Manage Student", None))
#endif // QT_CONFIG(tooltip)
        self.manage_student.setText(QCoreApplication.translate("MainWindow", u"Manage Student", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"Sort by:", None))
        self.sort_student.setItemText(0, QCoreApplication.translate("MainWindow", u"Name", None))
        self.sort_student.setItemText(1, QCoreApplication.translate("MainWindow", u"Email", None))
        self.sort_student.setItemText(2, QCoreApplication.translate("MainWindow", u"ID", None))
        self.sort_student.setItemText(3, QCoreApplication.translate("MainWindow", u"Course", None))
        self.sort_student.setItemText(4, QCoreApplication.translate("MainWindow", u"Year", None))
        self.sort_student.setItemText(5, QCoreApplication.translate("MainWindow", u"Section", None))

#if QT_CONFIG(whatsthis)
        self.sort_student.setWhatsThis(QCoreApplication.translate("MainWindow", u"<html><head/><body><p>background-color: rgb(255, 255, 255);</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.sort_student.setCurrentText(QCoreApplication.translate("MainWindow", u"Name", None))
#if QT_CONFIG(tooltip)
        self.search_student_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Search", None))
#endif // QT_CONFIG(tooltip)
        self.search_student_btn.setText(QCoreApplication.translate("MainWindow", u"Search", None))
        ___qtablewidgetitem13 = self.list_registered_stdnt.horizontalHeaderItem(0)
        ___qtablewidgetitem13.setText(QCoreApplication.translate("MainWindow", u"Student Name", None));
        ___qtablewidgetitem14 = self.list_registered_stdnt.horizontalHeaderItem(1)
        ___qtablewidgetitem14.setText(QCoreApplication.translate("MainWindow", u"Student ID", None));
        ___qtablewidgetitem15 = self.list_registered_stdnt.horizontalHeaderItem(2)
        ___qtablewidgetitem15.setText(QCoreApplication.translate("MainWindow", u"Email", None));
        ___qtablewidgetitem16 = self.list_registered_stdnt.horizontalHeaderItem(3)
        ___qtablewidgetitem16.setText(QCoreApplication.translate("MainWindow", u"Course", None));
        ___qtablewidgetitem17 = self.list_registered_stdnt.horizontalHeaderItem(4)
        ___qtablewidgetitem17.setText(QCoreApplication.translate("MainWindow", u"Year", None));
        ___qtablewidgetitem18 = self.list_registered_stdnt.horizontalHeaderItem(5)
        ___qtablewidgetitem18.setText(QCoreApplication.translate("MainWindow", u"Section", None));
        ___qtablewidgetitem19 = self.list_registered_stdnt.verticalHeaderItem(0)
        ___qtablewidgetitem19.setText(QCoreApplication.translate("MainWindow", u"1.", None));

        __sortingEnabled = self.list_registered_stdnt.isSortingEnabled()
        self.list_registered_stdnt.setSortingEnabled(False)
        self.list_registered_stdnt.setSortingEnabled(__sortingEnabled)

        self.label_13.setText(QCoreApplication.translate("MainWindow", u"Staff Accounts", None))
#if QT_CONFIG(tooltip)
        self.manage_staff.setToolTip(QCoreApplication.translate("MainWindow", u"Manage Staff", None))
#endif // QT_CONFIG(tooltip)
        self.manage_staff.setText(QCoreApplication.translate("MainWindow", u"Manage Staff", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Sort by:", None))
        self.sort_staff.setItemText(0, QCoreApplication.translate("MainWindow", u"Name", None))
        self.sort_staff.setItemText(1, QCoreApplication.translate("MainWindow", u"Email", None))
        self.sort_staff.setItemText(2, QCoreApplication.translate("MainWindow", u"ID", None))

        self.sort_staff.setCurrentText(QCoreApplication.translate("MainWindow", u"Name", None))
#if QT_CONFIG(tooltip)
        self.search_staff_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Search", None))
#endif // QT_CONFIG(tooltip)
        self.search_staff_btn.setText(QCoreApplication.translate("MainWindow", u"Search", None))
        ___qtablewidgetitem20 = self.list_registered_staff.horizontalHeaderItem(0)
        ___qtablewidgetitem20.setText(QCoreApplication.translate("MainWindow", u"Name", None));
        ___qtablewidgetitem21 = self.list_registered_staff.horizontalHeaderItem(1)
        ___qtablewidgetitem21.setText(QCoreApplication.translate("MainWindow", u"ID No.", None));
        ___qtablewidgetitem22 = self.list_registered_staff.horizontalHeaderItem(2)
        ___qtablewidgetitem22.setText(QCoreApplication.translate("MainWindow", u"Email", None));
        ___qtablewidgetitem23 = self.list_registered_staff.verticalHeaderItem(0)
        ___qtablewidgetitem23.setText(QCoreApplication.translate("MainWindow", u"1.", None));

        __sortingEnabled1 = self.list_registered_staff.isSortingEnabled()
        self.list_registered_staff.setSortingEnabled(False)
        self.list_registered_staff.setSortingEnabled(__sortingEnabled1)

        self.label_43.setText(QCoreApplication.translate("MainWindow", u"Room Requests", None))
        self.label_44.setText(QCoreApplication.translate("MainWindow", u"Received Message", None))
        self.received_request.setPlainText("")
        self.label_45.setText(QCoreApplication.translate("MainWindow", u"Reply / Message", None))
        self.reply_requests.setPlainText("")
#if QT_CONFIG(tooltip)
        self.del_request.setToolTip(QCoreApplication.translate("MainWindow", u"Delete", None))
#endif // QT_CONFIG(tooltip)
        self.del_request.setText(QCoreApplication.translate("MainWindow", u"Delete", None))
#if QT_CONFIG(tooltip)
        self.send_message_requests_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Send", None))
#endif // QT_CONFIG(tooltip)
        self.send_message_requests_btn.setText(QCoreApplication.translate("MainWindow", u"Send", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.Roomrequest_tab), QCoreApplication.translate("MainWindow", u"Room Request", None))
        self.label_48.setText(QCoreApplication.translate("MainWindow", u"Reports", None))
        self.label_46.setText(QCoreApplication.translate("MainWindow", u"Received Message", None))
        self.received_report.setPlainText("")
        self.label_47.setText(QCoreApplication.translate("MainWindow", u"Reply / Message", None))
        self.reply_report.setPlainText("")
#if QT_CONFIG(tooltip)
        self.del_report.setToolTip(QCoreApplication.translate("MainWindow", u"Delete", None))
#endif // QT_CONFIG(tooltip)
        self.del_report.setText(QCoreApplication.translate("MainWindow", u"Delete", None))
#if QT_CONFIG(tooltip)
        self.send_message_report_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Send", None))
#endif // QT_CONFIG(tooltip)
        self.send_message_report_btn.setText(QCoreApplication.translate("MainWindow", u"Send", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Maintenance / Damage Report", None))
        self.label_16.setText(QCoreApplication.translate("MainWindow", u"Instructor Accounts", None))
#if QT_CONFIG(tooltip)
        self.manage_instructor.setToolTip(QCoreApplication.translate("MainWindow", u"Manage Instructor", None))
#endif // QT_CONFIG(tooltip)
        self.manage_instructor.setText(QCoreApplication.translate("MainWindow", u"Manage Instructor", None))
        self.label_17.setText(QCoreApplication.translate("MainWindow", u"Sort by:", None))
        self.sort_instructor.setItemText(0, QCoreApplication.translate("MainWindow", u"Name", None))
        self.sort_instructor.setItemText(1, QCoreApplication.translate("MainWindow", u"Email", None))
        self.sort_instructor.setItemText(2, QCoreApplication.translate("MainWindow", u"ID", None))

        self.sort_instructor.setCurrentText(QCoreApplication.translate("MainWindow", u"Name", None))
#if QT_CONFIG(tooltip)
        self.search_instructor_btn.setToolTip(QCoreApplication.translate("MainWindow", u"Search", None))
#endif // QT_CONFIG(tooltip)
        self.search_instructor_btn.setText(QCoreApplication.translate("MainWindow", u"Search", None))
        ___qtablewidgetitem24 = self.list_registered_instructor.horizontalHeaderItem(0)
        ___qtablewidgetitem24.setText(QCoreApplication.translate("MainWindow", u"Name", None));
        ___qtablewidgetitem25 = self.list_registered_instructor.horizontalHeaderItem(1)
        ___qtablewidgetitem25.setText(QCoreApplication.translate("MainWindow", u"ID No.", None));
        ___qtablewidgetitem26 = self.list_registered_instructor.horizontalHeaderItem(2)
        ___qtablewidgetitem26.setText(QCoreApplication.translate("MainWindow", u"Email", None));
        ___qtablewidgetitem27 = self.list_registered_instructor.verticalHeaderItem(0)
        ___qtablewidgetitem27.setText(QCoreApplication.translate("MainWindow", u"1.", None));
        self.menuHelp.setTitle(QCoreApplication.translate("MainWindow", u"Help", None))
        self.menuRegistration.setTitle(QCoreApplication.translate("MainWindow", u"Registration", None))
        self.menuInbox.setTitle(QCoreApplication.translate("MainWindow", u"Inbox", None))
        self.menuSchedules.setTitle(QCoreApplication.translate("MainWindow", u"Schedules", None))
        self.menuRemove.setTitle(QCoreApplication.translate("MainWindow", u"Remove", None))
        self.menuSchedule.setTitle(QCoreApplication.translate("MainWindow", u"Schedule", None))
        self.menuUsers.setTitle(QCoreApplication.translate("MainWindow", u"Unregister Users", None))
        self.menuInbox_2.setTitle(QCoreApplication.translate("MainWindow", u"Inbox", None))
        self.menuExport.setTitle(QCoreApplication.translate("MainWindow", u"Export", None))
    # retranslateUi

