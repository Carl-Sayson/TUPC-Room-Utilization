from PySide6.QtWidgets import (QApplication, QMainWindow, QMessageBox, QDialog, QListWidgetItem, QPushButton,
                                QLineEdit, QTableWidgetItem, QTableWidget, QComboBox, QListWidget, QAbstractItemView, 
                                QHeaderView, QFileDialog, QProgressBar, QVBoxLayout, QLabel, )
from PySide6.QtCore import Qt, QTime, Signal, QThread, QObject, QEvent, QTimer, QRegularExpression
from PySide6.QtGui import QFont, QPainter, QPen, QIntValidator, QRegularExpressionValidator
from PySide6.QtCharts import QChart, QChartView, QPieSeries

from Log_in_ui import Ui_Log_In as login
from Admin_menu_ui import Ui_MainWindow as AdminUI
from Student_menu_ui import Ui_MainWindow as StudentUI
from Staff_menu_ui import Ui_MainWindow as StaffUI
from Instructor_menu_ui import Ui_MainWindow as InstructorUI

from Room_attendance_ui import Ui_Form as AttendanceUi
from sectionlist_export_ui import Ui_Dialog as SectionExportUi
from roomlist_export_ui import Ui_Dialog as RoomExportUi
from Change_pass_ui import Ui_Dialog as ChangePassUi
from Room_Request_Instructor_ui import Ui_Form as RoomRequestInstructorUi
from Room_Request_Staff_ui import Ui_Form as RoomRequestStaffUi
from Compose_Message_staff_ui import Ui_Form as ComposeReportStaffUi
from Edit_students_ui import Ui_Form as EditStudentUi
from Force_change_Password_ui import Ui_Form as ForceChangePasswordUi
from staff_registration_ui import Ui_Form as StaffRegistrationUi
from student_registration_ui import Ui_Dialog as StudentRegistrationUi
from instructor_registration_ui import Ui_Form as InstructorRegistrationUi

import smtplib
import socket
from email.message import EmailMessage
import os
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import errorcode
import sys
import time
from datetime import timedelta, datetime
import openpyxl
from openpyxl.styles import Font
from PySide6.QtWidgets import QFileDialog
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import tempfile

import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

# dialog help 
from About_TUPC_Room_Utilization_ui import Ui_Dialog as AboutUI
from HowTo_AddSchedule_ui import Ui_Dialog as How_addschedule
from HowTo_DeleteReport_ui import Ui_Dialog as How_DeleteReport
from HowTo_DeleteRoomReq_ui import Ui_Dialog as How_DeleteRoomReq
from HowTo_EditSchedule_ui import Ui_Dialog as How_editSched

from HowTo_MaintenanceDamageReport_ui import Ui_Dialog as How_MaintenanceDamage
from HowTo_RemoveInstOnSched_ui import Ui_Dialog as HowRemoveInstonSched
from HowTo_RemoveInstructor_ui import Ui_Dialog as HowRemoveInst
from HowTo_RemoveSection_ui import Ui_Dialog as HowRemoveSect

from HowTo_RemoveSectOnSched_ui import Ui_Dialog as HowRemoveSectonSched
from HowToReg_Student_ui import Ui_Dialog as HowRegSTDNT
from HowToReg_Instructor_ui import Ui_Dialog as HowRegINST
from HowToReg_Staff_ui import Ui_Dialog as HowRegSTFF

from HowTo_ReplyToRoomRequest_ui import Ui_Dialog as HowReplyROOMREQ 
from HowTo_RemoveStaffOnSched_ui import Ui_Dialog as HowRemoveSTAFFONSCHED
from HowTo_RemoveStaff_ui import Ui_Dialog as HowRemoveStaff

from HowTo_RemoveStudent_ui import Ui_Dialog as HowRemoveStdnt
from HowTo_RoomRequest_ui import Ui_Dialog as How_RoomReq
from HowTo_ReplyMaintenanceDamageReport_ui import Ui_Dialog as HowReplyMain_Damage


# Help Dialogs
class About(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = AboutUI()
        self.ui.setupUi(self)

class Delete_Report(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = How_DeleteReport()
        self.ui.setupUi(self)

class Add_schedule(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = How_addschedule()
        self.ui.setupUi(self)

class Delete_RoomReport(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = How_DeleteReport()
        self.ui.setupUi(self)

class Delete_RoomReq(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = How_DeleteRoomReq()
        self.ui.setupUi(self)

class Edit_schedule(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = How_editSched()
        self.ui.setupUi(self)

class MaintenanceDamage(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = How_MaintenanceDamage()
        self.ui.setupUi(self)

class Remove_Instructor(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRemoveInst()
        self.ui.setupUi(self)

class Remove_Inst_on_sched(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRemoveInstonSched()
        self.ui.setupUi(self)

class RemoveSection(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRemoveSect()
        self.ui.setupUi(self)

class RemoveSectonSched(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRemoveSectonSched()
        self.ui.setupUi(self)

class Reg_Student(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRegSTDNT()
        self.ui.setupUi(self)

class Reg_instructor(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRegINST()
        self.ui.setupUi(self)

class Reg_Staff(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRegSTFF()
        self.ui.setupUi(self)

class Reply_Room_Req(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowReplyROOMREQ()
        self.ui.setupUi(self)

class Remove_staff_sched(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRemoveSTAFFONSCHED()
        self.ui.setupUi(self)

class Remove_staff(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRemoveStaff()
        self.ui.setupUi(self)

class Remove_Student(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowRemoveStdnt()
        self.ui.setupUi(self)

class RoomReq(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = How_RoomReq()
        self.ui.setupUi(self)

class Reply_RoomMaint_Dam(QDialog):
   def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = HowReplyMain_Damage()
        self.ui.setupUi(self)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        try:
            self.ui = login()
            self.ui.setupUi(self)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Failed to load UI: {e}")
            sys.exit(1)

        try: 
            self.mydb = mysql.connector.connect(
                host="localhost",
                user="Group_F",
                password="CPET-8L-TUPCROOM",
                database="tupc-room_utilization"
            )
            
            self.mycursor = self.mydb.cursor(buffered=True)     
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)  

        self.ui.login.clicked.connect(self.handle_login)
        self.ui.show_new.clicked.connect(self.toggle_password_visibility)
        self.new_window = None
        self.add_admin_SQL()

    def add_admin_SQL(self):
        try:
            # Step 1: Check if any admin already exists
            self.mycursor.execute("""
                SELECT COUNT(*) FROM user_accounts WHERE user_type = 'admin'
            """)
            (admin_count,) = self.mycursor.fetchone()

            if admin_count > 0:
                return

            # Step 2: Insert default admin account
            default_firstname = "Default"
            default_lastname = "Admin"
            default_password = "admin123"  # You can hash this in production
            default_email = "admin@tupc.edu"
            default_tupc_id = "123"

            self.mycursor.execute("""
                INSERT INTO user_accounts (First_Name, Last_Name, password, user_type, email, real_ID, is_change_password)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                default_firstname,
                default_lastname,
                default_password,
                'admin',
                default_email,
                default_tupc_id,
                1  # Force change password on first login
            ))

            self.mydb.commit()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def handle_login(self):
        user_id = self.ui.username.text()
        password = self.ui.password.text()

        try: 
            self.mycursor.execute("SELECT real_ID, user_type, CONCAT(First_Name, ' ', Last_Name), is_change_password FROM user_accounts WHERE real_ID = %s AND password = %s", (user_id, password))
            result = self.mycursor.fetchone()
            if result:
                user_ID = result[0]
                user_type = result[1]
                username = result[2]
                changePass = result[3]
                if user_type == 'student':
                    self.new_window = StudentMenu(user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
                elif user_type == 'staff':
                    pass
                    self.new_window = StaffMenu(user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
                elif user_type == 'instructor':
                    pass
                    self.new_window = InstructorMenu(user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
                elif user_type == 'admin':
                    self.new_window = AdminMenu(user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
                value = f"Welcome to TUPC Room Utilization, {username}!"
                QMessageBox.information(None, f"Login Successful", value)
                self.force_change(changePass, user_ID)

            else:
                QMessageBox.warning(None, "Login Failed", "Invalid username or password!")

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def force_change(self, changepass_status, user_ID):
        if changepass_status == 0:
            dialog = ForceChangePassword(user_ID)
            ifChange = dialog.exec()
            if ifChange == QDialog.Accepted:
                self.switch_window(self.new_window)
            else:
                self.ui.username.clear()
                self.ui.password.clear()
                return
        else:
            self.switch_window(self.new_window)
            
    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

    def toggle_password_visibility(self):
        if self.ui.password.echoMode() == QLineEdit.Password:
            self.ui.password.setEchoMode(QLineEdit.Normal)  # Show password
            self.ui.show_new.setText("Hide")
        else:
            self.ui.password.setEchoMode(QLineEdit.Password)  # Hide password
            self.ui.show_new.setText("Show")  

    def switch_window(self, new_window_instance):
        if self.new_window:
            self.new_window.close()
        self.new_window = new_window_instance
        self.new_window.show()
        self.close()

class StudentMenu(QMainWindow):
    def __init__(self, user_ID, db_connection, db_cursor):
        super().__init__()
        self.ui = StudentUI()
        self.ui.setupUi(self)

        self.user_ID = user_ID   
        self.mydb = db_connection
        self.mycursor = db_cursor

        # Button connections
        self.ui.logout_btn.clicked.connect(self.open_logout)
        self.ui.change_pass.clicked.connect(self.open_change_pass)  
        self.ui.student_sched_btn.clicked.connect(lambda: self.open_page(0))  # Student view
        self.ui.info_stdnt_btn.clicked.connect(lambda: self.open_page(1))  # Student info

        self.new_window = None

        # Load student data
        self.setup_table()
        self.load_student_info()
        self.load_student_schedule()

    def open_page(self, index):
        """Switch pages in the stacked widget."""
        self.ui.student_menu_stackedwidget.setCurrentIndex(index)
        self.new_window = None

    def open_change_pass(self):
        """Open change password dialog."""
        dialog = ChangePass(self.user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()

    def open_logout(self):
        """Switch back to the login window."""
        self.switch_window(MainWindow)

    def switch_window(self, new_window_class):
        """Close current window and switch to a new one."""
        if self.new_window:
            self.new_window.close()
        self.new_window = new_window_class()
        self.new_window.show()
        self.close()

    def setup_table(self):
        table = self.ui.room_sched_table      
        table.setColumnCount(6)
        table.setRowCount(14)
        table.setWordWrap(True)
        table.resizeColumnsToContents()
        table.resizeRowsToContents()
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setWordWrap(True)
        table.verticalHeader().setVisible(False)
        table.setHorizontalHeaderLabels(["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
        for i in range(14):  # From 07:00 to 20:00
            hour = 7 + i
            time_str = QTime(hour, 0).toString("HH:mm")
            table.setItem(i, 0, QTableWidgetItem(time_str))

    def load_student_info(self):
        """Fetch and display student's personal information."""
        try:
            self.mycursor.execute("""
                SELECT real_ID, First_Name, Last_Name, email
                FROM user_accounts 
                WHERE real_ID = %s AND user_type = 'student'
            """, (self.user_ID,))
            student_info = self.mycursor.fetchone()

            if student_info:
                self.ui.tupc_id_lineedit_info.setDisabled(True)
                self.ui.first_name_lineedit_stdntinfo.setDisabled(True)
                self.ui.last_name_lineedit_stdntinfo.setDisabled(True)
                self.ui.email_stdnt_lineedit_info.setDisabled(True)

                self.ui.tupc_id_lineedit_info.setText(str(student_info[0]))
                self.ui.first_name_lineedit_stdntinfo.setText(student_info[1])
                self.ui.last_name_lineedit_stdntinfo.setText(student_info[2])
                self.ui.email_stdnt_lineedit_info.setText(student_info[3])
            else:
                QMessageBox.warning(None, "Error", "Student information not found.")

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_student_schedule(self):
        table = self.ui.room_sched_table

        # Clear all cells (except time column)
        for row in range(table.rowCount()):
            for col in range(1, table.columnCount()):
                table.setItem(row, col, QTableWidgetItem(""))

        try:
            # Step 1: Get the student's section_ID
            self.mycursor.execute("""
                SELECT section_ID FROM section_junction WHERE student_ID = %s
            """, (self.user_ID,))
            result = self.mycursor.fetchone()
            if not result:
                QMessageBox.information(None, "No Schedule", "You are not enrolled in any section.")
                return

            section_id = result[0]

            # Step 2: Get schedule for that section
            self.mycursor.execute("""
                SELECT rs.selected_day, rs.start_schedule, rs.end_schedule, 
                    rs.subject_code_purpose, rs.selected_room_ID
                FROM room_schedule rs
                WHERE rs.section_ID = %s
            """, (section_id,))
            schedule_data = self.mycursor.fetchall()

            # Step 3: Map days to columns
            day_column_map = {
                "Monday": 1,
                "Tuesday": 2,
                "Wednesday": 3,
                "Thursday": 4,
                "Friday": 5
            }

            for day, start_time, end_time, subject, room_id in schedule_data:
                col = day_column_map.get(day)
                if col is None:
                    continue

                # Step 4: Get instructor for this subject
                self.mycursor.execute("""
                    SELECT CONCAT(ua.First_Name, ' ', ua.Last_Name)
                    FROM room_schedule rs
                    JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                    WHERE rs.section_ID = %s AND rs.selected_day = %s 
                    AND rs.start_schedule = %s AND rs.end_schedule = %s 
                    AND rs.selected_room_ID = %s AND ua.user_type = 'instructor'
                    LIMIT 1
                """, (section_id, day, start_time, end_time, room_id))
                instructor_result = self.mycursor.fetchone()
                instructor_name = instructor_result[0] if instructor_result else "N/A"

                # Step 5: Get room name
                self.mycursor.execute("""
                    SELECT room FROM tupc_rooms WHERE idroom_names = %s
                """, (room_id,))
                room_result = self.mycursor.fetchone()
                room_name = room_result[0] if room_result else "N/A"

                start_qt = self.format_time(start_time)
                end_qt = self.format_time(end_time)

                for row in range(table.rowCount()):
                    time_item = table.item(row, 0)
                    if not time_item:
                        continue

                    row_time = QTime.fromString(time_item.text(), "HH:mm")
                    if row_time.isValid() and (
                        row_time >= start_qt and row_time < end_qt
                    ):
                        item = QTableWidgetItem(f"{subject}\n{room_name}\n{instructor_name}")
                        item.setTextAlignment(Qt.AlignCenter)
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        table.setItem(row, col, item)
            # Adjust table after loading
            table.resizeRowsToContents()
            table.resizeColumnsToContents()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def format_time(self, value):
        if isinstance(value, timedelta):
            total_seconds = int(value.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return QTime(hours, minutes)
        elif isinstance(value, str):
            return QTime.fromString(value, "HH:mm:ss")
        return QTime()

    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

class InstructorMenu(QMainWindow):
    def __init__(self, user_ID, db_connection, db_cursor):
        super().__init__()
        self.ui = InstructorUI()
        self.ui.setupUi(self)

        # Store the db_connection and cursor for future use
        self.db_connection = db_connection
        self.cursor = db_cursor

        self.user_ID = user_ID   
        self.mydb = db_connection
        self.mycursor = db_cursor

        # UI and button setup
        self.ui.logout_btn.clicked.connect(self.open_logout)
        self.ui.change_pass.clicked.connect(self.open_change_pass)  
        self.ui.send_message_instructor_btn.clicked.connect(self.open_compose)  
        self.ui.instructor_sched_btn.clicked.connect(lambda: self.open_page(0))  # Student view
        self.ui.instructor_info_btn.clicked.connect(lambda: self.open_page(1))  # Instructor view
        self.ui.instructor_inbox_btn.clicked.connect(lambda: self.open_page(2))  # Instructor view

        self.setup_table()
        self.load_instructor_info()
        self.load_instructor_schedule()
        self.load_inbox_messages()
        self.ui.listsent_received_inbox_instructor.itemDoubleClicked.connect(self.show_message_content)
        self.ui.del_messages_instructor.clicked.connect(self.delete_selected_message)

        self.new_window = None

        # QR scanning setup
        self.filter = KeyFilter()
        self.ui.accessed_room_instructor.installEventFilter(self.filter)
        self.ui.accessed_room_instructor.setFocus()
        self.ui.accessed_room_instructor.setText("NOT IN A ROOM")
        self.ui.accessed_room_instructor.setReadOnly(False)
        self.ui.accessed_room_instructor.setStyleSheet("color: red; font-weight: bold;")

        # Connecting to the handler after scan
        print(datetime.now())
        self.ui.accessed_room_instructor.returnPressed.connect(self.handle_scan)
    
    def verify_qr_code(self, scan_data):
        # Parse the QR code data (e.g., "TUPC-1001 CRUZ JOHN INSTRUCTOR")
        parts = scan_data.split()  # ["TUPC-1001", "CRUZ", "JOHN", "INSTRUCTOR"]
        real_ID = parts[0]  # Extract real_ID
        user_type = parts[-1]  # The last part is the user_type (INSTRUCTOR, STAFF, STUDENT)
        
        current_time = datetime.now().time()  # Get current time for validation

        # Fetch the user details (check if user exists in the database)
        self.cursor.execute("SELECT * FROM user_accounts WHERE real_ID = %s", (real_ID,))
        user = self.cursor.fetchone()
        if not user:
            return "Access Denied: User not found."

        # Fetch room schedule based on real_ID (assuming user_room_ID matches real_ID)
        self.cursor.execute("""
            SELECT * FROM room_schedule
            WHERE user_room_ID = %s
            AND start_schedule <= %s
            AND end_schedule >= %s
        """, (real_ID, current_time, current_time))

        room_schedule = self.cursor.fetchone()

        if not room_schedule:
            return "Access Denied: Room is not scheduled or outside the time window."

        # Role-based access control
        if user_type == 'STAFF':
            return "Access Granted"
        elif user_type == 'INSTRUCTOR':
            return "Access Granted"
        elif user_type == 'STUDENT':
            return "Attendance Recorded: Your attendance has been marked."
        else:
            return "Access Denied: Invalid user role."

    def handle_scan(self):
        scan_data = self.ui.accessed_room_instructor.text()
        print(scan_data)
        result = self.verify_qr_code(scan_data)

        if "Access Granted" in result:
            self.ui.accessed_room_instructor.setText("IN A ROOM")
            self.ui.accessed_room_instructor.setStyleSheet("color: green; font-weight: bold;")

            real_ID = scan_data.split()[0]
            self.open_room_attendance_dialog(real_ID)  # Will reset afterward
        else:
            self.ui.accessed_room_instructor.setText("NOT IN A ROOM")
            self.ui.accessed_room_instructor.setStyleSheet("color: red; font-weight: bold;")

    def open_room_attendance_dialog(self, real_ID):
        # Get the current date and time
        current_time = datetime.now().time()
        current_day = datetime.now().strftime('%A')  # e.g., 'Monday'

        # Fetch schedule of the instructor based on current time and day
        self.cursor.execute("""
            SELECT room_id, start_schedule, end_schedule, selected_day 
            FROM room_schedule 
            WHERE user_room_ID = %s 
            AND start_schedule <= %s 
            AND end_schedule >= %s 
            AND selected_day = %s
        """, (real_ID, current_time, current_time, current_day))


        schedule = self.cursor.fetchone()
        if not schedule:
            print("No matching schedule found.")
            return

        room_id, start_schedule, end_schedule, selected_day = schedule

        # Open modal RoomAttendance dialog with the schedule data
        self.new_window = RoomAttendance(self.db_connection, self.cursor, room_id, selected_day, start_schedule, end_schedule)
        self.new_window.exec()
        self.ui.accessed_room_instructor.setText("NOT IN A ROOM")
        self.ui.accessed_room_instructor.setStyleSheet("color: red; font-weight: bold;")

    def clear_schedule_table(self, table):
        for row in range(table.rowCount()):
            for col in range(1, table.columnCount()):
                table.setItem(row, col, QTableWidgetItem(""))

    def format_time(self, value):
        if isinstance(value, timedelta):
            total_seconds = int(value.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return QTime(hours, minutes)
        elif isinstance(value, str):
            return QTime.fromString(value, "HH:mm:ss")
        return QTime()

    def errorDisplay(self, errno, sqlstate, msg):
        self.mydb.rollback()
        """Displays detailed error information to the user."""
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

    def setup_table(self):
        table = self.ui.instructor_room_sched_table   
        table.setColumnCount(6)
        table.setRowCount(14)
        table.setWordWrap(True)
        table.resizeColumnsToContents()
        table.resizeRowsToContents()
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setWordWrap(True)
        table.verticalHeader().setVisible(False)
        table.setHorizontalHeaderLabels(["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
        for i in range(14):  # From 07:00 to 20:00
            hour = 7 + i
            time_str = QTime(hour, 0).toString("HH:mm")
            table.setItem(i, 0, QTableWidgetItem(time_str))

    def load_instructor_info(self):
        try:
            self.mycursor.execute("""
                SELECT real_ID, First_Name, Last_Name, email
                FROM user_accounts
                WHERE real_ID = %s AND user_type = 'instructor'
            """, (self.user_ID,))
            result = self.mycursor.fetchone()
            if result:
                self.ui.tupc_id_lineedit_info_4.setDisabled(True)
                self.ui.first_name_lineedit_nstrctrinfo.setDisabled(True)
                self.ui.last_name_lineedit_nstrctrinfo.setDisabled(True)
                self.ui.email_nstrctr_lineedit_info_4.setDisabled(True)

                self.ui.tupc_id_lineedit_info_4.setText(str(result[0]))
                self.ui.first_name_lineedit_nstrctrinfo.setText(result[1])
                self.ui.last_name_lineedit_nstrctrinfo.setText(result[2])
                self.ui.email_nstrctr_lineedit_info_4.setText(result[3])
            else:
                QMessageBox.warning(None, "Error", "Instructor information not found.")
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_instructor_schedule(self):
        table = self.ui.instructor_room_sched_table
        self.clear_schedule_table(table)

        try:
            self.mycursor.execute("""
                SELECT rs.selected_day, rs.start_schedule, rs.end_schedule, rs.subject_code_purpose, tr.room
                FROM room_schedule rs
                JOIN tupc_rooms tr ON rs.selected_room_ID = tr.idroom_names
                WHERE rs.user_room_ID = %s
            """, (self.user_ID,))
            schedule = self.mycursor.fetchall()

            day_column_map = {
                "Monday": 1, "Tuesday": 2, "Wednesday": 3,
                "Thursday": 4, "Friday": 5
            }

            for day, start_time, end_time, subject, room in schedule:
                col = day_column_map.get(day)
                if col is None:
                    continue

                start_qt = self.format_time(start_time)
                end_qt = self.format_time(end_time)

                for row in range(table.rowCount()):
                    row_time = QTime.fromString(table.item(row, 0).text(), "HH:mm")
                    if row_time.isValid() and start_qt <= row_time < end_qt:
                        display_text = f"{subject}\n({room})"  # Subject + Room below
                        item = QTableWidgetItem(display_text)
                        item.setTextAlignment(Qt.AlignCenter)
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        table.setItem(row, col, item)

            table.resizeRowsToContents()
            table.resizeColumnsToContents() # 🔥 Fit table nicely after loading

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def open_page(self, index):
        self.ui.instructor_menu_stackedwidget.setCurrentIndex(index)
        self.new_window = None

    def open_change_pass(self):
        dialog = ChangePass(self)
        dialog.exec()

    def open_compose(self):
        dialog = RoomRequestInstructor(self.user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()
        self.load_inbox_messages()

    def open_logout(self):
        self.switch_window(MainWindow)

    def switch_window(self, new_window_class):
        if self.new_window:
            self.new_window.close()
        self.new_window = new_window_class()
        self.new_window.show()
        self.close()

    def load_inbox_messages(self):
        self.ui.listsent_received_inbox_instructor.clear()
        self.messages = []

        try:
            self.mycursor.execute("""
                SELECT ri.idrequest_inbox, rr.request_id, rr.requested_room, rr.requested_day,
                    rr.requested_start, rr.requested_end, rr.request_comp_message,
                    rr.time_submitted, rr.replied_message
                FROM request_inbox ri
                JOIN room_requests rr ON ri.request_id = rr.request_id
                WHERE rr.user_ID = %s AND ri.user_type = 'instructor'
                ORDER BY rr.time_submitted DESC
            """, (self.user_ID,))
            request_results = self.mycursor.fetchall()

            for (inbox_id, request_id, room, day, start, end, message, submitted, reply) in request_results:
                subject = f"Request for Room {room} on {day}"
                timestamp = submitted.strftime("%Y-%m-%d %H:%M")

                status = "[REPLIED]" if reply else "[PENDING]"
                display_text = f"{status} {timestamp} - {subject}"
                self.ui.listsent_received_inbox_instructor.addItem(display_text)

                self.messages.append({
                    "inbox_id": inbox_id,
                    "request_id": request_id,
                    "subject": subject,
                    "room": room,
                    "day": day,
                    "start_time": start,
                    "end_time": end,
                    "original_message": message,
                    "submitted": submitted,
                    "replied_message": reply,
                    "timestamp_str": timestamp
                })

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def show_message_content(self, item):
        index = self.ui.listsent_received_inbox_instructor.row(item)
        if 0 <= index < len(self.messages):
            msg = self.messages[index]

            parts = [
                f"Subject: {msg.get('subject', 'Unknown')}",
                f"Date Sent: {msg.get('timestamp_str', 'Unknown')}",
                f"Day: {msg.get('requested_day', 'Unknown')}",
                f"Room: {msg.get('room', 'Unknown')}",
                f"Start Time: {msg.get('time_start', 'Unknown')}",
                f"End Time: {msg.get('time_end', 'Unknown')}",
                "",
                f"Message:\n{msg.get('original_message', 'No message.')}",
            ]

            if msg.get("replied_message"):
                parts += [
                    "",
                    "--- Admin Reply ---",
                    f"{msg.get('replied_message', '')}"
                ]
            else:
                parts.append("\n--- No reply from admin yet ---")

            full_content = "\n".join(parts)
            self.ui.received_message_instructor.setPlainText(full_content)

    def delete_selected_message(self):
        index = self.ui.listsent_received_inbox_instructor.currentRow()
        if index < 0 or index >= len(self.messages):
            QMessageBox.warning(None, "No Selection", "Please select a message to delete.")
            return

        message = self.messages[index]  
        request_id = message.get("request_id")  

        confirm = QMessageBox.question(
            self, "Confirm Deletion",
            "Are you sure you want to delete this message?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm != QMessageBox.Yes:
            return

        try:
            # Delete from inbox first
            self.mycursor.execute("""
                DELETE FROM request_inbox 
                WHERE request_id = %s AND user_type = 'instructor'
            """, (request_id,))
            self.mydb.commit()

            # Then, check if both sides deleted
            self.check_full_deletion(request_id)

            QMessageBox.information(None, "Deleted", "The message has been deleted.")
            self.load_inbox_messages()
            self.ui.received_message_instructor.clear()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def check_full_deletion(self, request_id):
        self.mycursor.execute("""
            SELECT COUNT(*) FROM request_inbox WHERE request_id = %s
        """, (request_id,))
        (remaining_copies,) = self.mycursor.fetchone()

        if remaining_copies == 0:
            # No more inbox copies, safe to delete from main room_requests
            self.mycursor.execute("""
                DELETE FROM room_requests WHERE request_id = %s
            """, (request_id,))
            self.mydb.commit()

    def open_change_pass(self):
            self.change_pass_window = ChangePass(self.user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
            self.change_pass_window.exec()

class KeyFilter(QObject):
    def __init__(self):
        super().__init__()
        self.buffer = ""
        self.last_time = time.time()
        self.max_delay = 0.05  # 50ms threshold for scanner speed

    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress:
            now = time.time()
            delay = now - self.last_time
            self.last_time = now

            key = event.key()
            char = event.text()

            # Accept only rapid input (simulate scanner typing)
            if delay > self.max_delay:
                self.buffer = ""

            if key in (Qt.Key_Return, Qt.Key_Enter):
                obj.setText(self.buffer)
                self.buffer = ""
                return False  # allow returnPressed signal

            if char.isalnum() or char in "- ":
                self.buffer += char
                return True  # block from appearing in the QLineEdit

            return True  # block all other keys
        return False

class StaffMenu(QMainWindow):
    def __init__(self, user_ID, db_connection, db_cursor):
        super().__init__()
        self.ui = StaffUI()
        self.ui.setupUi(self)

        self.user_ID = user_ID   
        self.mydb = db_connection
        self.mycursor = db_cursor

        self.ui.logout_btn.clicked.connect(self.open_logout)
        self.ui.change_pass.clicked.connect(self.open_change_pass)       
        self.ui.compose_staff.clicked.connect(self.open_composerequest)     
        self.ui.compose_message_report_btn.clicked.connect(self.open_composereport)  
        self.ui.staff_sched_btn.clicked.connect(lambda: self.open_page(0))  # Student view
        self.ui.staff_info_btn.clicked.connect(lambda: self.open_page(1))  # Instructor view
        self.ui.staff_inbox_btn.clicked.connect(lambda: self.open_page(2))  # Instructor view
        self.new_window = None
        self.ui.listWidget_2.itemDoubleClicked.connect(self.on_requestreply_selected)
        self.ui.listWidget_3.itemDoubleClicked.connect(self.on_reportreply_selected)
        style = """
            color: Black;
            background-color: white;
            border: 1px solid black;
        """
        self.ui.listWidget_2.setStyleSheet(style)
        self.ui.listWidget_3.setStyleSheet(style)
        self.ui.received_report.setStyleSheet(style)
        self.ui.received_request.setStyleSheet(style)
        self.setup_table()
        self.load_staff_info()
        self.load_staff_schedule()
        self.load_reportreply()
        self.ui.del_report.clicked.connect(self.delete_selected_report_message)
        self.ui.del_request.clicked.connect(self.delete_selected_request_message)
        self.ui.received_report.clear()
        self.ui.received_request.clear()
        self.load_requestreply()

        # QR Scanning
        self.filter = KeyFilter()
        self.ui.room_access_status_staff.installEventFilter(self.filter)
        self.ui.room_access_status_staff.setFocus()
        self.ui.room_access_status_staff.setReadOnly(False)

        self.ui.room_access_status_staff.returnPressed.connect(self.handle_scan)

    def handle_scan(self):
        scanned_text = self.ui.room_access_status_staff.text().strip()
        print(scanned_text)

        if not scanned_text:
            return
        else:
            self.ui.room_access_status_staff.setText(scanned_text)
            print(scanned_text)
        return

    def setup_table(self):
        table = self.ui.staff_room_sched_table  
        table.setColumnCount(6)
        table.setRowCount(14)
        table.setWordWrap(True)
        table.resizeColumnsToContents()
        table.resizeRowsToContents()
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        table.setHorizontalHeaderLabels(["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
        for i in range(14):  # From 07:00 to 20:00
            hour = 7 + i
            time_str = QTime(hour, 0).toString("HH:mm")
            table.setItem(i, 0, QTableWidgetItem(time_str))

    def clear_schedule_table(self, table):
        for row in range(table.rowCount()):
            for col in range(1, table.columnCount()):
                table.setItem(row, col, QTableWidgetItem(""))

    def format_time(self, value):
        if isinstance(value, timedelta):
            total_seconds = int(value.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return QTime(hours, minutes)
        elif isinstance(value, str):
            return QTime.fromString(value, "HH:mm:ss")
        return QTime()

    def load_staff_info(self):
        try:
            self.mycursor.execute("""
                SELECT real_ID, First_Name, Last_Name, email
                FROM user_accounts
                WHERE real_ID = %s AND user_type = 'staff'
            """, (self.user_ID,))
            result = self.mycursor.fetchone()
            if result:
                self.ui.tupc_id_lineedit_info_4.setDisabled(True)
                self.ui.first_name_lineedit_stdntinfo.setDisabled(True)
                self.ui.last_name_lineedit_stdntinfo.setDisabled(True)
                self.ui.email_stdnt_lineedit_info_4.setDisabled(True)

                self.ui.tupc_id_lineedit_info_4.setText(str(result[0]))
                self.ui.first_name_lineedit_stdntinfo.setText(result[1])
                self.ui.last_name_lineedit_stdntinfo.setText(result[2])
                self.ui.email_stdnt_lineedit_info_4.setText(result[3])
            else:
                QMessageBox.warning(None, "Error", "Staff information not found.")
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_staff_schedule(self):
        table = self.ui.staff_room_sched_table
        self.clear_schedule_table(table)

        try:
            self.mycursor.execute("""
                SELECT rs.selected_day, rs.start_schedule, rs.end_schedule, rs.subject_code_purpose, tr.room
                FROM room_schedule rs
                JOIN tupc_rooms tr ON rs.selected_room_ID = tr.idroom_names
                WHERE rs.user_room_ID = %s AND rs.section_ID IS NULL
            """, (self.user_ID,))
            schedule = self.mycursor.fetchall()

            day_column_map = {
                "Monday": 1, "Tuesday": 2, "Wednesday": 3,
                "Thursday": 4, "Friday": 5
            }

            for day, start_time, end_time, subject, room in schedule:
                col = day_column_map.get(day)
                if col is None:
                    continue

                start_qt = self.format_time(start_time)
                end_qt = self.format_time(end_time)

                for row in range(table.rowCount()):
                    row_time = QTime.fromString(table.item(row, 0).text(), "HH:mm")
                    if row_time.isValid() and start_qt <= row_time < end_qt:
                        display_text = f"{subject}\n({room})"  # Subject + Room below
                        item = QTableWidgetItem(display_text)
                        item.setTextAlignment(Qt.AlignCenter)
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        table.setItem(row, col, item)

            table.resizeRowsToContents()
            table.resizeColumnsToContents()  # 🔥 Fit table nicely after loading

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def delete_selected_request_message(self):
        index = self.ui.listWidget_2.currentRow()
        if index < 0 or index >= len(self.request_replies):
            QMessageBox.warning(None, "No Selection", "Please select a message to delete.")
            return

        message = self.request_replies[index]  
        request_id = message.get("request_id")  

        confirm = QMessageBox.question(
            self, "Confirm Deletion",
            "Are you sure you want to delete this message?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm != QMessageBox.Yes:
            return

        try:
            # Delete from inbox first
            self.mycursor.execute("""
                DELETE FROM request_inbox 
                WHERE request_id = %s AND user_type = 'staff'
            """, (request_id,))
            self.mydb.commit()

            # Then, check if both sides deleted
            self.check_full_deletion(request_id)

            QMessageBox.information(None, "Deleted", "The message has been deleted.")
            self.load_requestreply()
            self.ui.received_request.clear()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def check_full_deletion(self, request_id):
        self.mycursor.execute("""
            SELECT COUNT(*) FROM request_inbox WHERE request_id = %s
        """, (request_id,))
        (remaining_copies,) = self.mycursor.fetchone()

        if remaining_copies == 0:
            # No more inbox copies, safe to delete from main room_requests
            self.mycursor.execute("""
                DELETE FROM room_requests WHERE request_id = %s
            """, (request_id,))
            self.mydb.commit()

    def delete_selected_report_message(self):
        index = self.ui.listWidget_3.currentRow()
        if index < 0 or index >= len(self.report_replies):
            QMessageBox.warning(None, "No Selection", "Please select a report message to delete.")
            return

        confirm = QMessageBox.question(
            self, "Confirm Deletion",
            "Are you sure you want to delete this report message?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm != QMessageBox.Yes:
            return

        try:
            message = self.report_replies[index]
            report_inbox_id = message["report_inbox_id"]

            # Delete from report_inbox (not directly room_reports)
            self.mycursor.execute("""
                DELETE FROM report_inbox
                WHERE report_id = %s AND user_type = 'staff'
            """, (report_inbox_id,))
            self.mydb.commit()

            QMessageBox.information(None, "Deleted", "The report message has been deleted.")

            self.load_reportreply()
            self.ui.received_report.clear()
            self.check_full_deletion_report(report_inbox_id)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def check_full_deletion_report(self, report_id):
        self.mycursor.execute("""
            SELECT COUNT(*) FROM report_inbox WHERE report_id = %s
        """, (report_id,))
        (remaining_copies,) = self.mycursor.fetchone()

        if remaining_copies == 0:
            # No more inbox copies, safe to delete from main room_requests
            self.mycursor.execute("""
                DELETE FROM room_reports WHERE reports_id = %s
            """, (report_id,))
            self.mydb.commit()

    def load_requestreply(self):
        self.ui.listWidget_2.clear()
        self.request_replies = []

        try:
            self.mycursor.execute("""
                SELECT ri.idrequest_inbox, rr.request_id, rr.requested_room, rr.requested_day,
                    rr.requested_start, rr.requested_end, rr.request_comp_message,
                    rr.time_submitted, rr.replied_message
                FROM request_inbox ri
                JOIN room_requests rr ON ri.request_id = rr.request_id
                WHERE rr.user_ID = %s AND ri.user_type = 'staff'
                ORDER BY rr.time_submitted DESC
            """, (self.user_ID,))
            request_results = self.mycursor.fetchall()

            for (inbox_id, request_id, room, day, start, end, message, submitted, reply) in request_results:
                subject = f"Request for Room {room} on {day}"
                timestamp = submitted.strftime("%Y-%m-%d %H:%M")

                status = "[REPLIED]" if reply else "[PENDING]"
                display_text = f"{status} {timestamp} - {subject}"
                self.ui.listWidget_2.addItem(display_text)

                self.request_replies.append({
                    "inbox_id": inbox_id,
                    "request_id": request_id,
                    "subject": subject,
                    "room": room,
                    "day": day,
                    "start_time": start,
                    "end_time": end,
                    "original_message": message,
                    "submitted": submitted,
                    "replied_message": reply,
                    "timestamp_str": timestamp
                })

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def on_requestreply_selected(self, item):
        index = self.ui.listWidget_2.row(item)
        if 0 <= index < len(self.request_replies):
            selected_reply = self.request_replies[index]
            full_content = (
                f"Subject: {selected_reply['subject']}\n"
                f"Date Sent: {selected_reply['submitted']}\n"
                f"Day: {selected_reply['day']}\n"
                f"Room: {selected_reply['room']}\n"
                f"Start Time: {selected_reply['start_time']}\n"
                f"End Time: {selected_reply['end_time']}\n\n"
                f"Message:\n{selected_reply['original_message']}\n"
            )

            if selected_reply["replied_message"]:
                full_content += (
                    f"\n--- Admin Reply ---\n"
                    f"{selected_reply['replied_message']}"
                )
            else:
                full_content += "\n--- No reply from admin yet ---"

            self.ui.received_request.setPlainText(full_content)

    def load_reportreply(self):
        self.ui.listWidget_3.clear()
        self.report_replies = []

        try:
            # Load reports from report_inbox joined with room_reports
            self.mycursor.execute("""
                SELECT ri.report_id, rr.report_type, rr.composed_report, rr.time_submitted,
                    rr.replied_message, rr.time_submitted
                FROM report_inbox ri
                JOIN room_reports rr ON ri.report_id = rr.reports_id
                WHERE rr.staff_ID = %s AND ri.user_type = 'staff'
                ORDER BY rr.time_submitted DESC
            """, (self.user_ID,))
            rows = self.mycursor.fetchall()

            for inbox_id, report_type, report_content, time_submit, reply, reply_time in rows:
                time_str = time_submit.strftime("%Y-%m-%d %H:%M")
                status = "[REPLIED]" if reply else "[PENDING]"
                display_text = f"{status} {time_str} - {report_type}"

                self.ui.listWidget_3.addItem(display_text)
                self.report_replies.append({
                    "report_inbox_id": inbox_id,
                    "type": report_type,
                    "content": report_content,
                    "time_submit": time_submit,
                    "time_submit_str": time_str,
                    "reply": reply,
                    "reply_time_str": reply_time.strftime("%Y-%m-%d %H:%M") if reply_time else None
                })

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def on_reportreply_selected(self, item):
        index = self.ui.listWidget_3.row(item)
        if 0 <= index < len(self.report_replies):
            selected_reply = self.report_replies[index]
            full_content = (
                f"Report Type: {selected_reply['type']}\n"
                f"time submitted: {selected_reply['time_submit']}\n"
                f"Message:\n{selected_reply['content']}\n"
            )

            if selected_reply["reply"]:
                full_content += (
                    f"\n--- Admin Reply ---\n"
                    f"{selected_reply['reply']}"
                )
            else:
                full_content += "\n--- No reply from admin yet ---"

            self.ui.received_report.setPlainText(full_content)

    def open_page(self, index):
        self.ui.staff_menu_stackedwidget.setCurrentIndex(index)
        self.new_window = None

    def open_change_pass(self):
        dialog = ChangePass(self.user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec() 

    def open_composerequest(self):
        dialog = RoomRequestStaff(self.user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()
        self.load_requestreply()

    def open_composereport(self):
        dialog = ComposeReport(self.user_ID, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()
        self.load_reportreply()
        
    def open_logout(self):
        self.switch_window(MainWindow)

    def switch_window(self, new_window_class):
        if self.new_window:
            self.new_window.close()
        self.new_window = new_window_class()
        self.new_window.show()
        self.close()

    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

class AdminMenu(QMainWindow):
    def __init__(self, user_ID, db_connection, db_cursor):
        super().__init__()
        self.ui = AdminUI()
        self.ui.setupUi(self)

        self.admin_ID = user_ID
        self.mydb = db_connection
        self.mycursor = db_cursor

        self.student_table_widget = self.ui.stackedWidget.widget(1).findChild(QTableWidget, "list_registered_stdnt")
        self.instructor_table_widget = self.ui.stackedWidget.widget(4).findChild(QTableWidget, "list_registered_instructor")
        self.staff_table_widget = self.ui.stackedWidget.widget(2).findChild(QTableWidget, "list_registered_staff")

        self.student_table_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.instructor_table_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.staff_table_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.student_table_widget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.instructor_table_widget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.staff_table_widget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        student_tab = self.ui.stackedWidget.widget(1)
        self.sort_student = student_tab.findChild(QComboBox, "sort_student")
        self.search_student_btn = student_tab.findChild(QPushButton, "search_student_btn")
        self.search_bar_student = student_tab.findChild(QLineEdit, "search_bar_stdnt")
        self.student_table_widget = student_tab.findChild(QTableWidget, "list_registered_stdnt")

        self.sort_student.currentIndexChanged.connect(self.sort_students)
        self.search_student_btn.clicked.connect(self.search_students)
        self.search_bar_student.textChanged.connect(self.reset_student_search)

        self.ui.sort_instructor.clear()
        self.ui.sort_instructor.addItems(["ID", "First Name", "Last Name", "Email"])

        self.ui.sort_student.clear()
        self.ui.sort_student.addItems(["ID", "First Name", "Last Name", "Email", "Section", "Course", "Year"])

        self.ui.sort_staff.clear()
        self.ui.sort_staff.addItems(["ID", "First Name", "Last Name", "Email"])

        self.ui.sort_instructor.currentIndexChanged.connect(self.sort_instructors)
        self.ui.sort_staff.currentIndexChanged.connect(self.sort_staffs)

        self.ui.search_instructor_btn.clicked.connect(self.search_instructor)
        self.ui.search_bar_instructor.textChanged.connect(self.reset_instructor_search)

        self.ui.search_staff_btn.clicked.connect(self.search_staff)
        self.ui.search_bar_staff.textChanged.connect(self.reset_staff_search)

        self.search_staff_btn = self.ui.stackedWidget.widget(2).findChild(QTableWidget, "search_staff_btn")
        self.search_bar_staff = self.ui.stackedWidget.widget(2).findChild(QTableWidget, "search_bar_staff")
        self.sort_staff = self.ui.stackedWidget.widget(2).findChild(QTableWidget, "sort_staff")

        self.ui.add_rm.clicked.connect(self.add_room) 
        self.ui.del_rm.clicked.connect(self.delete_room)

        self.ui.start_time_instructor.setMinimumTime(QTime(7, 0))
        self.ui.start_time_instructor.setMaximumTime(QTime(20, 0))
        self.ui.start_time_instructor.timeChanged.connect(lambda: self.correct_time_minutes('start_instructor'))
        self.ui.final_time_instructor.setMinimumTime(QTime(8, 0))
        self.ui.final_time_instructor.setMaximumTime(QTime(20, 0))
        self.ui.final_time_instructor.timeChanged.connect(lambda: self.correct_time_minutes('end_instructor'))

        self.ui.start_time_staff.setMinimumTime(QTime(7, 0))
        self.ui.start_time_staff.setMaximumTime(QTime(20, 0))
        self.ui.start_time_staff.timeChanged.connect(lambda: self.correct_time_minutes('start_staff'))
        self.ui.final_time_staff.setMinimumTime(QTime(8, 0))
        self.ui.final_time_staff.setMaximumTime(QTime(20, 0))
        self.ui.final_time_staff.timeChanged.connect(lambda: self.correct_time_minutes('end_staff'))
        
        self.ui.room_btn.clicked.connect(lambda: self.open_page(0)) 
        self.ui.instructor_btn.clicked.connect(lambda: self.open_page(4)) 
        self.ui.student_btn.clicked.connect(lambda: self.open_page(1)) 
        self.ui.staff_btn.clicked.connect(lambda: self.open_page(2)) 
        self.ui.inbox_btn.clicked.connect(lambda: self.open_page(3))

        self.ui.log_rm.clicked.connect(lambda: self.handle_room_action(3))
        self.ui.edit_rm.clicked.connect(lambda: self.handle_room_action(2))
        self.ui.view_sched.clicked.connect(lambda: self.handle_room_action(1))

        self.bck_btn_editsched = self.ui.schedule_stackedwidget.widget(2).findChild(QPushButton, "back_2")
        self.bck_btn_display = self.ui.schedule_stackedwidget.widget(1).findChild(QPushButton, "back")
        self.bck_btn_logs = self.ui.schedule_stackedwidget.widget(3).findChild(QPushButton, "back_3")
        self.bck_btn_editsched.clicked.connect(self.return_roomview)
        self.bck_btn_display.clicked.connect(self.return_roomview)
        self.bck_btn_logs.clicked.connect(self.return_roomview)

        self.add_student = self.ui.schedule_stackedwidget.widget(2).findChild(QPushButton, "add_student")
        self.add_student.clicked.connect(self.open_add_student) 

        self.btn_manage_staff = self.ui.stackedWidget.widget(2).findChild(QPushButton, "manage_staff")
        self.btn_manage_student = self.ui.stackedWidget.widget(1).findChild(QPushButton, "manage_student")
        self.btn_manage_instructor = self.ui.stackedWidget.widget(4).findChild(QPushButton, "manage_instructor")
        self.btn_manage_staff.clicked.connect(self.open_manage_staff) 
        self.btn_manage_student.clicked.connect(self.open_manage_student) 
        self.btn_manage_instructor.clicked.connect(self.open_manage_instructor)
        self.ui.edit_room_sched_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.ui.edit_room_sched_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.edit_room_sched_table.itemDoubleClicked.connect(self.edit_selected_schedule)
        self.ui.room_sched_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.room_sched_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        self.ui.add_sched_instructor.clicked.connect(self.add_instructor_schedule)
        self.ui.add_sched_staff.clicked.connect(self.add_staff_schedule)
        self.setup_schedule_table()
        self.room_view()
        self.load_students_into_table()
        self.load_instructors_into_table()
        self.load_staffs_into_table()
        self.load_rooms_into_list()
        self.ui.room_list.itemChanged.connect(self.save_room_to_db)
        self.ui.room_list.itemChanged.connect(self.edit_room)
        self.ui.logout_btn.clicked.connect(self.open_logout)  
        self.ui.change_instructor_sched.clicked.connect(lambda: self.change_schedule('instructor'))
        self.ui.change_staff_sched.clicked.connect(lambda: self.change_schedule('staff'))

        self.ui.remove_instructor_sched.clicked.connect(self.remove_instructor_schedule)
        self.ui.remove_staff_sched.clicked.connect(self.remove_staff_schedule)
        self.load_reports()
        self.load_requests()
        self.ui.list_requests.itemDoubleClicked.connect(self.on_request_selected)
        self.ui.list_reports.itemDoubleClicked.connect(self.on_report_selected)
        self.ui.send_message_report_btn.clicked.connect(self.send_reportreply)
        self.ui.send_message_requests_btn.clicked.connect(self.send_requestreply)
        self.ui.del_request.clicked.connect(self.delete_selected_request)
        self.ui.del_report.clicked.connect(self.delete_selected_report)  

        self.ui.clear_fills_instructor.clicked.connect(self.cancel_change_instructor)
        self.ui.clear_fills_staff.clicked.connect(self.cancel_change_staffs)

        self.ui.change_instructor_sched.setDisabled(True)
        self.ui.change_staff_sched.setDisabled(True)

        #placeholders for changing schedule
        self.original_selected_day_edit_students = None
        self.original_teacher = None
        self.original_subject_code_edit_students = None
        self.original_start_time_edit_students = None
        self.original_end_time_edit_students = None
        self.original_section_id = None

        self.schedule_attempts = 0 

        self.ui.actionRoom_Schedule.triggered.connect(self.open_export_schedules)
        self.ui.actionSections.triggered.connect(self.open_export_sections)

        # logic for clearing or cancelling
        self.changed_sched_editing = False

        self.original_selected_day_edit_students_for_changing = None
        self.original_end_time_edit_students_for_changing = None
        self.original_start_time_edit_students_for_changing = None
        self.original_teacher_for_changing = None
        self.original_subject_code_edit_students_for_changing = None
        self.original_section_id_for_changing = None
        
        
        # about menu and help
        self.ui.actionAbout.triggered.connect(self.about_info)
        # add schedule
        self.ui.actionAdd_Schedule.triggered.connect(self.add_schedule_info)
        self.ui.actionEdit_Schedule.triggered.connect(self.edit_schedule_info)

        # Room request and report
        self.ui.actionRoom_Request.triggered.connect(self.reply_room_req_info)
        self.ui.actionMaintenance_Damage_Report.triggered.connect(self.maintenance_damage_info)

        # self.ui.actionMaintenance_Damage_Report_2.triggered.connect(self.delete_report_info)

        # registration
        self.ui.actionRegister_Instructor.triggered.connect(self.reg_instructor_info)
        self.ui.actionRegister_Student.triggered.connect(self.reg_student_info)
        self.ui.actionRegister_Staff.triggered.connect(self.reg_staff_info)

        # removing help
        self.ui.actionRoom_Request_2.triggered.connect(self.delete_room_req_info)
        self.ui.actionMaintenance_Damage_Report_2.triggered.connect(self.delete_room_report_info)

        self.ui.actionInstructor_2.triggered.connect(self.remove_inst_on_sched_info)
        self.ui.actionStudent_2.triggered.connect(self.remove_sect_on_sched_info)
        self.ui.actionStaff_2.triggered.connect(self.remove_staff_sched_info)

        self.ui.actionInstructor_3.triggered.connect(self.remove_instructor_info)
        self.ui.actionStudent_3.triggered.connect(self.remove_student_info)
        self.ui.actionStaff_3.triggered.connect(self.remove_staff_info)

    def about_info(self):
        dialog = About()
        dialog.exec()

    def delete_report_info(self):
        dialog = Delete_Report()
        dialog.exec()

    def add_schedule_info(self):
        dialog = Add_schedule()
        dialog.exec()

    def delete_room_report_info(self):
        dialog = Delete_RoomReport()
        dialog.exec()

    def delete_room_req_info(self):
        dialog = Delete_RoomReq()
        dialog.exec()

    def edit_schedule_info(self):
        dialog = Edit_schedule()
        dialog.exec()

    def maintenance_damage_info(self):
        dialog = MaintenanceDamage()
        dialog.exec()

    def remove_instructor_info(self):
        dialog = Remove_Instructor()
        dialog.exec()

    def remove_inst_on_sched_info(self):
        dialog = Remove_Inst_on_sched()
        dialog.exec()

    def remove_section_info(self):
        dialog = RemoveSection()
        dialog.exec()

    def remove_sect_on_sched_info(self):
        dialog = RemoveSectonSched()
        dialog.exec()

    def reg_student_info(self):
        dialog = Reg_Student()
        dialog.exec()

    def reg_instructor_info(self):
        dialog = Reg_instructor()
        dialog.exec()

    def reg_staff_info(self):
        dialog = Reg_Staff()
        dialog.exec()

    def reply_room_req_info(self):
        dialog = Reply_Room_Req()
        dialog.exec()

    def remove_staff_sched_info(self):
        dialog = Remove_staff_sched()
        dialog.exec()

    def remove_staff_info(self):
        dialog = Remove_staff()
        dialog.exec()

    def remove_student_info(self):
        dialog = Remove_Student()
        dialog.exec()

    def room_req_info(self):
        dialog = RoomReq()
        dialog.exec()

    def reply_room_maint_dam_info(self):
        dialog = Reply_RoomMaint_Dam()
        dialog.exec()

        
    def correct_time_minutes(self, timeedit):
        if timeedit == "start_instructor":
            time_edit = self.ui.start_time_instructor
        elif timeedit == "end_instructor":
            time_edit = self.ui.final_time_instructor
        elif timeedit == "start_staff":
            time_edit = self.ui.start_time_staff
        else:
            time_edit = self.ui.final_time_staff
        current_time = time_edit.time()
        corrected_time = QTime(current_time.hour(), 0)
        if current_time.minute() != 0:
            time_edit.setTime(corrected_time)

    def errorDisplay(self, errno, sqlstate, msg):
        self.mydb.rollback()
        """Displays detailed error information to the user."""
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

    def load_rooms_into_list(self):
        try:
            self.ui.room_list.clear()
            self.mycursor.execute("SELECT room FROM tupc_rooms")
            for (room_name,) in self.mycursor.fetchall():
                item = QListWidgetItem(room_name)
                item.setTextAlignment(Qt.AlignCenter)
                font = QFont()
                font.setPointSize(12)
                item.setFont(font)

                item.setData(Qt.UserRole, room_name)  # Store original name
                self.ui.room_list.addItem(item)
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def save_room_to_db(self, item):
        room_name = item.text().strip()

        if not room_name:
            QMessageBox.warning(None, "Invalid Room Name", "Room name cannot be empty.")
            return

        try:
            # Check if the room already exists
            check_query = "SELECT COUNT(*) FROM tupc_rooms WHERE room = %s"
            self.mycursor.execute(check_query, (room_name,))
            (exists,) = self.mycursor.fetchone()

            if exists:
                return  # Room already exists, no need to insert again

            # Insert new room into database
            insert_query = "INSERT INTO tupc_rooms (room) VALUES (%s)"
            self.mycursor.execute(insert_query, (room_name,))
            self.mydb.commit()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def edit_room(self, item):
        new_name = item.text().strip()

        if not new_name:
            QMessageBox.warning(None, "Invalid Room Name", "Room name cannot be empty.")
            self.load_rooms_into_list()
            return

        # Get original name (before it was changed)
        old_name = item.data(Qt.UserRole)  # Stored when item was first added/loaded

        if not old_name or old_name == new_name:
            return  # No change, or missing original name

        try:
            # Check for duplicates
            check_query = "SELECT COUNT(*) FROM tupc_rooms WHERE room = %s"
            self.mycursor.execute(check_query, (new_name,))
            (exists,) = self.mycursor.fetchone()

            if exists:
                QMessageBox.warning(None, "Duplicate Room", f"'{new_name}' already exists.")
                self.load_rooms_into_list()
                return

            # Perform the update
            update_query = "UPDATE tupc_rooms SET room = %s WHERE room = %s"
            self.mycursor.execute(update_query, (new_name, old_name))
            self.mydb.commit()

            # Update stored original name
            item.setData(Qt.UserRole, new_name)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def delete_room(self):
        selected_item = self.ui.room_list.currentItem()
        if selected_item:
            room_name = selected_item.text().strip()

            confirmation = QMessageBox.question(
                self, 
                "Confirm Deletion", 
                f"Are you sure you want to delete the room '{room_name}' and all associated schedules?",
                QMessageBox.Yes | QMessageBox.No
            )

            if confirmation == QMessageBox.Yes:
                try:
                    # Step 1: Get the room's ID
                    self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (room_name,))
                    result = self.mycursor.fetchone()
                    if not result:
                        QMessageBox.warning(None, "Error", "Room not found in database.")
                        return
                    room_id = result[0]

                    # Step 2: Delete all schedules associated with this room
                    self.mycursor.execute("DELETE FROM room_schedule WHERE selected_room_ID = %s", (room_id,))

                    # Step 3: Delete the room
                    self.mycursor.execute("DELETE FROM tupc_rooms WHERE room = %s", (room_name,))
                    self.mydb.commit()

                    # Step 4: Remove from the list widget
                    row = self.ui.room_list.row(selected_item)
                    self.ui.room_list.takeItem(row)

                    QMessageBox.information(None, "Success", f"Room '{room_name}' and its schedules were deleted.")

                except mysql.connector.Error as err:
                    self.errorDisplay(err.errno, err.sqlstate, err.msg)
        else:
            QMessageBox.warning(None, "Warning", "Please select a room to delete.")

    def convert_to_qtime(self, value):
        if isinstance(value, str):
            return QTime.fromString(value[:5], "HH:mm")
        elif hasattr(value, 'seconds'):
            # It's a timedelta (convert seconds to hours and minutes)
            total_minutes = value.seconds // 60
            return QTime(total_minutes // 60, total_minutes % 60)
        elif hasattr(value, 'hour'):
            # It's likely a datetime.time
            return QTime(value.hour, value.minute)
        else:
            return QTime()  # default invalid time

    def handle_room_action(self, page_index):
        try:
            selected_room = self.ui.room_list.currentItem()
            self.index = page_index
            if not selected_room:
                QMessageBox.warning(None, "No Room Selected", "Please select a room first.")
                return
            self.selected_room =  selected_room.text()
            self.mycursor.execute("SELECT room FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            result = self.mycursor.fetchone()
            if result:
                if self.index == 2:
                    self.load_schedule()
                elif self.index == 1:
                    self.view_schedule()
                else:
                    self.room_logs()
                self.open_roompage(self.index)
            else:
                QMessageBox.warning(None, "Room Not Found", f"Room '{self.selected_room}' not found")

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def view_schedule(self):
        self.ui.accessed_room_sched_lineedit.setText(self.selected_room)
        table = self.ui.room_sched_table
        # Clear all cells except the time column (column 0)
        for row in range(table.rowCount()):
            for col in range(1, table.columnCount()):
                table.setItem(row, col, QTableWidgetItem(""))
        try:
            # Get the room_nameID from tupc_rooms using the selected room name
            room_name_query = "SELECT idroom_names FROM tupc_rooms WHERE room = %s"
            self.mycursor.execute(room_name_query, (self.selected_room,))
            result = self.mycursor.fetchone()

            if not result:
                QMessageBox.warning(None, "Error", f"Room '{self.selected_room}' not found in database.")
                return

            selected_room_id = result[0]  # Foreign key for room_schedule

            # Retrieve schedule details along with user's full name
            schedule_query = """
                SELECT rs.selected_day, rs.start_schedule, rs.end_schedule,
                    CONCAT(ua.First_Name, ' ', ua.Last_Name) AS full_name,
                    rs.subject_code_purpose
                FROM room_schedule rs
                INNER JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.selected_room_ID = %s AND (ua.user_type = 'staff' OR ua.user_type = 'instructor') 
            """
            self.mycursor.execute(schedule_query, (selected_room_id,))
            schedule_data = self.mycursor.fetchall()

            # Map days to columns
            day_column_map = {
                "Monday": 1,
                "Tuesday": 2,
                "Wednesday": 3,
                "Thursday": 4,
                "Friday": 5
            }
            for day, start_time_db, end_time_db, user_name, purpose in schedule_data:
                day_col = day_column_map.get(day)
                if day_col is None:
                    continue

                start_time = self.convert_to_qtime(start_time_db)
                end_time = self.convert_to_qtime(end_time_db)

                # Fill the table rows
                for row in range(table.rowCount()):
                    row_time_item = table.item(row, 0)
                    if not row_time_item:
                        continue

                    row_time = QTime.fromString(row_time_item.text(), "HH:mm")
                    if row_time.isValid() and start_time <= row_time < end_time:
                        item = QTableWidgetItem(f"{user_name}:\n{purpose}")
                        table.setItem(row, day_col, item)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_schedule(self):
        table = self.ui.edit_room_sched_table
        # Clear all cells except the time column (column 0)
        for row in range(table.rowCount()):
            for col in range(1, table.columnCount()):
                table.setItem(row, col, QTableWidgetItem(""))
        try:
            # Get the room_nameID from tupc_rooms using the selected room name
            room_name_query = "SELECT idroom_names FROM tupc_rooms WHERE room = %s"
            self.mycursor.execute(room_name_query, (self.selected_room,))
            result = self.mycursor.fetchone()

            if not result:
                QMessageBox.warning(None, "Error", f"Room '{self.selected_room}' not found in database.")
                return

            selected_room_id = result[0]  # Foreign key for room_schedule

            # Retrieve schedule details along with user's full name
            schedule_query = """
                SELECT rs.selected_day, rs.start_schedule, rs.end_schedule,
                    CONCAT(ua.First_Name, ' ', ua.Last_Name) AS full_name,
                    rs.subject_code_purpose
                FROM room_schedule rs
                INNER JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.selected_room_ID = %s AND ua.user_type IN ('instructor', 'staff')
            """
            self.mycursor.execute(schedule_query, (selected_room_id,))
            schedule_data = self.mycursor.fetchall()

            # Map days to columns
            day_column_map = {
                "Monday": 1,
                "Tuesday": 2,
                "Wednesday": 3,
                "Thursday": 4,
                "Friday": 5
            }
            for day, start_time_db, end_time_db, user_name, purpose in schedule_data:
                day_col = day_column_map.get(day)
                if day_col is None:
                    continue

                start_time = self.convert_to_qtime(start_time_db)
                end_time = self.convert_to_qtime(end_time_db)

                # Fill the table rows
                for row in range(table.rowCount()):
                    row_time_item = table.item(row, 0)
                    if not row_time_item:
                        continue

                    row_time = QTime.fromString(row_time_item.text(), "HH:mm")
                    if row_time.isValid() and start_time <= row_time < end_time:
                        item = QTableWidgetItem(f"{user_name}:\n{purpose}")
                        table.setItem(row, day_col, item)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def check_students_if_added(self):
        self.selected_day = self.ui.instructor_day_edit_comboBox.currentText().strip()
        self.selected_time_start = self.ui.start_time_instructor.time()
        self.selected_time_end = self.ui.final_time_instructor.time()

        try:
            # Validate original values
            if None in (
                self.original_selected_day_edit_students,
                self.original_start_time_edit_students,
                self.original_end_time_edit_students,
                self.original_subject_code_edit_students,
                self.original_teacher
            ):
                QMessageBox.warning(None, "Error", "Missing original schedule reference.")
                return False
            
            # Step 1: Get Room ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            room_id_result = self.mycursor.fetchone()
            if not room_id_result:
                QMessageBox.warning(None, "Error", "Selected room not found in database.")
                return False
            selected_room_id = room_id_result[0]

            # Step 2: Format the times consistently as strings for database comparison
            # Format the original times as strings
            original_start_str = str(self.original_start_time_edit_students)
            original_end_str = str(self.original_end_time_edit_students)
            original_day = self.original_selected_day_edit_students

            # Query to check if there are students scheduled at this time
            self.mycursor.execute("""
                SELECT rs.user_room_ID
                FROM room_schedule rs
                JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.selected_day = %s
                AND rs.selected_room_ID = %s
                AND rs.start_schedule = %s
                AND rs.end_schedule = %s
                AND ua.user_type = 'student'
                AND rs.section_ID IS NOT NULL
                LIMIT 1
            """, (
                original_day,
                selected_room_id,
                original_start_str,
                original_end_str
            ))

            result = self.mycursor.fetchone()
            return result is not None

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
            return False

    def add_instructor_schedule(self):
        self.assigned_instructor = self.ui.assign_instructor.text()
        self.subject_code = self.ui.assign_subject.text()
        self.selected_day = self.ui.instructor_day_edit_comboBox.currentText().strip()
        self.selected_time_start = self.ui.start_time_instructor.time()
        self.selected_time_end = self.ui.final_time_instructor.time()

        # Basic validation
        if not (self.assigned_instructor and self.subject_code):
            QMessageBox.warning(None, "Missing Information", "Please fill in all required fields.")
            return
        elif not self.selected_day:
            QMessageBox.warning(None, "Missing Information", "Please select a day.")
            return
        elif self.selected_time_start >= self.selected_time_end:
            QMessageBox.warning(None, "Invalid Time", "Start time must be before end time.")
            return

        # First check if students are added
        if not self.check_students_if_added():
            QMessageBox.warning(None, "Error", "Students must be added to schedule before adding the instructor.")
            return

        try:
            # Get room ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            room_id_result = self.mycursor.fetchone()
            if not room_id_result:
                QMessageBox.warning(None, "Error", "Selected room not found in database.")
                return
            selected_room_id = room_id_result[0]

            # Prepare time strings for database operations
            start_time_str = self.selected_time_start.toString("HH:mm:ss")
            end_time_str = self.selected_time_end.toString("HH:mm:ss")

            # FIX: Correct conflict check for instructors - time overlap logic
            self.mycursor.execute("""
                SELECT COUNT(*) FROM room_schedule
                WHERE selected_room_ID = %s AND selected_day = %s AND section_ID IS NULL
                AND (
                    (start_schedule <= %s AND end_schedule > %s) OR
                    (start_schedule < %s AND end_schedule >= %s) OR
                    (start_schedule >= %s AND end_schedule <= %s)
                )
            """, (
                selected_room_id,
                self.selected_day,
                start_time_str, start_time_str,  # Case 1: Existing schedule starts before or at our start time and ends after our start
                end_time_str, end_time_str,      # Case 2: Existing schedule starts before our end and ends after or at our end
                start_time_str, end_time_str     # Case 3: Existing schedule is entirely within our time range
            ))
            
            conflict_count = self.mycursor.fetchone()[0]
            if conflict_count > 0:
                self.schedule_attempts += 1
                self.store_original_schedule()  # Always store original regardless of attempts
                QMessageBox.warning(None, "Schedule Conflict", "This time slot is already occupied.")
                return
            
            # Get instructor ID
            self.mycursor.execute("""
                SELECT real_ID FROM user_accounts
                WHERE CONCAT(First_Name, ' ', Last_Name) = %s
            """, (self.assigned_instructor,))
            instructor_id_result = self.mycursor.fetchone()
            if not instructor_id_result:
                QMessageBox.warning(None, "Error", "Instructor not found.")
                return
            instructor_id = instructor_id_result[0]

            # FIX: Check if instructor has conflicting schedule in ANY room - corrected overlap logic
            self.mycursor.execute("""
                SELECT COUNT(*) FROM room_schedule 
                WHERE user_room_ID = %s AND selected_day = %s
                AND (
                    (start_schedule <= %s AND end_schedule > %s) OR
                    (start_schedule < %s AND end_schedule >= %s) OR
                    (start_schedule >= %s AND end_schedule <= %s)
                )
            """, (
                instructor_id,
                self.selected_day,
                start_time_str, start_time_str,  # Case 1
                end_time_str, end_time_str,      # Case 2
                start_time_str, end_time_str     # Case 3
            ))

            conflict_count = self.mycursor.fetchone()[0]
            if conflict_count > 0:
                self.schedule_attempts += 1
                self.store_original_schedule()  # Always store original regardless of attempts
                QMessageBox.warning(None, "Schedule Conflict", "Instructor's schedule is already occupied.")
                return

            # Get section ID for this time slot
            self.mycursor.execute("""
                SELECT section_ID
                FROM room_schedule
                WHERE selected_day = %s
                AND start_schedule = %s
                AND end_schedule = %s
                AND selected_room_ID = %s
                AND section_ID IS NOT NULL
                LIMIT 1
            """, (
                self.selected_day,
                start_time_str,
                end_time_str,
                selected_room_id
            ))
            section_result = self.mycursor.fetchone()
            section_id = section_result[0] if section_result else None

            # if section_id is None:
            #     QMessageBox.warning(None, "Error", "Could not find matching student section for this time slot. Please recheck the data used in adding schedule")
            #     return

            # Check if the same instructor schedule already exists
            self.mycursor.execute("""
                SELECT COUNT(*) FROM room_schedule
                WHERE user_room_ID = %s AND selected_day = %s AND selected_room_ID = %s
                AND start_schedule = %s AND end_schedule = %s
            """, (
                instructor_id,
                self.selected_day,
                selected_room_id,
                start_time_str,
                end_time_str
            ))
            existing_sched_count = self.mycursor.fetchone()[0]

            if existing_sched_count > 0:
                QMessageBox.warning(None, "Duplicate", "This instructor already has a schedule at this time.")
                self.clear_instructor_fields()
                return

            # Insert instructor schedule
            self.mycursor.execute("""
                INSERT INTO room_schedule 
                (subject_code_purpose, selected_day, start_schedule, end_schedule, user_room_ID, selected_room_ID, section_ID)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                self.subject_code,
                self.selected_day,
                start_time_str,
                end_time_str,
                instructor_id,
                selected_room_id,
                section_id
            ))

            # Update student schedules if needed (original schedule exists)
            if None not in (self.original_selected_day_edit_students, self.original_teacher, 
                            self.original_subject_code_edit_students,
                            self.original_start_time_edit_students, self.original_end_time_edit_students):

                original_start_time_str = self.original_start_time_edit_students
                original_end_time_str = self.original_end_time_edit_students

                # Fetch the section ID for the original schedule (based on original values)
                self.mycursor.execute("""
                    SELECT section_ID
                    FROM room_schedule
                    WHERE selected_day = %s
                    AND start_schedule = %s
                    AND end_schedule = %s
                    AND selected_room_ID = %s
                    AND section_ID IS NOT NULL
                    LIMIT 1
                """, (
                    self.original_selected_day_edit_students,
                    original_start_time_str,
                    original_end_time_str,
                    selected_room_id
                ))
                section_result = self.mycursor.fetchone()

                if section_result:
                    # Update the student schedules based only on section_ID
                    section_id = section_result[0]
                    with self.mydb.cursor() as cursor_update_students:
                        cursor_update_students.execute("""
                            UPDATE room_schedule rs
                            JOIN section_junction sj ON rs.user_room_ID = sj.student_ID
                            SET rs.selected_day = %s,
                                rs.start_schedule = %s,
                                rs.end_schedule = %s,
                                rs.subject_code_purpose = %s
                            WHERE sj.section_ID = %s
                            AND rs.section_ID = %s
                            AND rs.selected_day = %s
                            AND rs.start_schedule = %s
                            AND rs.end_schedule = %s
                            AND rs.selected_room_ID = %s
                        """, (
                            self.selected_day,            # New day
                            start_time_str,               # New start
                            end_time_str,                 # New end
                            self.subject_code,            # New subject

                            section_id,                   # Section to update
                            section_id,                   # Match correct section again

                            self.original_selected_day_edit_students,
                            original_start_time_str,
                            original_end_time_str,
                            selected_room_id
                        ))

                        if cursor_update_students.rowcount == 0:
                            pass
                            # QMessageBox.warning(None, "No Update", "No student schedules were updated. Please check if the original schedule still exists.")

            # Reset schedule attempts counter
            self.schedule_attempts = 0
            self.mydb.commit()

            QMessageBox.information(None, "Success", "Instructor schedule saved.")
            self.clear_instructor_fields()
            self.load_schedule()
            self.original_selected_day_edit_students = None
            self.original_teacher = None
            self.original_subject_code_edit_students = None
            self.original_start_time_edit_students = None
            self.original_end_time_edit_students = None

        except mysql.connector.Error as err:
            self.mydb.rollback()  # Added rollback on error
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def store_original_schedule(self):
        self.original_selected_day_edit_students = self.selected_day
        self.original_teacher = self.assigned_instructor
        self.original_subject_code_edit_students = self.subject_code
        self.original_start_time_edit_students = self.selected_time_start
        self.original_end_time_edit_students = self.selected_time_end

    def room_view(self):
        table_view = self.ui.edit_room_sched_table
        table_view.setColumnCount(6)
        table_view.setRowCount(14)
        table_view.setHorizontalHeaderLabels(["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
        for i in range(14):  # From 07:00 to 20:00
            hour = 7 + i
            time_str = QTime(hour, 0).toString("HH:mm")
            table_view.setItem(i, 0, QTableWidgetItem(time_str))

    def setup_schedule_table(self):
        table = self.ui.room_sched_table      
        table.setColumnCount(6)
        table.setRowCount(14)
        table.setHorizontalHeaderLabels(["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
        for i in range(14):  # From 07:00 to 20:00
            hour = 7 + i
            time_str = QTime(hour, 0).toString("HH:mm")
            table.setItem(i, 0, QTableWidgetItem(time_str))

    def add_staff_schedule(self):
        self.assigned_staff = self.ui.assign_staff.text()
        self.purpose = self.ui.assign_maintenance.text()
        self.selected_day_staff = self.ui.day_edit_staff.currentText()
        self.selected_time_start_staff = self.ui.start_time_staff.time()
        self.selected_time_end_staff = self.ui.final_time_staff.time()
        if not (self.assigned_staff and self.purpose):
            QMessageBox.warning(None, "Missing Information", "Please fill in all required fields.")
            return
        elif not self.selected_day_staff:
            QMessageBox.warning(None, "Missing Information", "Please select a day.")
            return
        elif self.selected_time_start_staff >= self.selected_time_end_staff:
            QMessageBox.warning(None, "Invalid Time", "Start time must be before end time.")
            return

        try:
            # Get selected_room_ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            room_id_result = self.mycursor.fetchone()
            if not room_id_result:
                QMessageBox.warning(None, "Error", "Selected room not found in database.")
                return
            selected_room_id = room_id_result[0]

            # Conflict check
            conflict_query = """
                SELECT COUNT(*) FROM room_schedule
                WHERE selected_room_ID = %s AND selected_day = %s AND section_ID IS NULL
                AND (start_schedule < %s AND end_schedule > %s)
            """
            self.mycursor.execute(conflict_query, (
                selected_room_id,
                self.selected_day_staff,
                self.selected_time_end_staff.toString("HH:mm"),
                self.selected_time_start_staff.toString("HH:mm")        
            ))
            (conflict_count,) = self.mycursor.fetchone()
            if conflict_count > 0:
                QMessageBox.warning(None, "Schedule Conflict", "This time slot is already occupied.")
                return

            # Get staff real_ID
            self.mycursor.execute("""
                SELECT real_ID FROM user_accounts
                WHERE CONCAT(First_Name, ' ', Last_Name) = %s
            """, (self.assigned_staff,))
            staff_id_result = self.mycursor.fetchone()
            if not staff_id_result:
                QMessageBox.warning(None, "Error", "Staff member not found.")
                return
            staff_id = staff_id_result[0]
            
             # Conflict check TO OTHER ROOMS
            conflict_query = """
                SELECT COUNT(*) FROM room_schedule
                WHERE user_room_ID = %s AND selected_day = %s AND section_ID IS NULL 
                AND (start_schedule < %s AND end_schedule > %s)
            """
            self.mycursor.execute(conflict_query, (
                staff_id,
                self.selected_day_staff,
                self.selected_time_end_staff.toString("HH:mm"),
                self.selected_time_start_staff.toString("HH:mm")
            ))
            (conflict_count,) = self.mycursor.fetchone()
            if conflict_count > 0:
                QMessageBox.warning(None, "Schedule Conflict", "Staffs schedule is already occupied in other room.")
                return

            # Insert schedule
            insert_query = """
                INSERT INTO room_schedule 
                (subject_code_purpose, selected_day, start_schedule, end_schedule, user_room_ID, section_ID, selected_room_ID)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            self.mycursor.execute(insert_query, (
                self.purpose,
                self.selected_day_staff,
                self.selected_time_start_staff.toString("HH:mm"),
                self.selected_time_end_staff.toString("HH:mm"),
                staff_id,
                None,
                selected_room_id
            ))
            self.mydb.commit()
            QMessageBox.information(None, "Success", "Staff schedule saved.")
            self.clear_staff_fields()
            self.load_schedule()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def sort_students(self):
        """Sort students based on the selected category."""
        category = self.ui.sort_student.currentText()  # ✅ Get the selected text correctly

        sorting_map = {
            "ID": 0,
            "First Name": 1,
            "Last Name": 2,
            "Email": 3,
            "Section": 4,
            "Course": 5,  
            "Year": 6
        }

        if category in sorting_map:
            self.ui.list_registered_stdnt.sortItems(sorting_map[category], Qt.AscendingOrder)

    def room_logs(self):
        self.ui.accessed_room_logs_lineedit.setText(self.selected_room)

    def search_students(self):
        """Search students based on input in the search bar."""
        query = self.search_bar_student.text().strip().lower()

        for row in range(self.student_table_widget.rowCount()):
            match = False
            for col in range(self.student_table_widget.columnCount()):
                item = self.student_table_widget.item(row, col)
                if item and query in item.text().strip().lower():
                    match = True
                    break
            self.student_table_widget.setRowHidden(row, not match)

    def reset_student_search(self):
        """Reset search filter when search bar is cleared."""
        if not self.search_bar_student.text().strip():
            for row in range(self.student_table_widget.rowCount()):
                self.student_table_widget.setRowHidden(row, False)
        
        query = self.search_bar_student.text().strip().lower()

        for row in range(self.student_table_widget.rowCount()):
            match = False
            for col in range(self.student_table_widget.columnCount()):
                item = self.student_table_widget.item(row, col)
                if item and query in item.text().strip().lower():
                    match = True
                    break
            self.student_table_widget.setRowHidden(row, not match)

    def reset_instructor_search(self):
        """Reset the instructor table when the search bar is cleared."""
        search_text = self.ui.search_bar_instructor.text().strip().lower()
        if not search_text:
            for row in range(self.instructor_table_widget.rowCount()):
                self.instructor_table_widget.setRowHidden(row, False)

        for row in range(self.instructor_table_widget.rowCount()):
            match_found = False
            for col in range(self.instructor_table_widget.columnCount()):
                item = self.instructor_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # No need to check other columns if there's a match

            self.instructor_table_widget.setRowHidden(row, not match_found)

    def search_instructor(self):
        """Search for an instructor by ID, First Name, Last Name, or Email."""
        search_text = self.ui.search_bar_instructor.text().strip().lower()

        if not search_text:
            QMessageBox.warning(None, "Warning", "Please enter a search term.")
            return

        found = False
        for row in range(self.instructor_table_widget.rowCount()):
            match_found = False
            for col in range(self.instructor_table_widget.columnCount()):
                item = self.instructor_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # No need to check other columns if there's a match

            self.instructor_table_widget.setRowHidden(row, not match_found)
            if match_found:
                found = True

        if not found:
            QMessageBox.information(None, "No Results", "No matching instructor found.")

    def sort_instructors(self):
        """Sort instructors based on the selected category."""
        category = self.ui.sort_instructor.currentText()
        sorting_map = {
            "ID": 0,
            "First Name": 1,
            "Last Name": 2,
            "Email": 3
        }
        
        if category in sorting_map:
            self.ui.list_registered_instructor.sortItems(sorting_map[category], Qt.AscendingOrder)

    def sort_staffs(self):
        """Sort staff members based on the selected category."""
        staff_sort_combo = self.ui.stackedWidget.widget(2).findChild(QComboBox, "sort_staff")

        if not staff_sort_combo:
            return  # Exit if the combo box is not found

        category = staff_sort_combo.currentText()
        sorting_map = {
            "ID": 0,
            "First Name": 1,
            "Last Name": 2,
            "Email": 3
        }

        if category in sorting_map:
            self.staff_table_widget.sortItems(sorting_map[category], Qt.AscendingOrder)
    
    def reset_staff_search(self):
        """Reset the staff table when the search bar is cleared."""
        search_bar_staff = self.ui.stackedWidget.widget(2).findChild(QLineEdit, "search_bar_staff")

        if not search_bar_staff:
            return  # Exit if search bar is not found

        search_text = search_bar_staff.text().strip().lower()
        if not search_text:
            for row in range(self.staff_table_widget.rowCount()):
                self.staff_table_widget.setRowHidden(row, False)

        for row in range(self.staff_table_widget.rowCount()):
            match_found = False
            for col in range(self.staff_table_widget.columnCount()):
                item = self.staff_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # Stop checking other columns if match found

            self.staff_table_widget.setRowHidden(row, not match_found)

    def search_staff(self):
        """Search for a staff member by ID, First Name, Last Name, or Email."""
        search_bar_staff = self.ui.stackedWidget.widget(2).findChild(QLineEdit, "search_bar_staff")

        if not search_bar_staff:
            return  # Exit if search bar is not found

        search_text = search_bar_staff.text().strip().lower()

        if not search_text:
            QMessageBox.warning(None, "Warning", "Please enter a search term.")
            return

        found = False
        for row in range(self.staff_table_widget.rowCount()):
            match_found = False
            for col in range(self.staff_table_widget.columnCount()):
                item = self.staff_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # Stop checking other columns if match found

            self.staff_table_widget.setRowHidden(row, not match_found)
            if match_found:
                found = True

        if not found:
            QMessageBox.information(None, "No Results", "No matching staff member found.")

# REGISTRATION PART

    def open_manage_staff(self):
        dialog = StaffRegistration(parent=self, db_connection=self.mydb, db_cursor=self.mycursor)   
        dialog.exec()
        self.load_staffs_into_table()

    def open_manage_student(self):
        dialog = StudentRegistration(parent=self, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()
        self.load_students_into_table()

    def open_manage_instructor(self):
        dialog = InstructorRegistration(parent=self, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()  
        self.load_instructors_into_table()

    def open_roompage(self, index):
        self.ui.schedule_stackedwidget.setCurrentIndex(index)

    def return_roomview(self):
        self.ui.schedule_stackedwidget.setCurrentIndex(0)
        self.clear_instructor_fields()
        self.clear_staff_fields()

# actions on Menu Bar

    def open_export_schedules(self):
        dialog = Export_schedule(parent=self, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()

    def open_export_sections(self):
        dialog = Export_sections(parent=self, db_connection=self.mydb, db_cursor=self.mycursor)
        dialog.exec()

# """PART OF ROOM SCHEDULING"""

    def cancel_change_instructor(self): # TO DO, paayos na lang ulit ako dito, may bug akong nahanap
        try:
            if self.changed_sched_editing is True:
                # Fetch original room ID
                self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
                room_result = self.mycursor.fetchone()
                if not room_result:
                    return
                selected_room_id = room_result[0]

                # Step 1: Get instructor ID
                self.mycursor.execute("""
                    SELECT real_ID FROM user_accounts
                    WHERE CONCAT(First_Name, ' ', Last_Name) = %s
                """, (self.original_teacher_for_changing,))
                instructor_result = self.mycursor.fetchone()
                if not instructor_result:
                    QMessageBox.warning(None, "Error", "Original instructor not found.")
                    return
                instructor_id = instructor_result[0]

                # Step 2: Get original section_ID from the instructor's schedule
                self.mycursor.execute("""
                    SELECT section_ID FROM room_schedule
                    WHERE selected_day = %s
                    AND start_schedule = %s
                    AND end_schedule = %s
                    AND subject_code_purpose = %s
                    AND selected_room_ID = %s
                    AND user_room_ID = %s
                    AND section_ID IS NOT NULL
                    LIMIT 1
                """, (
                    self.original_selected_day_edit_students,
                    str(self.original_start_time_edit_students),
                    str(self.original_end_time_edit_students),
                    self.original_subject_code_edit_students,
                    selected_room_id,
                    instructor_id
                ))
                section_result = self.mycursor.fetchone()
                if not section_result:
                    QMessageBox.warning(None, "Error", "Original section not found.")
                    return
                section_id = section_result[0]

                self.mycursor.execute("""
                    UPDATE room_schedule rs
                    JOIN section_junction sj ON rs.user_room_ID = sj.student_ID
                    SET rs.selected_day = %s,
                        rs.start_schedule = %s,
                        rs.end_schedule = %s,
                        rs.subject_code_purpose = %s,
                        rs.selected_room_ID = %s,
                        rs.section_ID = %s
                    WHERE rs.user_room_ID = sj.student_ID
                    AND sj.section_ID = %s
                """, (
                    self.original_selected_day_edit_students_for_changing,
                    str(self.original_start_time_edit_students_for_changing),
                    str(self.original_end_time_edit_students_for_changing),
                    self.original_subject_code_edit_students_for_changing,
                    selected_room_id,
                    self.original_section_id_for_changing,         # set section_id
                    section_id          # confirm match with student-section
                ))
                self.mydb.commit()
            else:
                # Remove student schedule if section was added but not finalized
                if None not in (
                    self.original_selected_day_edit_students,
                    self.original_start_time_edit_students,
                    self.original_end_time_edit_students,
                    self.original_subject_code_edit_students,
                    self.original_teacher
                ):
                    self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
                    room_result = self.mycursor.fetchone()
                    if room_result:
                        selected_room_id = room_result[0]

                        self.mycursor.execute("""
                            DELETE FROM room_schedule 
                            WHERE selected_day = %s
                            AND start_schedule = %s
                            AND end_schedule = %s
                            AND selected_room_ID = %s
                            AND subject_code_purpose = %s
                            AND user_room_ID IN (
                                SELECT real_ID FROM user_accounts WHERE user_type = 'student'
                            )
                        """, (
                            self.original_selected_day_edit_students,
                            str(self.original_start_time_edit_students),
                            str(self.original_end_time_edit_students),
                            selected_room_id,
                            self.original_subject_code_edit_students
                        ))
                        self.mydb.commit()
        except mysql.connector.Error as err:
            self.mydb.rollback()
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

        finally:
            self.changed_sched_editing = False
            self.ui.change_instructor_sched.setDisabled(True)
            self.ui.add_sched_instructor.setDisabled(False)
            self.original_selected_day_edit_students = None
            self.original_teacher = None
            self.original_subject_code_edit_students = None
            self.original_start_time_edit_students = None
            self.original_end_time_edit_students = None

            self.original_selected_day_edit_students_for_changing = None
            self.original_end_time_edit_students_for_changing = None
            self.original_start_time_edit_students_for_changing = None
            self.original_teacher_for_changing = None
            self.original_subject_code_edit_students_for_changing = None
            self.original_section_id_for_changing = None

            self.ui.assign_instructor.clear()
            self.ui.assign_subject.clear()
            self.ui.instructor_day_edit_comboBox.setCurrentIndex(0)
            self.ui.start_time_instructor.setTime(QTime(0, 0))
            self.ui.final_time_instructor.setTime(QTime(0, 0))

    def cancel_change_staffs(self):
        self.ui.change_staff_sched.setDisabled(True)
        self.ui.add_sched_staff.setDisabled(False)
        self.ui.assign_staff.clear()
        self.ui.assign_maintenance.clear()
        self.ui.day_edit_staff.setCurrentIndex(0)
        self.ui.start_time_staff.setTime(QTime(0, 0))
        self.ui.final_time_staff.setTime(QTime(0, 0))

    def add_room(self):
        item = QListWidgetItem()
        item.setFlags(item.flags() | Qt.ItemIsEditable)
        item.setText("Enter Room Name")
        item.setTextAlignment(Qt.AlignCenter)
        font = QFont()
        font.setPointSize(12)
        item.setFont(font)

        self.ui.room_list.addItem(item)
        self.ui.room_list.setCurrentItem(item)
        self.ui.room_list.editItem(item)

    def open_add_student(self):
        self.assigned_instructor = self.ui.assign_instructor.text()
        self.subject_code = self.ui.assign_subject.text()
        self.selected_day = self.ui.instructor_day_edit_comboBox.currentText()
        self.selected_time_start = self.ui.start_time_instructor.time()
        self.selected_time_end = self.ui.final_time_instructor.time()
        if not self.subject_code:
            QMessageBox.warning(None, "Missing Subject", "Please select or input a subject code before adding students.")
            return

        elif not self.selected_time_start or not self.selected_time_end:
            QMessageBox.warning(None, "Missing Time", "Please set both start and end times before adding students.")
            return

        elif not self.selected_day:
            QMessageBox.warning(None, "Missing Day", "Please select a day before adding students.")
            return
        
        else:
            dialog = EditStudent(
                    subject_code=self.subject_code,
                    start_time=self.selected_time_start,
                    end_time=self.selected_time_end,
                    selected_day=self.selected_day,
                    room_name=self.selected_room,
                    assigned_instructor=self.assigned_instructor,
                    db_connection=self.mydb,
                    db_cursor=self.mycursor, 
                    original_subject_code=self.original_subject_code_edit_students,
                    original_day=self.original_selected_day_edit_students,
                    original_end=self.original_end_time_edit_students,
                    original_instructor=self.original_teacher,
                    original_start=self.original_start_time_edit_students
                )
            # Connect the signal to the handler function
            dialog.data_updated.connect(self.handle_dialog_data)
            dialog.exec()
    
    def handle_dialog_data(self, subject_code, selected_day, start_time, end_time, instructor):
        # Handle the data when the dialog is accepted or rejected
        print("Data received from dialog:")
        print("Subject Code:", subject_code)
        print("Day:", selected_day)
        print("Start Time:", start_time)
        print("End Time:", end_time)
        print("Instructor:", instructor)

        # Update your variables or do any other necessary actions
        self.original_subject_code_edit_students = subject_code
        self.original_selected_day_edit_students = selected_day
        self.original_start_time_edit_students = start_time
        self.original_end_time_edit_students = end_time
        self.original_teacher = instructor     

    def open_page(self, index):
        self.ui.stackedWidget.setCurrentIndex(index)
        self.new_window = None
        
    def clear_instructor_fields(self):
        self.ui.change_instructor_sched.setDisabled(True)
        self.ui.add_sched_instructor.setDisabled(False)
        self.ui.assign_instructor.clear()
        self.ui.assign_subject.clear()
        self.ui.instructor_day_edit_comboBox.setCurrentIndex(0)
        self.ui.start_time_instructor.setTime(QTime(0, 0))
        self.ui.final_time_instructor.setTime(QTime(0, 0))

    def clear_staff_fields(self):
        self.ui.change_staff_sched.setDisabled(True)
        self.ui.add_sched_staff.setDisabled(False)
        self.ui.assign_staff.clear()
        self.ui.assign_maintenance.clear()
        self.ui.day_edit_staff.setCurrentIndex(0)
        self.ui.start_time_staff.setTime(QTime(0, 0))
        self.ui.final_time_staff.setTime(QTime(0, 0))

    def timedelta_to_string(self, td):
        total_seconds = int(td.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours:02}:{minutes:02}:{seconds:02}"

    def reset_change_inst(self):
        self.ui.assign_instructor.clear()
        self.ui.assign_subject.clear()
        self.ui.instructor_day_edit_comboBox.setCurrentIndex(0)
        self.ui.start_time_instructor.setTime(QTime(0, 0))
        self.ui.final_time_instructor.setTime(QTime(0, 0))
        self.ui.add_sched_instructor.setDisabled(False)
        self.ui.change_instructor_sched.setDisabled(True)

    def reset_change_staff(self):
        self.ui.assign_staff.clear()
        self.ui.assign_maintenance.clear()
        self.ui.day_edit_staff.setCurrentIndex(0)
        self.ui.start_time_staff.setTime(QTime(0, 0))
        self.ui.final_time_staff.setTime(QTime(0, 0))
        self.ui.add_sched_staff.setDisabled(False)
        self.ui.change_staff_sched.setDisabled(True)

    def edit_selected_schedule(self):
        """Select a schedule from the table to edit"""
        self.clear_instructor_fields()
        self.clear_staff_fields()
        item = self.ui.edit_room_sched_table.currentItem()

        self.changed_sched_editing = True

        if not item:
            QMessageBox.warning(None, "Error", "No schedule item selected.")
            return
        
        clicked_text = item.text().strip()

        # If the cell is empty, just disable specific buttons
        if clicked_text == "":
            self.ui.change_instructor_sched.setDisabled(True)
            self.ui.change_staff_sched.setDisabled(True)
            self.ui.add_sched_instructor.setDisabled(False)
            self.ui.add_sched_staff.setDisabled(False)
            
            # Reset original values
            self.original_selected_day_edit_students = None
            self.original_teacher = None
            self.original_subject_code_edit_students = None
            self.original_start_time_edit_students = None
            self.original_end_time_edit_students = None
            self.original_section_id = None
            self.original_selected_day_edit_students_for_changing = None
            self.original_end_time_edit_students_for_changing = None
            self.original_start_time_edit_students_for_changing = None
            self.original_teacher_for_changing = None
            self.original_subject_code_edit_students_for_changing = None
            self.original_section_id_for_changing = None
            self.changed_sched_editing = False
            return

        # Split into full_name and subject_code
        if ":\n" in clicked_text:
            full_name, subject_code = clicked_text.split(":\n", 1)
            full_name = full_name.strip()
            subject_code = subject_code.strip()
        else:
            QMessageBox.warning(None, "Error", "Invalid cell format. Expected 'Name:\\nSubject'.")
            return

        # Get column (day) information
        col = item.column() 
        # The first column (0) is time — skip if user clicked there
        if col == 0:
            return

        day_column_map = {
            1: "Monday",
            2: "Tuesday",
            3: "Wednesday",
            4: "Thursday",
            5: "Friday"
        }
        selected_day = day_column_map.get(col)
        if not selected_day:
            QMessageBox.warning(None, "Error", "Invalid day column selected.")
            return
        
        # Get row information (for time)
        row = item.row()
        time_item = self.ui.edit_room_sched_table.item(row, 0)
        if not time_item:
            QMessageBox.warning(None, "Error", "No time information available.")
            return
        
        time_text = time_item.text().strip()

        try:
            # Get room ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            room_id_result = self.mycursor.fetchone()
            if not room_id_result:
                QMessageBox.warning(None, "Error", "Selected room not found in database.")
                return
            self.selected_room_id = room_id_result[0]
            
            # Use the combined information to find the schedule
            query = """
                SELECT rs.subject_code_purpose, rs.start_schedule, 
                    rs.end_schedule, ua.user_type, CONCAT(ua.First_Name, ' ', ua.Last_Name) AS full_name,
                    rs.section_ID
                FROM room_schedule rs
                JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.selected_day = %s 
                AND rs.subject_code_purpose = %s 
                AND CONCAT(ua.First_Name, ' ', ua.Last_Name) = %s 
                AND rs.selected_room_ID = %s
            """
            self.mycursor.execute(query, (
                selected_day,
                subject_code,
                full_name,
                self.selected_room_id
            ))
            schedule = self.mycursor.fetchone()

            if not schedule:
                QMessageBox.warning(None, "Error", "Schedule not found in the database.")
                return

            # Unpack data
            subject_code, start_time, end_time, user_type, full_name, section_id = schedule

            # Convert time objects to QTime for UI
            if isinstance(start_time, str):
                # If start_time is in HH:MM:SS format
                start_parts = start_time.split(':')
                start_hours = int(start_parts[0])
                start_minutes = int(start_parts[1])
            else:
                # If start_time is a timedelta
                start_time_seconds = start_time.total_seconds()
                start_hours = int(start_time_seconds // 3600)
                start_minutes = int((start_time_seconds % 3600) // 60)

            if isinstance(end_time, str):
                # If end_time is in HH:MM:SS format
                end_parts = end_time.split(':')
                end_hours = int(end_parts[0])
                end_minutes = int(end_parts[1])
            else:
                # If end_time is a timedelta
                end_time_seconds = end_time.total_seconds()
                end_hours = int(end_time_seconds // 3600)
                end_minutes = int((end_time_seconds % 3600) // 60)

            # Store original values for later reference
            self.original_selected_day_edit_students = selected_day
            self.original_end_time_edit_students = end_time
            self.original_start_time_edit_students = start_time
            self.original_teacher = full_name
            self.original_subject_code_edit_students = subject_code
            self.original_section_id = section_id

            self.original_selected_day_edit_students_for_changing = self.original_selected_day_edit_students
            self.original_end_time_edit_students_for_changing = self.original_end_time_edit_students
            self.original_start_time_edit_students_for_changing = self.original_start_time_edit_students
            self.original_teacher_for_changing = self.original_teacher
            self.original_subject_code_edit_students_for_changing = self.original_subject_code_edit_students
            self.original_section_id_for_changing = self.original_section_id


            # Set the appropriate fields based on user type
            if user_type == "instructor":
                self.ui.change_instructor_sched.setDisabled(False)
                self.ui.add_sched_instructor.setDisabled(True)
                self.ui.change_staff_sched.setDisabled(True)
                
                # Fill in instructor fields
                self.ui.assign_instructor.setText(full_name)
                self.ui.assign_subject.setText(subject_code)
                self.ui.instructor_day_edit_comboBox.setCurrentText(selected_day)
                self.ui.start_time_instructor.setTime(QTime(start_hours, start_minutes))
                self.ui.final_time_instructor.setTime(QTime(end_hours, end_minutes))

            elif user_type == "staff":
                self.ui.change_staff_sched.setDisabled(False)
                self.ui.add_sched_staff.setDisabled(True)
                self.ui.change_instructor_sched.setDisabled(True)
                
                # Fill in staff fields
                self.ui.assign_staff.setText(full_name)
                self.ui.assign_maintenance.setText(subject_code)
                self.ui.day_edit_staff.setCurrentText(selected_day)
                self.ui.start_time_staff.setTime(QTime(start_hours, start_minutes))
                self.ui.final_time_staff.setTime(QTime(end_hours, end_minutes))

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
            return

    def change_schedule(self, user):
        try:
            # Get selected room ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            room_id_result = self.mycursor.fetchone()
            if not room_id_result:
                QMessageBox.warning(None, "Error", "Selected room not found in database.")
                return
            self.selected_room_id = room_id_result[0]

            # Extract new values based on user type
            if user == 'instructor':
                self.ui.change_instructor_sched.setDisabled(True)
                self.ui.add_sched_instructor.setDisabled(False)
                new_day = self.ui.instructor_day_edit_comboBox.currentText()
                new_start_qtime = self.ui.start_time_instructor.time()
                new_end_qtime = self.ui.final_time_instructor.time()
                new_subject = self.ui.assign_subject.text().strip()
                full_name = self.ui.assign_instructor.text().strip()
            else:  # staff
                self.ui.change_staff_sched.setDisabled(True)
                self.ui.add_sched_staff.setDisabled(False)
                new_day = self.ui.day_edit_staff.currentText()
                new_start_qtime = self.ui.start_time_staff.time()
                new_end_qtime = self.ui.final_time_staff.time()
                new_subject = self.ui.assign_maintenance.text().strip()
                full_name = self.ui.assign_staff.text().strip()

            # Validate inputs
            if not all([new_day, new_subject, full_name]):
                QMessageBox.warning(None, "Invalid Input", "All fields must be filled.")
                return

            # Convert QTime to string format for database
            new_start_str = new_start_qtime.toString("HH:mm:ss")
            new_end_str = new_end_qtime.toString("HH:mm:ss")

            # Validate time range
            if new_start_qtime >= new_end_qtime:
                QMessageBox.warning(None, "Invalid Time", "Start time must be before end time.")
                return

            # Get user ID
            self.mycursor.execute("""
                SELECT real_ID, user_type FROM user_accounts 
                WHERE CONCAT(First_Name, ' ', Last_Name) = %s
            """, (full_name,))
            user_result = self.mycursor.fetchone()
            if not user_result:
                QMessageBox.warning(None, "Error", "User not found.")
                if user == 'instructor':
                    self.reset_change_inst()
                else:
                    self.reset_change_staff()
                return
            
            user_id, db_user_type = user_result

            # Verify user type matches
            if (user == 'instructor' and db_user_type != 'instructor') or (user == 'staff' and db_user_type != 'staff'):
                QMessageBox.warning(None, "Error", f"Selected user is not a {user}.")
                return

            # Confirm original data is set
            if None in (
                self.original_selected_day_edit_students,
                self.original_start_time_edit_students,
                self.original_end_time_edit_students,
                self.original_subject_code_edit_students,
                self.original_teacher
            ):
                QMessageBox.warning(None, "Error", "Missing original schedule reference.")
                return

            # Get original user ID
            self.mycursor.execute("""
                SELECT real_ID FROM user_accounts 
                WHERE CONCAT(First_Name, ' ', Last_Name) = %s
            """, (self.original_teacher,))
            original_user_result = self.mycursor.fetchone()
            if not original_user_result:
                QMessageBox.warning(None, "Error", "Original user not found.")
                return
            original_user_id = original_user_result[0]

            # Convert original times from timedelta to string
            original_day = self.original_selected_day_edit_students
            original_start_str = str(self.original_start_time_edit_students)
            original_end_str = str(self.original_end_time_edit_students)
            original_subject = self.original_subject_code_edit_students

            # Skip conflict check if updating same time slot
            skip_conflict_check = (
                original_day == new_day and
                original_start_str == new_start_str and
                original_end_str == new_end_str and
                original_user_id == user_id
            )

            if not skip_conflict_check:
                self.mycursor.execute("""
                    SELECT COUNT(*) FROM room_schedule rs
                    JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                    WHERE rs.selected_room_ID = %s
                    AND rs.selected_day = %s
                    AND ua.user_type != 'student'  -- ✅ Only check instructors and staff
                    AND (
                        (rs.start_schedule < %s AND rs.end_schedule > %s) OR
                        (rs.start_schedule >= %s AND rs.start_schedule < %s) OR
                        (rs.end_schedule > %s AND rs.end_schedule <= %s) OR
                        (rs.start_schedule = %s AND rs.end_schedule = %s)
                    )
                    AND NOT (
                        rs.selected_day = %s AND
                        rs.start_schedule = %s AND
                        rs.end_schedule = %s AND
                        rs.user_room_ID = %s AND
                        rs.subject_code_purpose = %s
                    )
                """, (
                    self.selected_room_id,
                    new_day,

                    new_end_str, new_start_str,
                    new_start_str, new_end_str,
                    new_start_str, new_end_str,
                    new_start_str, new_end_str,

                    original_day,
                    original_start_str,
                    original_end_str,
                    original_user_id,
                    original_subject
                ))

                (conflict_count,) = self.mycursor.fetchone()

                if conflict_count > 0:
                    QMessageBox.warning(None, "Schedule Conflict", "This time slot overlaps with another instructor or staff.")
                    if user == 'instructor':
                        self.reset_change_inst()
                    else:
                        self.reset_change_staff()
                    return

                # More accurate conflict check for same user in other rooms
                self.mycursor.execute("""
                    SELECT COUNT(*) FROM room_schedule
                    WHERE user_room_ID = %s AND selected_day = %s 
                    AND NOT (
                        (start_schedule >= %s) OR 
                        (end_schedule <= %s)
                    )
                    AND NOT (
                        selected_day = %s AND
                        start_schedule = %s AND
                        end_schedule = %s AND
                        selected_room_ID = %s AND
                        subject_code_purpose = %s
                    )
                """, (
                    user_id, new_day, 
                    new_end_str,  # No conflict if existing schedule starts after new ends
                    new_start_str,  # No conflict if existing schedule ends before new starts
                    original_day, original_start_str, original_end_str, self.selected_room_id, original_subject
                ))
                if self.mycursor.fetchone()[0] > 0:
                    QMessageBox.warning(None, "Schedule Conflict", f"This {user} already has a schedule at this time in another room.")
                    if user == 'instructor':
                        self.reset_change_inst()
                    else:
                        self.reset_change_staff()
                    return

            # Get section ID (for instructor)
            section_id = None
            if user == 'instructor':
                self.mycursor.execute("""
                    SELECT section_ID 
                    FROM room_schedule
                    WHERE selected_day = %s 
                    AND subject_code_purpose = %s
                    AND selected_room_ID = %s
                    AND start_schedule = %s
                    AND end_schedule = %s
                    AND user_room_ID = %s
                    LIMIT 1
                """, (original_day, original_subject, self.selected_room_id, 
                    original_start_str, original_end_str, original_user_id))
                result = self.mycursor.fetchone()
                if result:
                    section_id = result[0]
            try:
                # Update instructor/staff schedule
                self.mycursor.execute("""
                    UPDATE room_schedule 
                    SET selected_day = %s, 
                        start_schedule = %s, 
                        end_schedule = %s, 
                        subject_code_purpose = %s, 
                        user_room_ID = %s 
                    WHERE selected_day = %s 
                    AND subject_code_purpose = %s 
                    AND selected_room_ID = %s 
                    AND user_room_ID = %s
                    AND start_schedule = %s
                    AND end_schedule = %s
                """, (
                    new_day, new_start_str, new_end_str, new_subject, user_id,
                    original_day, original_subject, self.selected_room_id, original_user_id,
                    original_start_str, original_end_str
                ))
                
                rows_updated = self.mycursor.rowcount
                if rows_updated == 0:
                    raise Exception("No schedule was updated. Original schedule may have been modified.")

                # Update student schedules (if instructor and section exists)
                if user == 'instructor' and section_id:
                    self.mycursor.execute("""
                        UPDATE room_schedule rs
                        JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                        SET rs.selected_day = %s,
                            rs.start_schedule = %s,
                            rs.end_schedule = %s,
                            rs.subject_code_purpose = %s
                        WHERE rs.section_ID = %s
                        AND ua.user_type = 'student'
                        AND rs.subject_code_purpose = %s
                        AND rs.selected_day = %s
                        AND rs.start_schedule = %s
                        AND rs.end_schedule = %s
                        AND rs.selected_room_ID = %s
                    """, (
                        new_day, new_start_str, new_end_str, new_subject,
                        section_id,
                        original_subject, original_day, original_start_str, original_end_str,
                        self.selected_room_id
                    ))

                # Commit transaction
                self.mydb.commit()
                QMessageBox.information(None, "Success", "Schedule updated successfully.")

                # Reset original values
                self.original_selected_day_edit_students = None
                self.original_teacher = None
                self.original_subject_code_edit_students = None
                self.original_start_time_edit_students = None
                self.original_end_time_edit_students = None
                self.original_section_id = None
                self.changed_sched_editing = False

                self.original_selected_day_edit_students_for_changing = None
                self.original_end_time_edit_students_for_changing = None
                self.original_start_time_edit_students_for_changing = None
                self.original_teacher_for_changing = None
                self.original_subject_code_edit_students_for_changing = None
                self.original_section_id_for_changing = None

                # Reload schedule and clear fields
                self.load_schedule()
                self.clear_instructor_fields()
                self.clear_staff_fields()

            except Exception as e:
                # # Rollback on error
                self.mydb.rollback()
                QMessageBox.critical(None, "Error", f"Failed to update schedule: {str(e)}")
                return
                
        except mysql.connector.Error as err:
            self.mydb.rollback()
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
            return

    def remove_instructor_schedule(self):
        self.assigned_instructor = self.ui.assign_instructor.text()
        self.subject_code = self.ui.assign_subject.text()
        self.selected_day = self.ui.instructor_day_edit_comboBox.currentText()
        
        # Convert QTime to string (MySQL-compatible)
        self.selected_time_start = self.ui.start_time_instructor.time().toString("HH:mm:ss")
        self.selected_time_end = self.ui.final_time_instructor.time().toString("HH:mm:ss")

        if not (self.assigned_instructor and self.subject_code):
            QMessageBox.warning(None, "Missing Information", "Please fill in all required fields.")
            return
        elif not self.selected_day:
            QMessageBox.warning(None, "Missing Information", "Please select a day.")
            return

        try:
            # Check instructor
            self.mycursor.execute("""
                SELECT real_ID FROM user_accounts
                WHERE CONCAT(First_Name, ' ', Last_Name) = %s
            """, (self.assigned_instructor,))
            instructor_id_result = self.mycursor.fetchone()
            if not instructor_id_result:
                QMessageBox.warning(None, "Error", "Instructor not found.")
                return
            
            search_query = """
                SELECT room_id
                FROM room_schedule
                WHERE user_room_ID = %s
                AND start_schedule = %s
                AND end_schedule = %s
                AND selected_day = %s
                AND selected_room_ID = %s
                AND subject_code_purpose = %s
            """
            self.mycursor.execute(search_query, (
                instructor_id_result[0],
                self.selected_time_start,
                self.selected_time_end,
                self.selected_day,
                self.selected_room_id,
                self.subject_code
            ))
            
            schedule = self.mycursor.fetchone()
            if not schedule:
                QMessageBox.warning(None, "Error", "Instructor is not scheduled for this time.")
                return

            # Get room ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            room_result = self.mycursor.fetchone()
            if not room_result:
                QMessageBox.warning(None, "Error", "Selected room not found.")
                return

            self.selected_room_id = room_result[0]

            # Fetch section_ID from the instructor’s schedule entry
            section_id_query = """
                SELECT section_ID FROM room_schedule
                WHERE selected_day = %s
                AND start_schedule = %s
                AND end_schedule = %s
                AND selected_room_ID = %s
                AND subject_code_purpose = %s
                AND user_room_ID = %s
                LIMIT 1
            """
            self.mycursor.execute(section_id_query, (
                self.selected_day,
                self.selected_time_start,
                self.selected_time_end,
                self.selected_room_id,
                self.subject_code,
                instructor_id_result[0]
            ))
            section_result = self.mycursor.fetchone()
            if not section_result:
                QMessageBox.warning(None, "Error", "Schedule with matching section not found.")
                return

            section_id = section_result[0]

            # Delete instructor and students from the same section in this schedule
            delete_all_query = """
                DELETE FROM room_schedule
                WHERE section_ID = %s
                AND selected_day = %s
                AND start_schedule = %s
                AND end_schedule = %s
                AND selected_room_ID = %s
                AND subject_code_purpose = %s
            """
            self.mycursor.execute(delete_all_query, (
                section_id,
                self.selected_day,
                self.selected_time_start,
                self.selected_time_end,
                self.selected_room_id,
                self.subject_code
            ))

            self.mydb.commit()

            QMessageBox.information(None, "Success", "Instructor and associated students have been removed from the schedule.")

            # Optional: Clear fields and refresh views
            self.clear_instructor_fields()
            self.load_schedule()
            self.original_selected_day_edit_students = None
            self.original_teacher = None
            self.original_subject_code_edit_students = None
            self.original_start_time_edit_students = None
            self.original_end_time_edit_students = None
            self.original_section_id = None
            self.changed_sched_editing = False

            self.original_selected_day_edit_students_for_changing = None
            self.original_end_time_edit_students_for_changing = None
            self.original_start_time_edit_students_for_changing = None
            self.original_teacher_for_changing = None
            self.original_subject_code_edit_students_for_changing = None
            self.original_section_id_for_changing = None

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def remove_staff_schedule(self):
        self.staff_name = self.ui.assign_staff.text()
        self.staff_purpose = self.ui.assign_maintenance.text()
        self.selected_day = self.ui.day_edit_staff.currentText()
        self.start_staff = self.ui.start_time_staff.time().toString("HH:mm:ss")
        self.end_staff = self.ui.final_time_staff.time().toString("HH:mm:ss")

        if not (self.staff_name and self.staff_purpose):
            QMessageBox.warning(None, "Missing Information", "Please fill in all required fields.")
            return
        elif not self.selected_day:
            QMessageBox.warning(None, "Missing Information", "Please select a day.")
            return
 
        try:
            # Check staff
            self.mycursor.execute("""
                SELECT real_ID FROM user_accounts
                WHERE CONCAT(First_Name, ' ', Last_Name) = %s
            """, (self.staff_name,))
            staff_result = self.mycursor.fetchone()
            if not staff_result:
                QMessageBox.warning(None, "Error", "Instructor not found.")
                return

            # Get room ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.selected_room,))
            room_result = self.mycursor.fetchone()
            if not room_result:
                QMessageBox.warning(None, "Error", "Selected room not found.")
                return

            self.selected_room_id = room_result[0]

            # Delete staff
            delete_query = """
                DELETE FROM room_schedule 
                WHERE selected_day = %s AND start_schedule = %s AND end_schedule = %s AND selected_room_ID = %s
            """
            self.mycursor.execute(delete_query, (
                self.selected_day,
                self.start_staff,
                self.end_staff,
                self.selected_room_id
            ))
            self.mydb.commit()

            QMessageBox.information(None, "Success", "Staff has been removed from the schedule.")

            # Optional: Clear fields and refresh views
            self.clear_staff_fields()
            self.load_schedule()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def open_logout(self):
        self.switch_window(MainWindow)

    def switch_window(self, new_window_class):
        self.new_window = new_window_class()
        self.new_window.show()
        self.close()
    
    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

# Reply, Read and Delete (to be added) to reports and requests

    def load_requests(self):    
        self.ui.list_requests.clear()
        self.all_requests = []

        try:
            self.mycursor.execute("""
                SELECT ri.user_type, rr.request_id, rr.user_ID, rr.requested_room, rr.requested_day,
                    rr.requested_start, rr.requested_end, rr.request_comp_message,
                    rr.time_submitted, rr.replied_message, ua.First_Name, ua.Last_Name, ua.user_type
                FROM request_inbox ri
                JOIN room_requests rr ON ri.request_id = rr.request_id
                JOIN user_accounts ua ON rr.user_ID = ua.real_ID
                WHERE ri.user_type = 'admin'
            """)
            rows = self.mycursor.fetchall()

            for row in rows:
                (inbox_user, request_id, user_id, room, day, start, end, body, timestamp, status,
                fname, lname, user_type) = row

                msg = {
                    "request_id": request_id,
                    "user_type_request": inbox_user,
                    "sender_id": user_id,
                    "full_name": f"{fname} {lname}",
                    "user": user_type,
                    "room": room,
                    "day": day,
                    "start_time": f"{int(start.total_seconds() // 3600):02}:{int((start.total_seconds() % 3600) // 60):02}",
                    "end_time": f"{int(end.total_seconds() // 3600):02}:{int((end.total_seconds() % 3600) // 60):02}",
                    "body": body,
                    "timestamp": timestamp.strftime("%Y-%m-%d %H:%M"),
                    "status": "Replied" if status else "Pending"
                }

                item_text = f"{msg['full_name']} ({user_type}) - Room {room} on {day}"
                self.ui.list_requests.addItem(item_text)
                self.all_requests.append(msg)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
    
    def on_request_selected(self, item):
        index = self.ui.list_requests.row(item)
        if 0 <= index < len(self.all_requests):
            msg = self.all_requests[index]
            self.selected_request = msg
            formatted = (
                f"From: {msg['full_name']} (Instructor)\n"
                f"Room: {msg['room']}\n"
                f"Day: {msg['day']}\n"
                f"Start Time: {msg['start_time']}\n"
                f"End Time: {msg['end_time']}\n"
                f"Message: {msg['body']}\n"
                f"Timestamp: {msg['timestamp']}\n"
                f"Status: {msg['status']}"
            )
            self.ui.received_request.setPlainText(formatted)

    def delete_selected_request(self):
        selected_row = self.ui.list_requests.currentRow()
        if selected_row < 0 or selected_row >= len(self.all_requests):
            QMessageBox.warning(None, "No selection", "Please select a request to delete.")
            return

        msg = self.all_requests[selected_row]

        confirm = QMessageBox.question(None, "Confirm", "Are you sure you want to delete this request?",
                                        QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            try:
                self.mycursor.execute("""
                    DELETE FROM request_inbox WHERE request_id = %s AND user_type =%s
                """, (msg["request_id"], msg["user_type_request"]))
                self.mydb.commit()
                QMessageBox.information(None, "Deleted", "Request has been deleted.")
                self.load_requests()
                self.check_full_deletion_requests(msg["request_id"])
                self.ui.received_request.clear()

            except mysql.connector.Error as err:
                self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def check_full_deletion_requests(self, request_id):
        self.mycursor.execute("""
            SELECT COUNT(*) FROM request_inbox WHERE request_id = %s
        """, (request_id,))
        (remaining_copies,) = self.mycursor.fetchone()

        if remaining_copies == 0:
            # No more inbox copies, safe to delete from main room_requests
            self.mycursor.execute("""
                DELETE FROM room_requests WHERE request_id = %s
            """, (request_id,))
            self.mydb.commit()

    def delete_selected_report(self):
        selected_row = self.ui.list_reports.currentRow()
        if selected_row < 0 or selected_row >= len(self.all_reports):
            QMessageBox.warning(None, "No selection", "Please select a report to delete.")
            return

        msg = self.all_reports[selected_row]

        confirm = QMessageBox.question(None, "Confirm", "Are you sure you want to delete this report?",
                                        QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            try:
                self.mycursor.execute("""
                    DELETE FROM report_inbox WHERE report_id = %s AND user_type = %s
                """, (msg["report_id"], msg["user_type"]))
                self.mydb.commit()
                QMessageBox.information(None, "Deleted", "Report has been deleted.")
                self.load_reports()
                self.check_full_deletion_reports(msg["report_id"])
                self.ui.received_report.clear()

            except mysql.connector.Error as err:
                self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def check_full_deletion_reports(self, report_id):
        self.mycursor.execute("""
            SELECT COUNT(*) FROM report_inbox WHERE report_id = %s
        """, (report_id,))
        (remaining_copies,) = self.mycursor.fetchone()

        if remaining_copies == 0:
            # No more inbox copies, safe to delete from main room_requests
            self.mycursor.execute("""
                DELETE FROM room_reports WHERE reports_id = %s
            """, (report_id,))
            self.mydb.commit()

    def send_requestreply(self):
        reply_text = self.ui.reply_requests.toPlainText()
        if not hasattr(self, "selected_request"):
            QMessageBox.warning(None, "No request selected", "Please select a request to reply.")
            return
        if not reply_text.strip():
            QMessageBox.warning(None, "Empty reply", "Please enter a reply message.")
            return

        try:
            # check if already replied, else send reply
            self.mycursor.execute("""
                SELECT replied_message FROM room_request
                WHERE request_id = %s
                """, (self.selected_request["request_id"],))
            
            (self.result,) = self.mycursor.fetchone()

            if not self.result:
                self.mycursor.execute("""
                    UPDATE room_requests
                    SET replied_message = %s
                    WHERE request_id = %s
                """, (reply_text, self.selected_request["request_id"]))

                self.mycursor.execute("""
                    SELECT COUNT(*) FROM request_inbox
                    WHERE request_id = %s AND user_type IN ('instructor', 'staff')
                    """, (self.selected_request["request_id"],))
                
                (count,) = self.mycursor.fetchone()

                if count == 0:
                    self.mycursor.execute("""
                        INSERT INTO request_inbox (request_id, user_type)
                        VALUES (%s, %s)
                        """, (self.selected_request["request_id"], self.selected_request["user"])) 
                self.mydb.commit()

                QMessageBox.information(None, "Reply Sent", "Reply sent successfully!")
            else:
                QMessageBox.warning(None, "Already replied", "This request has already been replied to.")

            self.ui.reply_requests.clear()
            self.ui.received_request.clear()
            self.load_requests()
            self.selected_request = []

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_reports(self):
        self.ui.list_reports.clear()
        self.all_reports = []

        try:
            self.mycursor.execute("""
                SELECT ri.user_type, rr.reports_id, rr.staff_ID, rr.report_type, rr.composed_report,
                    rr.time_submitted, rr.replied_message, ua.First_Name, ua.Last_Name
                FROM report_inbox ri
                JOIN room_reports rr ON ri.report_id = rr.reports_id
                JOIN user_accounts ua ON rr.staff_ID = ua.real_ID
                WHERE ri.user_type = 'admin'
            """)
            rows = self.mycursor.fetchall()

            for row in rows:
                (user_type, report_id, staff_id, report_type, body, timestamp, _, fname, lname) = row
                msg = {
                    "user_type": user_type,
                    "report_id": report_id,
                    "sender_id": staff_id,
                    "full_name": f"{fname} {lname}",
                    "type": report_type,
                    "subject": f"{report_type}",
                    "body": body,
                    "timestamp": timestamp.strftime("%Y-%m-%d %H:%M")
                }

                item_text = f"{msg['full_name']} (Staff) - {report_type}"
                self.ui.list_reports.addItem(item_text)
                self.all_reports.append(msg)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def on_report_selected(self, item):
        index = self.ui.list_reports.row(item)
        if 0 <= index < len(self.all_reports):
            msg = self.all_reports[index]
            self.selected_report = msg
            formatted = (
                f"From: {msg.get('full_name', '')} (Staff)\n"
                f"Report Type: {msg.get('type', '')}\n"
                f"Message: {msg.get('body', '')}\n"
                f"Timestamp: {msg.get('timestamp', '')}"
            )
            self.ui.received_report.setPlainText(formatted)

    def send_reportreply(self):
        reply_text = self.ui.reply_report.toPlainText()
        if not hasattr(self, "selected_report"):
            QMessageBox.warning(None, "No report selected", "Please select a report to reply.")
            return
        if not reply_text.strip():
            QMessageBox.warning(None, "Empty reply", "Please enter a reply message.")
            return

        try:
            # First, check if staff still has a report_inbox copy
            self.mycursor.execute("""
                SELECT COUNT(*) FROM report_inbox
                WHERE report_id = %s AND user_type = 'staff'
            """, (self.selected_report["report_id"],))
            (count,) = self.mycursor.fetchone()

            if count == 0:
                # Staff deleted it, recreate the inbox entry
                self.mycursor.execute("""
                    INSERT INTO report_inbox (report_id, user_type)
                    VALUES (%s, %s)
                """, (self.selected_report["report_id"], 'staff'))

            # check if already replied, else send reply
            self.mycursor.execute("""
                SELECT replied_message FROM room_reports
                WHERE reports_id = %s
                """, (self.selected_report["report_id"],))
            
            (self.result,) = self.mycursor.fetchone()
            print(self.result)

            if not self.result:
                # Then update the reply
                self.mycursor.execute("""
                    UPDATE room_reports
                    SET replied_message = %s
                    WHERE reports_id = %s
                """, (reply_text, self.selected_report["report_id"]))

                self.mydb.commit()

                QMessageBox.information(None, "Reply Sent", "Reply sent successfully!")
            else:
                QMessageBox.warning(None, "Reply error", "Report already replied.")

            self.ui.reply_report.clear()
            self.ui.received_report.clear()
            self.load_reports()
            self.selected_report = []

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_students_into_table(self): 
        try:
            self.ui.list_registered_stdnt.setRowCount(0)

            self.student_thread = QThread()
            self.student_worker = StudentLoaderWorker()
            self.student_worker.moveToThread(self.student_thread)

            self.student_thread.started.connect(self.student_worker.run)
            self.student_worker.finished.connect(self.on_students_loaded)
            self.student_worker.error.connect(self.handle_qthread_error)

            self.student_worker.finished.connect(self.student_thread.quit)
            self.student_worker.finished.connect(self.student_worker.deleteLater)
            self.student_thread.finished.connect(self.student_thread.deleteLater)

            self.student_thread.start() 
        except:
            QMessageBox.critical(None, "Error", "Failed to load students into table")

    def load_instructors_into_table(self):
        try:
            self.instructor_table_widget.setRowCount(0)

            self.instructor_thread = QThread()
            self.instructor_worker = InstructorLoaderWorker()
            self.instructor_worker.moveToThread(self.instructor_thread)

            self.instructor_thread.started.connect(self.instructor_worker.run)
            self.instructor_worker.finished.connect(self.on_instructors_loaded)
            self.instructor_worker.error.connect(self.handle_qthread_error)

            self.instructor_worker.finished.connect(self.instructor_thread.quit)
            self.instructor_worker.finished.connect(self.instructor_worker.deleteLater)
            self.instructor_thread.finished.connect(self.instructor_thread.deleteLater)

            self.instructor_thread.start() 
        except Exception as err:
            QMessageBox.critical(None, "Error", f"Failed to load instructors into table: {err}")

    def load_staffs_into_table(self):
        try:
            self.staff_table_widget.setRowCount(0)

            self.staff_thread = QThread()
            self.staff_worker = StaffLoaderWorker()
            self.staff_worker.moveToThread(self.staff_thread)

            self.staff_thread.started.connect(self.staff_worker.run)
            self.staff_worker.finished.connect(self.on_staffs_loaded)
            self.staff_worker.error.connect(self.handle_qthread_error)

            self.staff_worker.finished.connect(self.staff_thread.quit)
            self.staff_worker.finished.connect(self.staff_worker.deleteLater)
            self.staff_thread.finished.connect(self.staff_thread.deleteLater)

            self.staff_thread.start() 
        except:
            QMessageBox.critical(None, "Error", "Failed to load staffs into table")

    def on_students_loaded(self, users_data):
        self.users_data = users_data
        self.ui.list_registered_stdnt.setRowCount(len(users_data))
        self.ui.list_registered_stdnt.setColumnCount(7)
        self.ui.list_registered_stdnt.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Email", "Section", "Course", "Year"])

        for row_index, row_data in enumerate(users_data):
            display_data = [
                row_data[3], # ID 
                row_data[0], # First name
                row_data[1], # Last name
                row_data[2], # Email
                row_data[6], # Course
                row_data[7], # Year
                row_data[8]  # Section
            ]
            
            for col_index, value in enumerate(display_data):
                item = QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.ui.list_registered_stdnt.setItem(row_index, col_index, item)

        self.ui.list_registered_stdnt.sortItems(0, Qt.AscendingOrder)

    def on_staffs_loaded(self, users_data):
        self.users_data = users_data
        self.staff_table_widget.setRowCount(len(self.users_data))
        self.staff_table_widget.setColumnCount(4)
        self.staff_table_widget.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Email"])
        for row_index, row_data in enumerate(self.users_data):
            display_data = [
                row_data[3], # ID 
                row_data[0], # First name
                row_data[1], # Last name
                row_data[2]  # Email
            ]
            
            for col_index, value in enumerate(display_data):
                item = QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.staff_table_widget.setItem(row_index, col_index, item)
        self.staff_table_widget.sortItems(0, Qt.AscendingOrder)

    def on_instructors_loaded(self, users_data):
        self.users_data = users_data
        self.instructor_table_widget.setRowCount(len(self.users_data))
        self.instructor_table_widget.setColumnCount(4)
        self.instructor_table_widget.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Email"])
        for row_index, row_data in enumerate(self.users_data):
            display_data = [
                row_data[3], # ID 
                row_data[0], # First name
                row_data[1], # Last name
                row_data[2]  # Email
            ]
            
            for col_index, value in enumerate(display_data):
                item = QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.instructor_table_widget.setItem(row_index, col_index, item)
        self.instructor_table_widget.sortItems(0, Qt.AscendingOrder)

    def handle_qthread_error(self, error_msg):
        QMessageBox.critical(None, "Error loading users", error_msg)

class StudentLoaderWorker(QObject):
    finished = Signal(list)
    error = Signal(str)

    def run(self):
        try:
            # New DB connection just for this thread
            conn = mysql.connector.connect(
                host="localhost",
                user="Group_F",
                password="CPET-8L-TUPCROOM",
                database="tupc-room_utilization"
            )
            self.mycursor = conn.cursor()

            query = """
                SELECT 
                    ua.First_Name, 
                    ua.Last_Name, 
                    ua.email, 
                    ua.real_ID, 
                    ua.user_type, 
                    ua.is_change_password, 
                    s.course,
                    s.year,
                    s.section                  
                FROM section_junction sj
                JOIN user_accounts ua ON sj.student_ID = ua.real_ID
                JOIN section s ON sj.section_ID = s.sections_id
                WHERE user_type = 'student'
            """

            # Execute the query
            self.mycursor.execute(query)

            # Fetch all results
            self.users_data = self.mycursor.fetchall()
            self.finished.emit(self.users_data)

        except Exception as e:
            self.error.emit(str(e))

class StaffLoaderWorker(QObject):
    finished = Signal(list)
    error = Signal(str)

    def run(self):
        try:
            # New DB connection just for this thread
            conn = mysql.connector.connect(
                host="localhost",
                user="Group_F",
                password="CPET-8L-TUPCROOM",
                database="tupc-room_utilization"
            )
            self.mycursor = conn.cursor()

            query = """
                SELECT 
                    First_Name, 
                    Last_Name, 
                    email, 
                    real_ID                  
                FROM user_accounts 
                WHERE user_type = 'staff'
            """

            # Execute the query
            self.mycursor.execute(query)

            # Fetch all results
            self.users_data = self.mycursor.fetchall()
            self.finished.emit(self.users_data)

        except Exception as e:
            self.error.emit(str(e))

class InstructorLoaderWorker(QObject):
    finished = Signal(list) 
    error = Signal(str)

    def run(self):
        try:
            # New DB connection just for this thread
            conn = mysql.connector.connect(
                host="localhost",
                user="Group_F",
                password="CPET-8L-TUPCROOM",
                database="tupc-room_utilization"
            )
            self.mycursor = conn.cursor()

            query = """
                SELECT 
                    First_Name, 
                    Last_Name, 
                    email, 
                    real_ID                  
                FROM user_accounts 
                WHERE user_type = 'instructor'
            """

            # Execute the query
            self.mycursor.execute(query)

            # Fetch all results
            self.users_data = self.mycursor.fetchall()
            self.finished.emit(self.users_data)
        except Exception as e:
            self.error.emit(str(e))

class StaffRegistration(QDialog):
    def __init__(self, db_connection, db_cursor, parent=None):
        super().__init__(parent)  # Ensures it stays on top of the main window

        self.ui = StaffRegistrationUi()
        self.ui.setupUi(self)

        self.mydb = db_connection
        self.mycursor = db_cursor
        
        self.ui.sort_instructor.clear()
        self.ui.sort_instructor.addItems(["ID", "First Name", "Last Name", "Email"])

        self.ui.sort_instructor.currentIndexChanged.connect(self.sort_staff)

        self.staff_table_widget = self.ui.list_registered_staff
        self.ui.search_staff_btn.clicked.connect(self.search_staff)
        self.ui.search_bar_staff.textChanged.connect(self.reset_staff_search)

        self.ui.pass_generate_staff.clicked.connect(self.generate_default_password)
        self.ui.save_staff_btn.clicked.connect(self.register_staff)
    
        remove_tab = self.ui.tabWidget_instructor.widget(1)
        
        self.firstname = remove_tab.findChild(QLineEdit, "first_name_lineedit_remove_staff")
        self.lastname = remove_tab.findChild(QLineEdit, "last_name_lineedit_remove_staff")
        self.idnumber = remove_tab.findChild(QLineEdit, "ID_staff_remove")

        self.removestaff_btn = remove_tab.findChild(QPushButton, "del_staff_inlist")
        self.removestaff_btn.clicked.connect(self.remove_staff)

        self.email_sending_in_progress = False
        self.ui.list_registered_staff.cellDoubleClicked.connect(self.fill_remove)

        self.ui.ID_staff.setValidator(QIntValidator(0, 999))  # Only numbers from 0 to 999
        self.ui.ID_staff.setMaxLength(3)

        # Initialize TableWidget
        self.setup_table()
        self.load_user_data()
        self.load_staffs_into_table()

        
    def fill_remove(self, row, column):
        current_tab = self.ui.tabWidget_instructor.currentWidget()
        if current_tab != self.ui.remove_staff:
            return

        first_name = self.ui.list_registered_staff.item(row, 1).text()
        last_name = self.ui.list_registered_staff.item(row, 2).text()
        id_number = self.ui.list_registered_staff.item(row, 0).text()

        self.ui.first_name_lineedit_remove_staff.setText(first_name)
        self.ui.last_name_lineedit_remove_staff.setText(last_name)
        self.ui.ID_staff_remove.setText(id_number)

    def load_user_data(self):
        try:
            query = """
                SELECT 
                    First_Name, 
                    Last_Name, 
                    email, 
                    real_ID                  
                FROM user_accounts 
                WHERE user_type = 'staff'
            """

            # Execute the query
            self.mycursor.execute(query)

            # Fetch all results
            self.users_data = self.mycursor.fetchall()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def reset_staff_search(self):
        """Reset the instructor table when the search bar is cleared."""
        search_text = self.ui.search_bar_staff.text().strip().lower()
        if not search_text:
            for row in range(self.staff_table_widget.rowCount()):
                self.staff_table_widget.setRowHidden(row, False)
            return
        
        for row in range(self.staff_table_widget.rowCount()):
            match_found = False
            for col in range(self.staff_table_widget.columnCount()):
                item = self.staff_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # No need to check other columns if there's a match

            self.staff_table_widget.setRowHidden(row, not match_found)

    def search_staff(self):
        """Search for an instructor by ID, First Name, Last Name, or Email."""
        search_text = self.ui.search_bar_staff.text().strip().lower()

        if not search_text:
            QMessageBox.warning(None, "Warning", "Please enter a search term.")
            return

        found = False
        for row in range(self.staff_table_widget.rowCount()):
            match_found = False
            for col in range(self.staff_table_widget.columnCount()):
                item = self.staff_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # No need to check other columns if there's a match

            self.staff_table_widget.setRowHidden(row, not match_found)
            if match_found:
                found = True

        if not found:
            QMessageBox.information(None, "No Results", "No matching instructor found.")

    def setup_table(self):
        """Setup table columns."""
        self.ui.list_registered_staff.setColumnCount(4)
        self.ui.list_registered_staff.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Email"])
        self.ui.list_registered_staff.resizeColumnsToContents()
        self.ui.list_registered_staff.resizeRowsToContents()
        self.ui.list_registered_staff.setWordWrap(True)
        self.ui.list_registered_staff.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def load_staffs_into_table(self):
        """Load all instructors into the table widget."""
        self.ui.list_registered_staff.setRowCount(len(self.users_data))
        for row_index, row_data in enumerate(self.users_data):
            display_data = [
                row_data[3], # ID 
                row_data[0], # First name
                row_data[1], # Last name
                row_data[2]  # Email
            ]
            
            for col_index, value in enumerate(display_data):
                item = QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.ui.list_registered_staff.setItem(row_index, col_index, item)
        self.ui.list_registered_staff.sortItems(0, Qt.AscendingOrder)

    def generate_default_password(self):
        """Generate a default password."""
        default_password = "Staff123"
        self.ui.password_staff_reg.setText(default_password)

    def sort_staff(self):
        """Sort instructors based on the selected category."""
        category = self.ui.sort_instructor.currentText()
        sorting_map = {
            "ID": 0,
            "First Name": 1,
            "Last Name": 2,
            "Email": 3
        }
        
        if category in sorting_map:
            self.ui.list_registered_staff.sortItems(sorting_map[category], Qt.AscendingOrder)

    def register_staff(self):
        first_name = self.ui.first_name_lineedit_staff.text().strip()
        last_name = self.ui.lastname_lineedit_staff.text().strip()
        email = self.ui.email_staff_lineedit.text().strip()
        staff_id = self.ui.ID_staff.text().strip()
        formatted_id = StaffID(staff_id).get_id() 
        password = self.ui.password_staff_reg.text().strip()

        if not (first_name and last_name and email and staff_id and password):
            QMessageBox.warning(None, "Error", "All fields must be filled!")
            return

        elif len(staff_id) != 3:
            QMessageBox.warning(None, "Error", "Staff ID must be exactly 3 digits!")
            return

        try:
            self.mycursor.execute("SELECT COUNT(*) FROM user_accounts WHERE real_ID = %s", (formatted_id,))
            if self.mycursor.fetchone()[0] > 0:
                QMessageBox.warning(None, "Error", "Staff ID already exists!")
                return     

            self.mycursor.execute("SELECT COUNT(*) FROM user_accounts WHERE First_Name = %s AND Last_Name = %s", (first_name, last_name))    
            if self.mycursor.fetchone()[0] > 0:
                QMessageBox.warning(None, "Error", "User with this name already exists!")
                return   
            
            sql_columns_inst = "INSERT INTO user_accounts (First_Name, Last_Name, email, password, real_ID, user_type, is_change_password) " \
            "VALUES (%s, %s, %s, %s, %s, %s, %s)"
            values = [first_name, last_name, email, password, formatted_id, 'staff', 0]

            self.mycursor.execute(sql_columns_inst, values)
            self.mydb.commit()
           
            QMessageBox.information(None, "Success", "Staff registered successfully!")
            
            self.clear_fields()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

        # Refresh registration table
        self.load_user_data()
        self.load_staffs_into_table()
        self.send_credentials_email(email, first_name, formatted_id, password)
 
    def remove_staff(self):
        """Remove a student using First Name, Last Name, or ID"""
        first_name = self.firstname.text().strip()
        last_name = self.lastname.text().strip()
        id_number = self.idnumber.text().strip()

        if not (first_name and last_name and id_number):
            QMessageBox.warning(None, "Error", "Please enter First Name, Last Name, or ID Number to remove.")
            return
        
        try:
            # check user credentials if existing or wrong input of data
            check_query = """
                SELECT COUNT(*) FROM user_accounts WHERE  First_Name = %s AND Last_Name = %s AND real_ID = %s
            """
            self.mycursor.execute(check_query, (first_name, last_name, id_number))
            result = self.mycursor.fetchone()
            if result[0] == 0:
                QMessageBox.warning(None, "Warning", "User does not exist, please check you inputted data.")
                return

            delete_section_sql = """
                DELETE FROM user_accounts WHERE First_Name = %s AND Last_Name = %s AND real_ID = %s
            """
            self.mycursor.execute(delete_section_sql, (first_name, last_name, id_number))

            self.mydb.commit()

            QMessageBox.information(None, "Success", "Staff removed successfully.")

            # Refresh UI
            self.clear_remove_fields()
            self.load_user_data()
            self.load_staffs_into_table()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
        
    def clear_remove_fields(self):
        """Clear input fields after removal"""
        self.firstname.clear()
        self.lastname.clear()
        self.idnumber.clear()

    def clear_fields(self):
        """Clear input fields after successful registration."""
        self.ui.first_name_lineedit_staff.clear()
        self.ui.lastname_lineedit_staff.clear()
        self.ui.email_staff_lineedit.clear()
        self.ui.ID_staff.clear()
        self.ui.password_staff_reg.clear()
    
    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

    def send_credentials_email(self, recipient_email, first_name, staff_id, password):
        sender_email = "tupcroomutilization@gmail.com"
        sender_password = "mqfb surj molj joko"  # App password

        self.current_staff_id = staff_id  # Store for rollback if needed

        # Create the progress dialog
        self.dialog = EmailSendingDialog(self)
        self.dialog.setModal(True)
        self.dialog.show()

        # Create thread and worker
        self.email_thread = QThread()
        self.email_worker = EmailSenderWorker(
            recipient_email, first_name, staff_id, password,
            sender_email, sender_password, "Staff"
        )
        self.email_worker.moveToThread(self.email_thread)

        self.email_thread.started.connect(self.email_worker.run)
        self.email_worker.finished.connect(self.email_thread.quit)
        self.email_worker.finished.connect(self.email_worker.deleteLater)
        self.email_worker.finished.connect(self.successed_send)
        self.email_thread.finished.connect(self.email_thread.deleteLater)
        self.email_worker.error.connect(self.handle_email_error)

        self.email_thread.start()
    
    def successed_send(self):
        self.dialog.close()

    def handle_email_error(self, error_message):      
        self.dialog.close()
        # Step 1: Disconnect the worker if needed
        try:
            self.email_worker.finished.disconnect()
        except TypeError:
            pass
        try:
            self.email_thread.quit()
            self.email_thread.wait() 
            self.rollback_registration(self.current_staff_id)
        except:
            self.email_thread.quit()
            self.email_thread.wait()
            self.rollback_registration(self.current_staff_id) 
            QMessageBox.critical(
                None,
                "Email Sending Failed",
                f"An error occurred while sending the email:\n\n{error_message}"
            )

    def rollback_registration(self, user_id):
        """Safely roll back a user registration if email sending fails"""
        try:
            # Check if database connection is valid
            if not hasattr(self, 'mydb') or not self.mydb.is_connected():
                QMessageBox.critical(None, "Database Error", "Database connection lost. Please restart the application.")
                return
                
            self.mycursor.execute("DELETE FROM user_accounts WHERE real_ID = %s", (user_id,))
            self.mydb.commit()
            self.load_user_data()
            self.load_staffs_into_table()
            QMessageBox.information(None, "Cancelled", "Registration was cancelled and user removed due to email error. Please try again.")
        except mysql.connector.Error as err:
            QMessageBox.critical(None, "Database Error", f"Rollback failed:\n{err}")
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Unexpected error during rollback:\n{str(e)}")

    def closeEvent(self, event):
        try:
            if getattr(self, 'email_sending_in_progress', False):
                QMessageBox.warning(None, "Please wait", "Email is still being sent.")
                event.ignore()
            else:
                event.accept()
        except Exception as err:
            QMessageBox.critical(None, "Unexpected error", f"Error cause: {err}")

class InstructorRegistration(QDialog):
    def __init__(self, db_connection, db_cursor, parent=None):
        super().__init__(parent)

        self.ui = InstructorRegistrationUi()
        self.ui.setupUi(self)
        
        self.mydb = db_connection
        self.mycursor = db_cursor

        self.ui.sort_instructor.currentIndexChanged.connect(self.sort_instructors)

        self.ui.sort_instructor.clear()
        self.ui.sort_instructor.addItems(["ID", "First Name", "Last Name", "Email"])

        self.ui.pass_generate_instructor.clicked.connect(self.generate_default_password)
        self.ui.save_instructor_btn.clicked.connect(self.register_instructor)

        self.instructor_table_widget = self.ui.list_registered_instructor
        self.ui.search_instructor_btn.clicked.connect(self.search_instructor)
        self.ui.search_bar_instructor.textChanged.connect(self.reset_instructor_search)

        remove_tab = self.ui.tabWidget_instructor.widget(1)

        # Find the correct QLineEdit widgets for instructor removal
        self.firstname = remove_tab.findChild(QLineEdit, "first_name_lineedit_remove_instructor_3")
        self.lastname = remove_tab.findChild(QLineEdit, "last_name_lineedit_remove_instructor_3")
        self.idnumber = remove_tab.findChild(QLineEdit, "ID_instructor_remove")

        # Find and connect remove button
        self.removeinstructor_btn = remove_tab.findChild(QPushButton, "del_instructor_inlist_3")
        self.removeinstructor_btn.clicked.connect(self.remove_instructor)
        self.ui.list_registered_instructor.cellDoubleClicked.connect(self.fill_remove)

        self.ui.ID_instructor.setValidator(QIntValidator(0, 999))  # Only numbers from 0 to 999
        self.ui.ID_instructor.setMaxLength(3)

        self.email_sending_in_progress = False
        self.setup_table()
        self.load_user_data()
        self.load_instructors_into_table()
        
    def fill_remove(self, row, column):
        current_tab = self.ui.tabWidget_instructor.currentWidget()

        if current_tab != self.ui.remove_instructor:
            return

        first_name = self.ui.list_registered_instructor.item(row, 1).text()
        last_name = self.ui.list_registered_instructor.item(row, 2).text()
        id_number = self.ui.list_registered_instructor.item(row, 0).text()

        self.ui.first_name_lineedit_remove_instructor_3.setText(first_name)
        self.ui.last_name_lineedit_remove_instructor_3.setText(last_name)
        self.ui.ID_instructor_remove.setText(id_number)

    def load_user_data(self):
        try:
            query = """
                SELECT 
                    First_Name, 
                    Last_Name, 
                    email, 
                    real_ID                  
                FROM user_accounts 
                WHERE user_type = 'instructor'
            """

            # Execute the query
            self.mycursor.execute(query)

            # Fetch all results
            self.users_data = self.mycursor.fetchall()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def reset_instructor_search(self):
        """Reset the instructor table when the search bar is cleared."""
        search_text = self.ui.search_bar_instructor.text().strip().lower()
        if not search_text:
            for row in range(self.instructor_table_widget.rowCount()):
                self.instructor_table_widget.setRowHidden(row, False)

        for row in range(self.instructor_table_widget.rowCount()):
            match_found = False
            for col in range(self.instructor_table_widget.columnCount()):
                item = self.instructor_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # No need to check other columns if there's a match

            self.instructor_table_widget.setRowHidden(row, not match_found)

    def search_instructor(self):
        """Search for an instructor by ID, First Name, Last Name, or Email."""
        search_text = self.ui.search_bar_instructor.text().strip().lower()

        if not search_text:
            QMessageBox.warning(None, "Warning", "Please enter a search term.")
            return

        found = False
        for row in range(self.instructor_table_widget.rowCount()):
            match_found = False
            for col in range(self.instructor_table_widget.columnCount()):
                item = self.instructor_table_widget.item(row, col)
                if item and search_text in item.text().strip().lower():
                    match_found = True
                    break  # No need to check other columns if there's a match

            self.instructor_table_widget.setRowHidden(row, not match_found)
            if match_found:
                found = True

        if not found:
            QMessageBox.information(None, "No Results", "No matching instructor found.")
            
    def sort_instructors(self):
        """Sort instructors based on the selected category."""
        category = self.ui.sort_instructor.currentText()
        sorting_map = {
            "ID": 0,
            "First Name": 1,
            "Last Name": 2,
            "Email": 3
        }
        
        if category in sorting_map:
            self.ui.list_registered_instructor.sortItems(sorting_map[category], Qt.AscendingOrder)

    def setup_table(self):
        """Setup table columns."""
        self.ui.list_registered_instructor.setColumnCount(4)
        self.ui.list_registered_instructor.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Email"])
        self.ui.list_registered_instructor.resizeColumnsToContents()
        self.ui.list_registered_instructor.resizeRowsToContents()
        self.ui.list_registered_instructor.setWordWrap(True)
        self.ui.list_registered_instructor.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def load_instructors_into_table(self):
        """Load all instructors into the table widget."""
        self.ui.list_registered_instructor.setRowCount(len(self.users_data))
        for row_index, row_data in enumerate(self.users_data):
            display_data = [
                row_data[3], # ID 
                row_data[0], # First name
                row_data[1], # Last name
                row_data[2]  # Email
            ]
            
            for col_index, value in enumerate(display_data):
                item = QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.ui.list_registered_instructor.setItem(row_index, col_index, item)
        self.ui.list_registered_instructor.sortItems(0, Qt.AscendingOrder)

    def generate_default_password(self):
        """Generate a default password."""
        default_password = "Instructor123"
        self.ui.password_instructor_reg.setText(default_password)

    def register_instructor(self):
        first_name = self.ui.first_name_lineedit_instructor.text().strip()
        last_name = self.ui.lastname_lineedit_instructor.text().strip()
        email = self.ui.email_instructor_lineedit.text().strip()
        instructor_id = self.ui.ID_instructor.text().strip()
        formatted_id = InstructorID(instructor_id).get_id() 
        password = self.ui.password_instructor_reg.text().strip()

        if not (first_name and last_name and email and instructor_id and password):
            QMessageBox.warning(None, "Error", "All fields must be filled!")
            return
        
        elif len(instructor_id) != 3:
            QMessageBox.warning(None, "Error", "Instructor ID must be exactly 3 digits!")
            return


        try:
            self.mycursor.execute("SELECT COUNT(*) FROM user_accounts WHERE real_ID = %s", (formatted_id,))
            if self.mycursor.fetchone()[0] > 0:
                QMessageBox.warning(None, "Error", "Instructor ID already exists!")
                return     

            self.mycursor.execute("SELECT COUNT(*) FROM user_accounts WHERE First_Name = %s AND Last_Name = %s", (first_name, last_name))    
            if self.mycursor.fetchone()[0] > 0:
                QMessageBox.warning(None, "Error", "User with this name already exists!")
                return
            
            sql_columns_inst = "INSERT INTO user_accounts (First_Name, Last_Name, email, password, real_ID, user_type, is_change_password) " \
            "VALUES (%s, %s, %s, %s, %s, %s, %s)"
            values = [first_name, last_name, email, password, formatted_id, 'instructor', 0]

            self.mycursor.execute(sql_columns_inst, values)
            self.mydb.commit()
           
            QMessageBox.information(None, "Success", "Instructor registered successfully!")
            
            self.clear_fields()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

        # Refresh registration table
        self.load_user_data()
        self.load_instructors_into_table()
        self.send_credentials_email(email, first_name, formatted_id, password)

    def remove_instructor(self):
        """Remove a student using First Name, Last Name, or ID"""
        first_name = self.ui.first_name_lineedit_remove_instructor_3.text().strip()
        last_name = self.ui.last_name_lineedit_remove_instructor_3.text().strip()
        id_number = self.ui.ID_instructor_remove.text().strip()

        if not (first_name and  last_name and id_number):
            QMessageBox.warning(None, "Error", "Please enter First Name, Last Name, or ID Number to remove.")
            return
        
        try:
            # check user credentials if existing or wrong input of data
            check_query = """
                SELECT COUNT(*) FROM user_accounts WHERE  First_Name = %s AND Last_Name = %s AND real_ID = %s
            """
            self.mycursor.execute(check_query, (first_name, last_name, id_number))
            result = self.mycursor.fetchone()
            if result[0] == 0:
                QMessageBox.warning(None, "Warning", "User does not exist, please check you inputted data.")
                return
            
            delete_section_sql = """
                DELETE FROM user_accounts WHERE First_Name = %s AND Last_Name = %s AND real_ID = %s
            """
            self.mycursor.execute(delete_section_sql, (first_name, last_name, id_number))

            self.mydb.commit()

            QMessageBox.information(None, "Success", "Instructor removed successfully.")

            # Refresh UI
            self.clear_remove_fields()
            self.load_user_data()
            self.load_instructors_into_table()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
        self.clear_fields()

    def clear_remove_fields(self):
        """Clear input fields after removal"""
        self.ui.first_name_lineedit_remove_instructor_3.clear()
        self.ui.last_name_lineedit_remove_instructor_3.clear()
        self.ui.ID_instructor_remove.clear()
    
    def clear_fields(self):
            """Clear input fields after successful registration."""
            self.ui.first_name_lineedit_instructor.clear()
            self.ui.lastname_lineedit_instructor.clear()
            self.ui.email_instructor_lineedit.clear()
            self.ui.ID_instructor.clear()
            self.ui.password_instructor_reg.clear()

    def send_credentials_email(self, recipient_email, first_name, instructor_id, password):
        sender_email = "tupcroomutilization@gmail.com"
        sender_password = "mqfb surj molj joko"  # Make sure this is a valid App Password

        self.current_instructor_id = instructor_id  # Store for rollback if needed

        # Create the progress dialog
        self.dialog = EmailSendingDialog(self)
        self.dialog.setModal(True)
        self.dialog.show()

        self.email_thread = QThread()
        self.email_worker = EmailSenderWorker(recipient_email, first_name, instructor_id, password, sender_email, sender_password, "Instructor")
        self.email_worker.moveToThread(self.email_thread)

        self.email_thread.started.connect(self.email_worker.run)
        self.email_worker.finished.connect(self.email_thread.quit)
        self.email_worker.finished.connect(self.email_worker.deleteLater)
        self.email_worker.finished.connect(self.successed_send)
        self.email_thread.finished.connect(self.email_thread.deleteLater)
        self.email_worker.error.connect(self.handle_email_error)
        
        self.email_thread.start()
    
    def successed_send(self):
        self.dialog.close()

    def handle_email_error(self, error_message):      
        self.dialog.close()
        # Step 1: Disconnect the worker if needed
        try:
            self.email_worker.finished.disconnect()
        except TypeError:
            pass
        try:
            self.email_thread.quit()
            self.email_thread.wait()    
            self.rollback_registration(self.current_instructor_id)
        except:
            self.email_thread.quit()
            self.email_thread.wait()
            self.rollback_registration(self.current_instructor_id)
            QMessageBox.critical(
                None,
                "Email Sending Failed",
                f"An error occurred while sending the email:\n\n{error_message}"
            )

    def rollback_registration(self, user_id):
        """Safely roll back a user registration if email sending fails"""
        try:
            # Check if database connection is valid
            if not hasattr(self, 'mydb') or not self.mydb.is_connected():
                QMessageBox.critical(None, "Database Error", "Database connection lost. Please restart the application.")
                return
                
            self.mycursor.execute("DELETE FROM user_accounts WHERE real_ID = %s", (user_id,))
            self.mydb.commit()
            self.load_user_data()
            self.load_instructors_into_table()
            QMessageBox.information(None, "Cancelled", "Registration was cancelled and user removed due to email error. Please try again.")
        except mysql.connector.Error as err:
            QMessageBox.critical(None, "Database Error", f"Rollback failed:\n{err}")
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Unexpected error during rollback:\n{str(e)}")

    def closeEvent(self, event):
        try:
            if getattr(self, 'email_sending_in_progress', False):
                QMessageBox.warning(None, "Please wait", "Email is still being sent.")
                event.ignore()
            else:
                event.accept()
        except Exception as err:
            QMessageBox.critical(None, "Unexpected error", f"Error cause: {err}")
 
    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

class StudentRegistration(QDialog):
    def __init__(self, db_connection, db_cursor, parent=None):
        super().__init__(parent)

        self.ui = StudentRegistrationUi()
        self.ui.setupUi(self)

        self.mydb = db_connection
        self.mycursor = db_cursor
    
        self.ui.sort_student.clear()
        self.ui.sort_student.addItems(["ID", "First Name", "Last Name", "Email", "Section", "Course", "Year"])

        self.ui.sort_sections.clear()
        self.ui.sort_sections.addItems(["Section", "Course", "Year"])

        self.ui.sort_student.currentIndexChanged.connect(self.sort_students)

        student_tab = self.ui.edit_tab.widget(1)
        self.sort_student_combo = student_tab.findChild(QComboBox, "sort_student")
        self.search_student_btn = student_tab.findChild(QPushButton, "search_student_btn")
        self.search_bar_student = student_tab.findChild(QLineEdit, "search_bar_stdnt")
        self.student_table_widget = student_tab.findChild(QTableWidget, "list_registered_stdnt")

        self.search_student_btn.clicked.connect(self.search_students)
        self.search_bar_student.textChanged.connect(self.reset_student_search)

        section_tab = self.ui.edit_tab.widget(0)  # Get the first ta
        self.sort_sections_combo = section_tab.findChild(QComboBox, "sort_sections")
        self.search_sections_btn = section_tab.findChild(QPushButton, "search_sections_btn")
        self.list_sections = section_tab.findChild(QTableWidget, "list_sections")
        self.search_bar_sections = section_tab.findChild(QLineEdit, "search_bar_sections")

        self.ui.sort_sections.currentIndexChanged.connect(self.sort_sections)
        self.ui.search_sections_btn.clicked.connect(self.search_sections)
        self.ui.search_bar_sections.textChanged.connect(self.reset_section_search)


        self.ui.tupc_id_lineedit.setValidator(QIntValidator(0, 999999))
        self.ui.tupc_id_lineedit.setMaxLength(6)  

        regex = QRegularExpression("[A-Za-z]+")

        self.ui.section.setValidator(QRegularExpressionValidator(regex))
        self.ui.section.setMaxLength(3)

        self.stdnt_table_widget = self.ui.list_registered_stdnt

        self.ui.pass_generate_stdnt.clicked.connect(self.generate_default_password)
        self.ui.save_send_stdnt_cred.clicked.connect(self.register_student)

        remove_tab = self.ui.tabWidget_student.widget(1)
        self.firstname = remove_tab.findChild(QLineEdit, "first_name_lineedit_remove")
        self.lastname = remove_tab.findChild(QLineEdit, "last_name_lineedit_remove")
        self.idnumber = remove_tab.findChild(QLineEdit, "tupc_id_remove_lineedit")

        self.removestudent_btn = remove_tab.findChild(QPushButton, "del_student_inlist")
        self.removestudent_btn.clicked.connect(self.remove_student)

        self.list_sections_remove = remove_tab.findChild(QListWidget, "list_sections_register_3")
        self.remove_stdnts_in_section_from_system = remove_tab.findChild(QPushButton, "remove_stdnts_in_section_from_system")
        self.remove_stdnts_in_section_from_system.clicked.connect(self.remove_students_by_section)

        self.ui.remove_section.clicked.connect(self.remove_section)

        self.email_sending_in_progress = False

        self.ui.list_registered_stdnt.cellDoubleClicked.connect(self.fill_remove_selection)
        self.ui.add_section.clicked.connect(self.add_section)  # Connect button to method
        self.load_section_data()
        self.load_sections_into_list()

        # Initialize TableWidget
        self.load_user_data()
        self.setup_table()
        self.load_students_into_table() 

    def fill_remove_selection(self, row, column):
        current_tab = self.ui.tabWidget_student.currentWidget()
        if current_tab != self.ui.remove_stdnt:
            return
        
        first_name = self.ui.list_registered_stdnt.item(row, 1).text()
        last_name = self.ui.list_registered_stdnt.item(row, 2).text()
        tupc_id = self.ui.list_registered_stdnt.item(row, 0).text()

        self.ui.first_name_lineedit_remove.setText(first_name)
        self.ui.last_name_lineedit_remove.setText(last_name)
        self.ui.tupc_id_remove_lineedit.setText(tupc_id)

    def load_user_data(self):
        try:
            query = """
                SELECT 
                    ua.First_Name, 
                    ua.Last_Name, 
                    ua.email, 
                    ua.real_ID, 
                    ua.user_type, 
                    ua.is_change_password, 
                    s.course,
                    s.year,
                    s.section                  
                FROM section_junction sj
                JOIN user_accounts ua ON sj.student_ID = ua.real_ID
                JOIN section s ON sj.section_ID = s.sections_id
                WHERE user_type = 'student'
            """

            # Execute the query
            self.mycursor.execute(query)

            # Fetch all results
            self.users_data = self.mycursor.fetchall()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)    

    def load_sections_into_remove_list(self):
        """Load sections into the removal list."""
        try:
            sections = self.load_section_data()
            self.list_sections_remove.clear()
            self.list_sections_remove.addItems(sections)
        except:
            QMessageBox.critical(None, "Error", "Something went wrong, please try again.")

    def load_sections_into_list(self):
        """Load and sort sections before displaying them."""
        try:
            self.ui.list_sections.clear()

            sections = self.load_section_data()
            sorted_sections = sorted(sections)  # Alphabetical sorting

            self.ui.list_sections.addItems(sorted_sections)
        except:
            QMessageBox.critical(None, "Error", "Something went wrong, please try again.")

    def remove_section(self):
        """Remove a section and all associated students."""
        selected_section_item = self.ui.list_sections.currentItem()
        
        if not selected_section_item:
            QMessageBox.warning(None, "Error", "Please select a section to remove.")
            return

        section_text = selected_section_item.text().strip()  # Example: "BSIT - 1A"
        try:
            course, year_section = section_text.split(" - ")
            year = year_section[0]  # e.g. "1"
            section = year_section[1:]  # e.g. "A"
        except ValueError:
            QMessageBox.warning(None, "Error", "Invalid section format.")
            return

        confirm = QMessageBox.question(
            self, "Confirm Deletion", 
            f"Are you sure you want to remove section {section_text} and all associated students?",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirm != QMessageBox.Yes:
            return

        try:
            # Step 1: Get section_id
            self.mycursor.execute(
                "SELECT sections_id FROM section WHERE course = %s AND year = %s AND section = %s",
                (course, year, section)
            )
            result = self.mycursor.fetchone()

            if not result:
                QMessageBox.warning(None, "Error", "Section not found in the database.")
                return

            section_id = result[0]

            # Step 2: Get all student_ids associated with this section
            self.mycursor.execute(
                "SELECT student_ID FROM section_junction WHERE section_id = %s",
                (section_id,)
            )
            student_ids = self.mycursor.fetchall()
            student_ids_flat = [sid[0] for sid in student_ids]

            if student_ids_flat:
                # Step 3: Delete from student_section
                self.mycursor.execute(
                    "DELETE FROM section_junction WHERE section_ID = %s",
                    (section_id,)
                )

                # Step 4: Delete from user_accounts
                format_strings = ','.join(['%s'] * len(student_ids_flat))
                self.mycursor.execute(
                    f"DELETE FROM user_accounts WHERE real_ID IN ({format_strings})",
                    tuple(student_ids_flat)
                )

            # Step 5: Delete the section
            self.mycursor.execute(
                "DELETE FROM section WHERE sections_id = %s",
                (section_id,)
            )

            self.mydb.commit()

            QMessageBox.information(None, "Success", f"Section '{section_text}' and its students have been removed.")

            # Refresh UI
            self.load_section_data()
            self.load_sections_into_list()
            self.load_user_data()
            self.load_students_into_table()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def reset_section_search(self):
        section_tab = self.ui.edit_tab.widget(0)
        self.list_sections = section_tab.findChild(QTableWidget, "list_sections")
        self.search_bar_sections = section_tab.findChild(QLineEdit, "search_bar_sections")

        if not self.list_sections or not self.search_bar_sections:
            return

        self.search_bar_sections.clear()

        for row in range(self.list_sections.rowCount()):
            self.list_sections.setRowHidden(row, False)

    def remove_students_by_section(self):
        """Remove all students in the selected section from the SQL database."""
        selected_section_item = self.ui.list_sections_register_3.currentItem()

        if not selected_section_item:
            QMessageBox.warning(None, "Error", "Please select a section to remove students from.")
            return

        section_text = selected_section_item.text().strip()  # e.g., "BET-COET - 2A"

        try:
            course, section_year = section_text.split(" - ")
            year = section_year[0]
            section = section_year[1]
        except ValueError:
            QMessageBox.warning(None, "Error", "Invalid section format. Please contact admin.")
            return

        try:
            # Step 1: Get section_id
            self.mycursor.execute(
                "SELECT sections_id FROM section WHERE course = %s AND year = %s AND section = %s",
                (course, year, section)
            )
            result = self.mycursor.fetchone()

            if not result:
                QMessageBox.information(None, "Info", "No such section found in the database.")
                return

            section_id = result[0]

            # Step 2: Get all student_ids in that section
            self.mycursor.execute(
                "SELECT student_ID FROM section_junction WHERE section_id = %s",
                (section_id,)
            )
            student_ids = self.mycursor.fetchall()

            if not student_ids:
                QMessageBox.information(None, "Info", "No students found in the selected section.")
                return

            # Step 3: Confirm deletion
            confirm = QMessageBox.question(
                self, "Confirm Deletion", 
                f"Are you sure you want to remove all students in {course}-{year}{section}?",
                QMessageBox.Yes | QMessageBox.No
            )

            if confirm == QMessageBox.Yes:
                student_ids_flat = [sid[0] for sid in student_ids]

                # Step 4: Delete from student_section first (foreign key constraint)
                self.mycursor.execute(
                    "DELETE FROM section_junction WHERE section_ID = %s",
                    (section_id,)
                )

                # Step 5: Delete the actual students in user_accounts
                format_strings = ','.join(['%s'] * len(student_ids_flat))
                self.mycursor.execute(
                    f"DELETE FROM user_accounts WHERE real_ID IN ({format_strings})",
                    tuple(student_ids_flat)
                )

                self.mydb.commit()

                QMessageBox.information(None, "Success", f"All students from {course}-{year}{section} have been removed.")

                self.load_user_data()
                self.load_students_into_table()

        except mysql.connector.Error as err:
            QMessageBox.critical(None, "SQL Error", f"Error: {err}")

    def sort_students(self):
        """Sort students based on the selected category."""
        category = self.ui.sort_student.currentText()  # ✅ Get the selected text correctly

        sorting_map = {
            "ID": 0,
            "First Name": 1,
            "Last Name": 2,
            "Email": 3,
            "Section": 4,
            "Course": 5,  
            "Year": 6
        }

        if category in sorting_map:
            self.ui.list_registered_stdnt.sortItems(sorting_map[category], Qt.AscendingOrder)

    def sort_sections(self):
        """Sort sections based on the selected category (Section, Course, or Year)."""
        category = self.ui.sort_sections.currentText()  # Get selected sorting category
        
        # Mapping category to index position
        sorting_map = {"Section": 0, "Course": 1, "Year": 2}

        if category in sorting_map:
            self.sort_section_list(sorting_map[category])

    def sort_section_list(self, category_index):
        """Sort sections by Section Name, Course, or Year."""
        section_items = []

        # Extract section text from QListWidget
        for i in range(self.ui.list_sections.count()):
            text = self.ui.list_sections.item(i).text().strip()
            parts = text.split(" - ")

            if len(parts) == 2:
                section_name = parts[0].strip()
                course_year = parts[1].strip("()").split()

                if len(course_year) == 2:
                    course = course_year[0].strip()
                    year = course_year[1].strip()
                else:
                    course = course_year[0].strip()
                    year = ""
            else:
                section_name = text
                course = ""
                year = ""

            section_items.append((section_name, course, year, text))

        # Sort by the selected category (Section Name, Course, or Year)
        section_items.sort(key=lambda item: item[category_index])

        # Update QListWidget with sorted sections
        self.ui.list_sections.clear()
        self.ui.list_sections.addItems([item[3] for item in section_items])

    def search_sections(self):
        """Search for sections based on input in the search bar."""
        search_text = self.ui.search_bar_sections.text().strip().lower()

        for i in range(self.ui.list_sections.count()):
            item = self.ui.list_sections.item(i)
            if item:
                item.setHidden(search_text not in item.text().strip().lower())  # Hide non-matching items

    def reset_section_search(self):
        """Reset search filter when search bar is cleared."""
        if not self.ui.search_bar_sections.text().strip():
            for i in range(self.ui.list_sections.count()):
                self.ui.list_sections.item(i).setHidden(False)  # Show all items again

        search_text = self.ui.search_bar_sections.text().strip().lower()

        for i in range(self.ui.list_sections.count()):
            item = self.ui.list_sections.item(i)
            if item:
                item.setHidden(search_text not in item.text().strip().lower())

    def search_students(self):
        """Search students based on input in the search bar."""
        query = self.search_bar_student.text().strip().lower()

        for row in range(self.student_table_widget.rowCount()):
            match = False
            for col in range(self.student_table_widget.columnCount()):
                item = self.student_table_widget.item(row, col)
                if item and query in item.text().strip().lower():
                    match = True
                    break
            self.student_table_widget.setRowHidden(row, not match)

    def reset_student_search(self):
        """Reset search filter when search bar is cleared."""
        if not self.search_bar_student.text().strip():
            for row in range(self.student_table_widget.rowCount()):
                self.student_table_widget.setRowHidden(row, False)
        
        query = self.search_bar_student.text().strip().lower()

        for row in range(self.student_table_widget.rowCount()):
            match = False
            for col in range(self.student_table_widget.columnCount()):
                item = self.student_table_widget.item(row, col)
                if item and query in item.text().strip().lower():
                    match = True
                    break
            self.student_table_widget.setRowHidden(row, not match)

    def add_section(self):
        """Adds a new section to both list widgets"""
        section_name = self.ui.section.text().upper().strip()
        course = self.ui.course_section.currentText()
        year_chosen = self.ui.year_level_section.currentText()
        year = "".join(y for y in year_chosen if y.isdecimal())

        if not section_name:
            QMessageBox.warning(None, "Error", "Section name cannot be empty!")
            return

        formatted_section = f"{course} - {year}{section_name}"

        # Prevent duplicate entries
        for i in range(self.ui.list_sections.count()):
            if self.ui.list_sections.item(i).text() == formatted_section:
                QMessageBox.warning(None, "Error", "Section already exists!")
                return

        # Add to both list widgets
        self.ui.list_sections.addItem(formatted_section)
        self.ui.list_sections_register_3.addItem(formatted_section)
        self.ui.list_sections_register.addItem(formatted_section)

        # Save to SQL 
        try:
            sql_columns = "INSERT INTO section (course, year, section) " \
            "VALUES (%s, %s, %s)"
            values = [course, year, section_name]

            self.mycursor.execute(sql_columns, values)
            self.mydb.commit()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

        # Clear input field
        self.ui.section.clear()

    def load_section_data(self):
        try:
            self.mycursor.execute("SELECT course, year, section FROM section")
            self.result_sections = self.mycursor.fetchall()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_sections_into_list(self):
        """Load stored sections into all list widgets"""
        self.sections = self.result_sections

        # Clear existing items first
        self.ui.list_sections.clear()
        self.ui.list_sections_register.clear()
        self.ui.list_sections_register_3.clear()

        for course, year, section in self.sections:
            display_text = f"{course} - {year}{section}"

            # Add to all relevant list widgets
            self.ui.list_sections.addItem(display_text)
            self.ui.list_sections_register.addItem(display_text)
            self.ui.list_sections_register_3.addItem(display_text)

    def setup_table(self):
        """Setup table columns."""
        self.ui.list_registered_stdnt.setColumnCount(7)
        self.ui.list_registered_stdnt.setHorizontalHeaderLabels(["ID", "First Name", "Last Name", "Email", "Section", "Course", "Year"])
        self.ui.list_registered_stdnt.resizeColumnsToContents()
        self.ui.list_registered_stdnt.resizeRowsToContents()
        self.ui.list_registered_stdnt.setWordWrap(True)
        self.ui.list_registered_stdnt.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def load_students_into_table(self):
        """Load all students into the table widget."""
        self.ui.list_registered_stdnt.setRowCount(len(self.users_data))

        for row_index, row_data in enumerate(self.users_data):
            display_data = [
                row_data[3], # ID 
                row_data[0], # First name
                row_data[1], # Last name
                row_data[2], # Email
                row_data[6], # Course
                row_data[7], # Year
                row_data[8]  # Section
            ]
            
            for col_index, value in enumerate(display_data):
                item = QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.ui.list_registered_stdnt.setItem(row_index, col_index, item)

        self.ui.list_registered_stdnt.sortItems(0, Qt.AscendingOrder)

    def generate_default_password(self):
        """Generate a default password."""
        default_password = "Student123"
        self.ui.password_stdnt_reg.setText(default_password)

    def register_student(self):
        first_name = self.ui.first_name_lineedit.text().strip()
        last_name = self.ui.last_name_lineedit.text().strip()
        email = self.ui.email_stdnt_lineedit.text().strip()
        student_id = self.ui.tupc_id_lineedit.text().strip()
        formatted_id = StudentID(student_id).get_id() 
        password = self.ui.password_stdnt_reg.text().strip()
        
        # Get selected section from the list
        selected_section = self.ui.list_sections_register.currentItem()
        
        if len(student_id) != 6:
            QMessageBox.warning(None, "Error", "Student ID must be exactly 6 digits!")
            return


        if not selected_section:
            QMessageBox.warning(None, "Error", "Please select a section!")
            return
        
        if not (first_name and last_name and email and student_id and password):
            QMessageBox.warning(None, "Error", "All fields must be filled!")
            return

        self.mycursor.execute("SELECT COUNT(*) FROM user_accounts WHERE First_Name = %s AND Last_Name = %s", (first_name, last_name))    
        if self.mycursor.fetchone()[0] > 0:
            QMessageBox.warning(None, "Error", "User with this name already exists!")
            return
        
        section_text = selected_section.text()
        
        try:
            course, section_year = section_text.split(" - ")  # Split into section and the rest
            year = ''.join([char for char in section_year if char.isdigit()])  
            section = ''.join([char for char in section_year if not char.isdigit()])         
        except ValueError:
            QMessageBox.warning(None, "Error", "Invalid section format! Contact admin.")
            return

        try:
            self.mycursor.execute("SELECT COUNT(*) FROM user_accounts WHERE real_ID = %s", (formatted_id,))
            if self.mycursor.fetchone()[0] > 0:
                QMessageBox.warning(None, "Error", "Student ID already exists!")
                return

            sql_columns_stdnt = "INSERT INTO user_accounts (First_Name, Last_Name, email, password, real_ID, user_type, is_change_password) " \
            "VALUES (%s, %s, %s, %s, %s, %s, %s)"
            values = [first_name, last_name, email, password, formatted_id, 'student', 0]

            self.mycursor.execute(sql_columns_stdnt, values)
            self.mydb.commit()

            self.query = "SELECT sections_id FROM section WHERE course = %s AND year = %s AND section = %s"
            self.mycursor.execute(self.query, (course, year, section))

            section_result = self.mycursor.fetchone()
            section_id = section_result[0]
            self.full_name = f"{first_name} {last_name}"

            # Insert into the section_junction table to link the student and the section
            self.mycursor.execute("""
                INSERT INTO section_junction (section_ID, student_ID, student_name)
                VALUES (%s, %s, %s)
            """, (section_id, formatted_id, self.full_name))

            # Commit the transaction
            self.mydb.commit()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
      
        self.clear_fields()
        self.load_user_data()
        self.load_students_into_table()
        self.send_credentials_email(email, first_name, student_id, password)

    def remove_student(self):
        """Remove a student using First Name, Last Name, or ID"""
        first_name = self.firstname.text().strip()
        last_name = self.lastname.text().strip()
        id_number = self.idnumber.text().strip()

        if not (first_name and  last_name and id_number):
            QMessageBox.warning(None, "Error", "Please enter First Name, Last Name, or ID Number to remove.")
            return
        
        try:
            # check user credentials if existing or wrong input of data
            check_query = """
                SELECT COUNT(*) FROM user_accounts WHERE  First_Name = %s AND Last_Name = %s AND real_ID = %s
            """
            self.mycursor.execute(check_query, (first_name, last_name, id_number))
            result = self.mycursor.fetchone()
            if result[0] == 0:
                QMessageBox.warning(None, "Warning", "User does not exist, please check you inputted data.")
                return
            
            delete_section_sql = """
                DELETE FROM user_accounts WHERE First_Name = %s AND Last_Name = %s AND real_ID = %s
            """
            self.mycursor.execute(delete_section_sql, (first_name, last_name, id_number))

            self.mydb.commit()

            QMessageBox.information(None, "Success", "Student removed successfully.")

            # Refresh UI
            self.load_user_data()
            self.load_students_into_table()
            self.clear_remove_fields()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
       
    def send_credentials_email(self, recipient_email, first_name, student_id, password):
        sender_email = "tupcroomutilization@gmail.com"
        sender_password = "mqfb surj molj joko"  # Make sure this is a valid App Password

        self.current_student_id = student_id  # Store for rollback if needed

        # Create the progress dialog
        self.dialog = EmailSendingDialog(self)
        self.dialog.setModal(True)
        self.dialog.show()

        self.email_thread = QThread()
        self.email_worker = EmailSenderWorker(recipient_email, first_name, student_id, password, sender_email, sender_password, "Student")
        self.email_worker.moveToThread(self.email_thread)

        self.email_thread.started.connect(self.email_worker.run)
        self.email_worker.finished.connect(self.email_thread.quit)
        self.email_worker.finished.connect(self.email_worker.deleteLater)
        self.email_worker.finished.connect(self.successed_send)
        self.email_thread.finished.connect(self.email_thread.deleteLater)
        self.email_worker.error.connect(self.handle_email_error)

        self.email_thread.start()
    
    def successed_send(self):
        self.dialog.close()

    def handle_email_error(self, error_message):
        self.dialog.close()

        # Step 1: Disconnect the worker if needed
        try:
            self.email_worker.finished.disconnect()
        except TypeError:
            pass  # already disconnected
        try:
            # Step 2: Stop the thread gracefully
            self.email_thread.quit()
            self.email_thread.wait()
            self.rollback_registration(self.current_student_id)
        except:
            self.email_thread.quit()
            self.email_thread.wait()
            self.rollback_registration(self.current_student_id)
            QMessageBox.critical(
                None,
                "Email Sending Failed",
                f"An error occurred while sending the email:\n\n{error_message}: Registration was cancelled and user removed due to email error. Please try again."
            )

    def rollback_registration(self, user_id):
        """Safely roll back a user registration if email sending fails"""
        try:
            # Check if database connection is valid
            if not hasattr(self, 'mydb') or not self.mydb.is_connected():
                QMessageBox.critical(None, "Database Error", "Database connection lost. Please restart the application.")
                return
            self.mycursor.execute("DELETE FROM user_accounts WHERE real_ID = %s", (user_id,))
            self.mydb.commit()
            self.load_user_data()
            self.load_students_into_table()
        except mysql.connector.Error as err:
            QMessageBox.critical(None, "Database Error", f"Rollback failed:\n{err}")
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Unexpected error during rollback:\n{str(e)}")


    def closeEvent(self, event):
        try:
            if getattr(self, 'email_sending_in_progress', False):
                QMessageBox.warning(None, "Please wait", "Email is still being sent.")
                event.ignore()
            else:
                event.accept()
        except Exception as err:
            QMessageBox.critical(None, "Unexpected error", f"Error cause: {err}")
 
    def clear_remove_fields(self):
        """Clear input fields after removal"""
        self.firstname.clear()
        self.lastname.clear()
        self.idnumber.clear()

    def clear_fields(self):
        """Clear input fields after successful registration."""
        self.ui.first_name_lineedit.clear()
        self.ui.last_name_lineedit.clear()
        self.ui.email_stdnt_lineedit.clear()
        self.ui.tupc_id_lineedit.clear()
        self.ui.password_stdnt_reg.clear()

    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)
     
class EmailSenderWorker(QObject):
    finished = Signal()
    error = Signal(str)
    
    def __init__(self, recipient_email, first_name, user_id, password,
                 email_address, email_password, user_type):
        super().__init__()
        self.recipient_email = recipient_email
        self.first_name = first_name
        self.user_id = user_id
        self.password = password
        self.email_address = email_address
        self.email_password = email_password
        self.user_type = user_type
        self.should_stop = False  # Flag to check if we should abort
    
    def run(self):
        try:
            msg = EmailMessage()
            msg.set_content(
                f"Hello {self.first_name},\n\n"
                f"Welcome to TUPC Room Utilization System.\n"
                f"Your {self.user_type} ID: {self.user_id}\n"
                f"Your Password: {self.password}\n"
                f"For any concern, please send us an email for us to take action.\n\n"
                f"Please keep this information secure.\n"
                f"Best regards,\n"
                f"TUPC Room Utilization System Administrator"
            )
            msg["Subject"] = "Registration Confirmation"
            msg["From"] = self.email_address
            msg["To"] = self.recipient_email

            with smtplib.SMTP("smtp.gmail.com", 587, timeout=10) as smtp:
                smtp.starttls()
                smtp.login(self.email_address, self.email_password)
                smtp.send_message(msg)

            self.finished.emit()
                
        except smtplib.SMTPAuthenticationError:
            self.error.emit("Authentication failed. Please check the sender email and app password.")
        except smtplib.SMTPException as e:
            self.error.emit(f"SMTP error: {str(e)}")
        except socket.timeout:
            self.error.emit("Connection timed out. Please check your internet connection.")
        except socket.gaierror:
            self.error.emit("Network error. Unable to connect to the email server.")
        except Exception as e:
            self.error.emit(f"Failed to send email: {str(e)}")  

class EditStudent(QDialog):
    # Define a signal that will pass data when the dialog is closed
    data_updated = Signal(str, str, str, str, str)

    def __init__(self, subject_code, start_time, end_time, selected_day, room_name, assigned_instructor, db_connection, db_cursor, 
                 original_subject_code, original_day, original_start, original_end, original_instructor, parent=None):
        super().__init__(parent)

        self.mydb = db_connection
        self.mycursor = db_cursor
        self.ui = EditStudentUi()
        self.ui.setupUi(self)
        self.load_section_data()
        self.collect_sections()

        self.subject = subject_code
        self.start_time = start_time
        self.end_time = end_time
        self.selected_day = selected_day
        self.room_name = room_name
        self.assigned_instructor = assigned_instructor

        self.original_subject = original_subject_code
        self.original_day = original_day
        self.original_start = self.timedelta_to_string(original_start)
        self.original_end = self.timedelta_to_string(original_end)
        self.original_instructor = original_instructor
        
        self.ui.sort_student_section.currentIndexChanged.connect(self.sort_students)
        self.ui.search_stdnt_insched_btn.clicked.connect(self.search_students)
        self.ui.search_bar_stdnt_insched.textChanged.connect(self.reset_student_search)

        self.ui.sort_student_section.clear()
        self.ui.sort_student_section.addItems(["A to Z", "Z to A"])

        self.ui.add_section_btn.clicked.connect(self.insert_students_to_schedule)
        self.ui.remove_section.clicked.connect(self.remove_students_section)
        self.display_students_in_section()

        self.ui.search_bar_sections.textChanged.connect(self.reset_section_search)
        self.ui.search_stdnt_sections_btn_2.clicked.connect(self.search_sections)
        self.ui.sort_student_section_2.currentIndexChanged.connect(self.sort_sections)
        self.ui.sort_student_section_2.clear()
        self.ui.sort_student_section_2.addItems(["A to Z", "Z to A"])

        self.original_section = ""

        self.returned_original_subject = None
        self.returned_original_day = None
        self.returned_original_start = None
        self.returned_original_end = None
        self.returned_original_instructor = None

    def timedelta_to_string(self, value):
        if value is None:
            return "" 
        if isinstance(value, timedelta):
            total_seconds = int(value.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return f"{hours:02d}:{minutes:02d}"
        elif isinstance(value, str):
            return value[:5]  # assume it's already a string
        else:
            return ""

    def search_sections(self):
        """Search sections based on input in the search bar."""
        query = self.ui.search_bar_sections.text().strip().lower()
        if not query:
            QMessageBox.warning(None, "Warning", "You must input a section to search.")
            return

        for row in range(self.ui.list_sections_schedule.count()):
            match = False
            item = self.ui.list_sections_schedule.item(row)
            if item and query in item.text().strip().lower():
                match = True
            self.ui.list_sections_schedule.setRowHidden(row, not match)

    def reset_section_search(self):
        """Reset the search bar for sections."""
        if not self.ui.search_bar_sections.text().strip():
            for row in range(self.ui.list_sections_schedule.count()):
                self.ui.list_sections_schedule.setRowHidden(row, False)

        query = self.ui.search_bar_sections.text().strip().lower()

        for row in range(self.ui.list_sections_schedule.count()):
            match = False
            item = self.ui.list_sections_schedule.item(row)
            if item and query in item.text().strip().lower():
                match = True
            self.ui.list_sections_schedule.setRowHidden(row, not match)

    def sort_sections(self):
        category = self.ui.sort_student_section_2.currentText()

        reverse = category == "Z to A"
        self.sort_section_list_by_second_token(reverse)

    def sort_section_list_by_second_token(self, reverse):
        section_items = []

        for i in range(self.ui.list_sections_schedule.count()):
            item = self.ui.list_sections_schedule.item(i)
            full_text = item.text().strip()

            # Expected format: "BET-COET-2A - (BET 2nd)"
            section_part = full_text.split(" - ")[0]  # Get "BET-COET-2A"
            tokens = section_part.split("-")

            # Grab second token for sorting (e.g., COET from BET-COET-2A)
            if len(tokens) >= 2:
                sort_key = tokens[1].strip()
            else:
                sort_key = ""  # fallback if format is unexpected

            section_items.append((sort_key, full_text))

        # Sort by the extracted key
        section_items.sort(key=lambda x: x[0], reverse=reverse)

        # Update QListWidget
        self.ui.list_sections_schedule.clear()
        for sort_key, text in section_items:
            self.ui.list_sections_schedule.addItem(text)

    def sort_students(self):
        """Sort students based on the selected category."""
        category = self.ui.sort_student_section.currentText()  # Get the selected sorting option

        sorting_map = {
            "A to Z": 0,  # Ascending order (A to Z)
            "Z to A": 1   # Descending order (Z to A)
        }

        if category in sorting_map:
            # Extract the items from the list
            rows = self.ui.list_students_schedule.count()
            students = []

            # Extract all items into a list for sorting
            for row in range(rows):
                item = self.ui.list_students_schedule.item(row)
                students.append(item.text())

            # Sort the list based on the selected option (A to Z or Z to A)
            if category == "A to Z":
                students.sort()  # Sort in ascending order (A to Z)
            elif category == "Z to A":
                students.sort(reverse=True)  # Sort in descending order (Z to A)

            # Clear the current list and re-add the sorted items
            self.ui.list_students_schedule.clear()
            for student in students:
                item = QListWidgetItem(student)
                self.ui.list_students_schedule.addItem(item)

    def search_students(self):
        """Search students based on input in the search bar."""
        query = self.ui.search_bar_stdnt_insched.text().strip().lower()

        for row in range(self.ui.list_students_schedule.count()):
            match = False
            item = self.ui.list_students_schedule.item(row)
            if item and query in item.text().strip().lower():
                match = True
            self.ui.list_students_schedule.setRowHidden(row, not match)

    def reset_student_search(self):
        """Reset search filter when search bar is cleared."""
        if not self.ui.search_bar_stdnt_insched.text().strip():
            for row in range(self.ui.list_students_schedule.count()):
                self.ui.list_students_schedule.setRowHidden(row, False)

        query = self.ui.search_bar_stdnt_insched.text().strip().lower()

        for row in range(self.ui.list_students_schedule.count()):
            match = False
            item = self.ui.list_students_schedule.item(row)
            if item and query in item.text().strip().lower():
                match = True
            self.ui.list_students_schedule.setRowHidden(row, not match)

    def load_section_data(self):
        try:
            self.mycursor.execute("SELECT course, year, section FROM section")
            self.result_sections = self.mycursor.fetchall()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def collect_sections(self):
        """Populate the list of sections in the list widget."""
        self.ui.list_sections_schedule.clear()  # Clear previous list if any
        self.sections = self.result_sections
        try:

            if not self.sections:
                self.ui.list_sections_schedule.addItem("No sections available")

            # Populate the list widget with sections
            for course, year, section in self.sections:
                display_text = f"{course} - {year}{section}"
                self.ui.list_sections_schedule.addItem(display_text)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def insert_students_to_schedule(self):
        try:
            selected_item = self.ui.list_sections_schedule.currentItem()
            if not selected_item:
                QMessageBox.warning(None, "Error", "Please select a section.")
                return

            list_text = self.ui.list_students_schedule.item(0).text()
            if list_text != "No students scheduled for this section.":
                QMessageBox.warning(None, "Error", "There is already a scheduled section.")
                return

            self.section_text = selected_item.text().strip()

            # Get selected_room_ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.room_name,))
            room_id_result = self.mycursor.fetchone()
            if not room_id_result:
                QMessageBox.warning(None, "Error", "Selected room not found in database.")
                return
            selected_room_id = room_id_result[0]

            # Conflict check
            conflict_query = """
                SELECT COUNT(*) FROM room_schedule
                WHERE subject_code_purpose = %s
                AND selected_room_ID = %s
                AND selected_day = %s
                AND section_ID IS NULL
                AND (
                        (start_schedule < %s AND end_schedule > %s) OR
                        (start_schedule >= %s AND start_schedule < %s) OR
                        (end_schedule > %s AND end_schedule <= %s) OR
                        (start_schedule = %s AND end_schedule = %s)
                )
            """

            start_str = self.start_time.toString("HH:mm:ss")
            end_str = self.end_time.toString("HH:mm:ss")

            self.mycursor.execute(conflict_query, (
                self.subject,
                self.selected_room_id,
                self.selected_day,
                end_str, start_str,
                start_str, end_str,
                start_str, end_str,
                start_str, end_str
            ))
            (conflict_count,) = self.mycursor.fetchone()
            
            # Parse course, year, section
            try:
                course, year_section = self.section_text.split(" - ")
                year = year_section[0]
                section = year_section[1:]
            except ValueError:
                QMessageBox.warning(None, "Error", "Invalid section format.")
                return

            try:
                # Step 1: Get section_id
                self.mycursor.execute(
                    "SELECT sections_id FROM section WHERE course = %s AND year = %s AND section = %s",
                    (course, year, section)
                )
                result = self.mycursor.fetchone()
                if not result:
                    QMessageBox.warning(None, "Error", "Section not found in the database.")
                    return
                self.section_id = result[0]

                # Step 2: Get student IDs in that section
                self.mycursor.execute("""
                    SELECT sj.student_ID
                    FROM section_junction sj
                    JOIN user_accounts ua ON sj.student_ID = ua.real_ID
                    WHERE sj.section_ID = %s AND ua.user_type = 'student'
                """, (self.section_id,))
                student_ids = self.mycursor.fetchall()

                if not student_ids:
                    QMessageBox.information(None, "Info", "No students found in this section.")
                    return

                # Step 3: Get room ID
                self.mycursor.execute(
                    "SELECT idroom_names FROM tupc_rooms WHERE room = %s",
                    (self.room_name,)
                )
                room_result = self.mycursor.fetchone()
                if not room_result:
                    QMessageBox.warning(None, "Error", "Selected room not found.")
                    return
                self.selected_room_id = room_result[0]

                # Step 4: Check for duplicate section schedule
                self.mycursor.execute("""
                    SELECT COUNT(*)
                    FROM room_schedule rs
                    JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                    WHERE rs.section_ID = %s AND rs.selected_day = %s AND rs.start_schedule = %s AND rs.selected_room_ID = %s AND ua.user_type = 'student'
                """, (
                    self.section_id,
                    self.selected_day,
                    self.start_time.toString("HH:mm:ss"),
                    self.selected_room_id
                ))
                if self.mycursor.fetchone()[0] > 0:
                    QMessageBox.warning(None, "Error", "This section is already scheduled for this time.")
                    return

                # Step 5: Insert students
                insert_query = """
                    INSERT INTO room_schedule 
                    (subject_code_purpose, selected_day, start_schedule, end_schedule, user_room_ID, section_ID, selected_room_ID)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """

                for (student_id,) in student_ids:
                    self.mycursor.execute(insert_query, (
                        self.subject,
                        self.selected_day,
                        self.start_time.toString("HH:mm:ss"),
                        self.end_time.toString("HH:mm:ss"),
                        student_id,
                        self.section_id,
                        self.selected_room_id
                    ))

                # Step 6: Update instructor's section if replacing old
                if None not in (self.original_subject, self.original_day, self.original_start, self.original_end, self.original_instructor):
                    # Find instructor ID
                    self.mycursor.execute("""
                        SELECT real_ID FROM user_accounts
                        WHERE CONCAT(First_Name, ' ', Last_Name) = %s
                    """, (self.assigned_instructor,))
                    teacher_result = self.mycursor.fetchone()
                    if not teacher_result:
                        QMessageBox.warning(None, "Error", "Assigned teacher not found.")
                        return
                    new_teacher_id = teacher_result[0]

                    # Update instructor's schedule
                    self.mycursor.execute("""
                        UPDATE room_schedule
                        SET section_ID = %s
                        WHERE selected_day = %s
                        AND start_schedule = %s
                        AND end_schedule = %s
                        AND subject_code_purpose = %s
                        AND user_room_ID = (
                            SELECT real_ID FROM user_accounts
                            WHERE CONCAT(First_Name, ' ', Last_Name) = %s
                        )
                    """, (
                        self.section_id,
                        self.original_day,
                        self.original_start,
                        self.original_end,
                        self.original_subject,
                        self.original_instructor
                    ))

                    # ✅ Update original values
                    self.original_subject = self.subject
                    self.original_day = self.selected_day
                    self.original_start = self.start_time.toString("HH:mm:ss")
                    self.original_end = self.end_time.toString("HH:mm:ss")
                    self.original_instructor = self.assigned_instructor

                self.mydb.commit()

                QMessageBox.information(None, "Success", "Student schedules added successfully.")
                self.display_students_in_section()

            except mysql.connector.Error as err:
                self.errorDisplay(err.errno, err.sqlstate, err.msg)
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def handle_schedule_conflict_prompt(self, room_id):
        self.orginal_room_id = room_id

        QMessageBox.warning(
            self,
            "Schedule Conflict",
            "The schedule you tried to assign is already in use.\n"
            "Please change the schedule or reassign the schedule of the section."
        )

        # Parse course, year, section
        try:
            course, year_section = self.original_section.split(" - ")
            year = year_section[0]
            section = year_section[1:]
        except ValueError:
            QMessageBox.warning(None, "Error", "Invalid section format.")
            return
        
        try:
            # Step 1: Get section_id
            self.mycursor.execute(
                "SELECT sections_id FROM section WHERE course = %s AND year = %s AND section = %s",
                (course, year, section)
            )
            result = self.mycursor.fetchone()
            if not result:
                QMessageBox.warning(None, "Error", "Section not found in the database.")
                return
            self.section_id = result[0]

            # Step 2: Get student IDs in that section
            self.mycursor.execute("""
                SELECT sj.student_ID
                FROM section_junction sj
                JOIN user_accounts ua ON sj.student_ID = ua.real_ID
                WHERE sj.section_ID = %s AND ua.user_type = 'student'
            """, (self.section_id,))
            student_ids = self.mycursor.fetchall()

            if not student_ids:
                QMessageBox.information(None, "Info", "No students found in this section.")
                return

            # Step 3: Get room ID
            self.mycursor.execute(
                "SELECT idroom_names FROM tupc_rooms WHERE room = %s",
                (self.room_name,)
            )
            room_result = self.mycursor.fetchone()
            if not room_result:
                QMessageBox.warning(None, "Error", "Selected room not found.")
                return
            self.selected_room_id = room_result[0]

            # Insert students
            insert_query = """
                INSERT INTO room_schedule 
                (subject_code_purpose, selected_day, start_schedule, end_schedule, user_room_ID, section_ID, selected_room_ID)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """

            for (student_id,) in student_ids:
                self.mycursor.execute(insert_query, (
                    self.original_subject,
                    self.original_day,
                    self.original_start,
                    self.original_end,
                    student_id,
                    self.section_id,
                    self.selected_room_id
                ))

            # Update instructor's section if replacing old
            if None not in (self.original_subject, self.original_day, self.original_start, self.original_end, self.original_instructor):
                # Find instructor ID
                self.mycursor.execute("""
                    SELECT real_ID FROM user_accounts
                    WHERE CONCAT(First_Name, ' ', Last_Name) = %s
                """, (self.original_instructor,))
                teacher_result = self.mycursor.fetchone()
                if not teacher_result:
                    QMessageBox.warning(None, "Error", "Assigned teacher not found.")
                    return
                new_teacher_id = teacher_result[0]

                # Update instructor's schedule
                self.mycursor.execute("""
                    UPDATE room_schedule
                    SET section_ID = %s
                    WHERE selected_day = %s
                    AND start_schedule = %s
                    AND end_schedule = %s
                    AND subject_code_purpose = %s
                    AND user_room_ID = (
                        SELECT real_ID FROM user_accounts
                        WHERE CONCAT(First_Name, ' ', Last_Name) = %s
                    )
                """, (
                    self.section_id,
                    self.original_day,
                    self.original_start,
                    self.original_end,
                    self.original_subject,
                    self.original_instructor
                ))

            self.mydb.commit()
            self.display_students_in_section()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

        # Close the window
        self.close()

    def display_students_in_section(self):
        self.ui.list_students_schedule.clear()  # Clear the list first

        try:
            # Get the selected room ID
            self.mycursor.execute(
                "SELECT idroom_names FROM tupc_rooms WHERE room = %s",
                (self.room_name,)
            )
            room_result = self.mycursor.fetchone()
            if not room_result:
                QMessageBox.warning(None, "Error", "Selected room not found.")
                return
            self.selected_room_id = room_result[0]

            # Decide what values to use: updated ones or original
            subject_code = self.original_subject if None not in (
                self.original_subject, self.original_day, self.original_start, self.original_end, self.original_instructor
            ) else self.subject

            day = self.original_day if self.original_day else self.selected_day
            start_time = self.original_start if self.original_start else self.start_time.toString("HH:mm:ss")
            end_time = self.original_end if self.original_end else self.end_time.toString("HH:mm:ss")

            # Fetch students assigned to that schedule
            self.mycursor.execute("""
                SELECT ua.First_Name, ua.Last_Name
                FROM room_schedule rs
                JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.subject_code_purpose = %s
                AND rs.selected_day = %s
                AND rs.start_schedule = %s
                AND rs.end_schedule = %s
                AND rs.selected_room_ID = %s
                AND ua.user_type = 'student'
            """, (
                subject_code,
                day,
                start_time,
                end_time,
                self.selected_room_id
            ))
            students = self.mycursor.fetchall()

            if not students:
                self.ui.list_students_schedule.addItem("No students scheduled for this section.")
                return

            for first_name, last_name in students:
                full_name = f"{last_name}, {first_name}"
                self.ui.list_students_schedule.addItem(QListWidgetItem(full_name))

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

    def remove_students_section(self):
        selected_item = self.ui.list_sections_schedule.currentItem()
        if not selected_item:
            QMessageBox.warning(None, "Error", "Please select a section.")
            return

        self.section_text = selected_item.text().strip()
        self.original_section = self.section_text

        # Parse course, year, section
        try:
            course, year_section = self.section_text.split(" - ")
            year = year_section[0]
            section = year_section[1:]
        except ValueError:
            QMessageBox.warning(None, "Error", "Invalid section format.")
            return

        try:
            # Get section_id
            self.mycursor.execute("""
                SELECT sections_id FROM section
                WHERE course = %s AND year = %s AND section = %s
            """, (course, year, section))
            result = self.mycursor.fetchone()
            if not result:
                QMessageBox.warning(None, "Error", "Section not found in the database.")
                return
            self.section_id = result[0]

            # Get room ID
            self.mycursor.execute("SELECT idroom_names FROM tupc_rooms WHERE room = %s", (self.room_name,))
            room_result = self.mycursor.fetchone()
            if not room_result:
                QMessageBox.warning(None, "Error", "Selected room not found.")
                return
            self.selected_room_id = room_result[0]

            # Find instructor ID
            instructor_name = self.assigned_instructor if None in (
                self.original_subject, self.original_day, self.original_start, self.original_end, self.original_instructor
            ) else self.original_instructor

            self.mycursor.execute("""
                SELECT real_ID FROM user_accounts
                WHERE CONCAT(First_Name, ' ', Last_Name) = %s
            """, (instructor_name,))
            instructor_result = self.mycursor.fetchone()
            if not instructor_result:
                QMessageBox.warning(None, "Error", "Instructor not found.")
                return
            instructor_id = instructor_result[0]

            # Step 1: Delete student schedules in this section
            self.mycursor.execute("""
                DELETE rs
                FROM room_schedule rs
                JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.section_ID = %s
                AND rs.selected_room_ID = %s
                AND ua.user_type = 'student'
            """, (self.section_id, self.selected_room_id))

            # Step 2: Remove section_ID from instructor schedule
            self.mycursor.execute("""
                UPDATE room_schedule
                SET section_ID = NULL
                WHERE user_room_ID = %s
                AND selected_day = %s
                AND start_schedule = %s
                AND end_schedule = %s
                AND selected_room_ID = %s
            """, (
                instructor_id,
                self.selected_day if self.selected_day else self.original_day,
                self.start_time.toString("HH:mm:ss") if self.start_time else self.original_start,
                self.end_time.toString("HH:mm:ss") if self.end_time else self.original_end,
                self.selected_room_id
            ))

            self.mydb.commit()

            QMessageBox.information(None, "Success", "Student schedules removed successfully.")
            self.display_students_in_section()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def closeEvent(self, event):
        if self.ui.list_students_schedule.count() > 0:
            section_text = self.ui.list_students_schedule.item(0).text()

            if section_text == "No students scheduled for this section.":
                QMessageBox.warning(
                    self,
                    "Section Required",
                    "You must assign a section before closing this window."
                )
                event.ignore()
                return
        else:
            # Handle if list is somehow empty
            QMessageBox.warning(
                self,
                "Section Required",
                "You must assign a section before closing this window."
            )
            event.ignore()
            return

        self.accept()

    def accept(self):
        # Emit the data_updated signal with the original values
        self.data_updated.emit(
            self.subject,     # Subject code
            self.selected_day,         # Day
            self.start_time.toString("HH:mm:ss"),       # Start time
            self.end_time.toString("HH:mm:ss"),         # End time
            self.assigned_instructor   # Instructor
        )
        
        # Call the parent class's accept method to close the dialog
        super().accept()

class ChangePass(QDialog):
    def __init__(self, user_ID, db_connection, db_cursor, parent=None):
        super().__init__(parent)  # Ensures it stays on top of the main window
        self.ui = ChangePassUi()
        self.ui.setupUi(self)
        self.user_ID = user_ID
        self.mydb = db_connection
        self.mycursor  = db_cursor

        try:
            find_user = """
            SELECT CONCAT(First_Name, ' ', Last_Name)
            FROM user_accounts
            WHERE real_ID = %s
            """
            self.mycursor.execute(find_user, (self.user_ID,))
            self.user_name = self.mycursor.fetchone()
        
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

        self.ui.user_lineedit.setText(self.user_name[0])
        self.ui.user_lineedit.setReadOnly(True)

        # Set password input to be hidden by default (as circles or dots)
        self.ui.old_pass.setEchoMode(QLineEdit.Password)
        self.ui.new_pass.setEchoMode(QLineEdit.Password)
        self.ui.confirm_pass.setEchoMode(QLineEdit.Password)

        self.ui.change_pass_btn.clicked.connect(self.change_password)
        self.ui.cancel.clicked.connect(self.clear_fields)

        # Connect the show/hide buttons
        self.ui.show_new.clicked.connect(lambda: self.toggle_visibility(self.ui.new_pass, self.ui.show_new))
        self.ui.show_new_2.clicked.connect(lambda: self.toggle_visibility(self.ui.old_pass, self.ui.show_new_2))
        self.ui.show_new_3.clicked.connect(lambda: self.toggle_visibility(self.ui.confirm_pass, self.ui.show_new_3))

    def clear_fields(self):
        self.ui.old_pass.clear()
        self.ui.new_pass.clear()
        self.ui.confirm_pass.clear()

    def toggle_visibility(self, lineedit, button):
        if lineedit.echoMode() == QLineEdit.Password:
            lineedit.setEchoMode(QLineEdit.Normal)
            button.setText("Hide")  # Change button text to "Hide"
        else:
            lineedit.setEchoMode(QLineEdit.Password)
            button.setText("Show")  # Change button text to "Show"

    def change_password(self):
        old = self.ui.old_pass.text()
        new = self.ui.new_pass.text()
        confirm = self.ui.confirm_pass.text()

        if not old or not new or not confirm:
            QMessageBox.warning(None, "Missing Fields", "Please fill in all fields.")
            return

        if new != confirm:
            QMessageBox.warning(None, "Error", "Passwords do not match.")
            return

        if len(new) < 6:
            QMessageBox.warning(None, "Error", "Password must be at least 6 characters.")
            return

        try:
            # 1. Fetch the current password from DB
            self.mycursor.execute("""
                SELECT password FROM user_accounts
                WHERE real_ID = %s
            """, (self.user_ID,))
            result = self.mycursor.fetchone()

            if not result:
                QMessageBox.warning(None, "Error", "User not found.")
                return

            current_password = result[0]

            if current_password != old:
                QMessageBox.warning(None, "Error", "Old password is incorrect.")
                return
            
            if current_password == new:
                QMessageBox.warning(None, "Error", "New password cannot be the same in old password.")
                return

            # 2. Update the password
            self.mycursor.execute("""
                UPDATE user_accounts
                SET password = %s
                WHERE real_ID = %s
            """, (new, self.user_ID))
            self.mydb.commit()

            QMessageBox.information(None, "Success", "Password changed successfully!")
            self.close()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    
    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

class ForceChangePassword(QDialog):
    closing = Signal()

    def __init__(self, user_ID, parent=None):
        super().__init__(parent)
        self.ui = ForceChangePasswordUi()
        self.ui.setupUi(self)
        self.username = user_ID # Store username
        self.new_password = None  # Variable to store new password
        
        self.ui.new_pass.setEchoMode(QLineEdit.Password)
        self.ui.confirm_pass.setEchoMode(QLineEdit.Password)
        
        # Connect buttons
        self.ui.change_pass_btn.clicked.connect(self.save_new_password)
        self.ui.show_pass.clicked.connect(lambda: self.toggle_password_visibility(self.ui.new_pass))
    
    def toggle_password_visibility(self, field):
        if field.echoMode() == QLineEdit.Password:
            self.ui.new_pass.setEchoMode(QLineEdit.Normal)  # Show password
            self.ui.confirm_pass.setEchoMode(QLineEdit.Normal)
        else:
            self.ui.new_pass.setEchoMode(QLineEdit.Password)  # Hide password
            self.ui.confirm_pass.setEchoMode(QLineEdit.Password)

    def save_new_password(self):
        new_pass = self.ui.new_pass.text()
        confirm_pass = self.ui.confirm_pass.text()

        if not new_pass or not confirm_pass:
            QMessageBox.warning(None, "Error", "Please fill in both fields.")
            return

        if new_pass != confirm_pass:
            QMessageBox.warning(None, "Error", "Passwords do not match!")
            return
        
        if len(new_pass) < 6:
            QMessageBox.warning(None, "Error", "Password must be at least 6 characters.")
            return

        try:
            # Connect to the database
            mydb = mysql.connector.connect(
                host="localhost",
                user="Group_F",
                password="CPET-8L-TUPCROOM",
                database="tupc-room_utilization"
            )
            cursor = mydb.cursor()

            # Get current (old) password
            cursor.execute("SELECT password FROM user_accounts WHERE real_ID = %s", (self.username,))
            result = cursor.fetchone()
            if result:
                old_pass = result[0]
                if new_pass == old_pass:
                    QMessageBox.warning(None, "Error", "New password cannot be the same as the old password.")
                    cursor.close()
                    mydb.close()
                    return
            else:
                QMessageBox.critical(None, "Error", "User not found.")
                cursor.close()
                mydb.close()
                return

            # Update the password
            cursor.execute("""
                UPDATE user_accounts
                SET password = %s, is_change_password = 1
                WHERE real_ID = %s
            """, (new_pass, self.username))
            mydb.commit()
            cursor.close()
            mydb.close()

            QMessageBox.information(None, "Success", "Password changed successfully.")
            self.accept()  # Close the dialog

        except mysql.connector.Error as err:
            QMessageBox.critical(None, "Error", f"Database error: {err.msg}")
    
class RoomRequestInstructor(QDialog):
    def __init__(self, instructor_id, db_connection, db_cursor, parent=None):
        super().__init__(parent)
        self.mydb = db_connection
        self.mycursor = db_cursor
        self.instructor_id = instructor_id 
        self.ui = RoomRequestInstructorUi()
        self.ui.setupUi(self)
        self.ui.room_list_request_instructor.itemDoubleClicked.connect(self.view_schedule)
        self.ui.view_room.clicked.connect(self.view_schedule)

        page = self.ui.stackedWidget.widget(1)
        self.send_button = page.findChild(QPushButton, "send_btn_composed_request_instructor")
        self.send_button.clicked.connect(self.send_room_request)
        self.back_to_room_list = self.ui.stackedWidget.widget(0).findChild(QPushButton, "back")
        self.back_to_room_list.clicked.connect(lambda: self.open_page(1))
        self.instructor_id = instructor_id  
        self.ui.choose_rm_btn.clicked.connect(self.handle_selection)
        self.load_rooms_into_list()
        self.ui.start_time_instructor.setMinimumTime(QTime(7, 0))
        self.ui.start_time_instructor.setMaximumTime(QTime(20, 0))
        self.ui.final_time_instructor.setMinimumTime(QTime(8, 0))
        self.ui.final_time_instructor.setMaximumTime(QTime(20, 0))
        self.ui.start_time_instructor.timeChanged.connect(lambda: self.correct_time_minutes('start_instructor'))
        self.ui.final_time_instructor.timeChanged.connect(lambda: self.correct_time_minutes('end_instructor'))
        self.clear_fields()

        self.ui.search_bar_room_request_instructor.textChanged.connect(self.search_room)

    def correct_time_minutes(self, timeedit):
        if timeedit == "start_instructor":
            time_edit = self.ui.start_time_instructor
        else:
            time_edit = self.ui.final_time_instructor
        current_time = time_edit.time()
        corrected_time = QTime(current_time.hour(), 0)
        if current_time.minute() != 0:
            time_edit.setTime(corrected_time)

    def handle_selection(self):
        selected_room = self.ui.room_list_request_instructor.currentItem()
        if not selected_room:
            QMessageBox.warning(None, "No Room Selected", "Please select a room first.")
            return
        self.selected_room =  selected_room.text()
        self.ui.lineEdit.setText(self.selected_room)  

    def load_rooms_into_list(self):
        try:
            self.ui.room_list_request_instructor.clear()
            self.mycursor.execute("SELECT room FROM tupc_rooms")
            for (room_name,) in self.mycursor.fetchall():
                item = QListWidgetItem(room_name)
                item.setTextAlignment(Qt.AlignCenter)
                font = QFont()
                font.setPointSize(12)
                item.setFont(font)

                item.setData(Qt.UserRole, room_name)  # Store original name
                self.ui.room_list_request_instructor.addItem(item)
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def view_schedule(self):
        self.selected_room = self.ui.room_list_request_instructor.currentItem().text()
        table = self.ui.instructor_room_sched_table_request
        self.setup_schedule_time_column(table)

        if not self.selected_room:
            QMessageBox.warning(None, "No selected room", "Please select a room.")
        
        # Clear all cells except the time column (column 0)
        for row in range(table.rowCount()):
            for col in range(1, table.columnCount()):
                table.setItem(row, col, QTableWidgetItem(""))
        try:
            # Get the room_nameID from tupc_rooms using the selected room name
            room_name_query = "SELECT idroom_names FROM tupc_rooms WHERE room = %s"
            self.mycursor.execute(room_name_query, (self.selected_room,))
            result = self.mycursor.fetchone()

            if not result:
                QMessageBox.warning(None, "Error", f"Room '{self.selected_room}' not found in database.")
                return

            selected_room_id = result[0]  # Foreign key for room_schedule

            # Retrieve schedule details along with user's full name
            schedule_query = """
                SELECT rs.selected_day, rs.start_schedule, rs.end_schedule,
                    CONCAT(ua.First_Name, ' ', ua.Last_Name) AS full_name,
                    rs.subject_code_purpose
                FROM room_schedule rs
                INNER JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.selected_room_ID = %s
            """
            self.mycursor.execute(schedule_query, (selected_room_id,))
            schedule_data = self.mycursor.fetchall()

            # Map days to columns
            day_column_map = {
                "Monday": 1,
                "Tuesday": 2,
                "Wednesday": 3,
                "Thursday": 4,
                "Friday": 5
            }
            for day, start_time_db, end_time_db, user_name, purpose in schedule_data:
                day_col = day_column_map.get(day)
                if day_col is None:
                    continue

                start_time = self.convert_to_qtime(start_time_db)
                end_time = self.convert_to_qtime(end_time_db)

                # Fill the table rows
                for row in range(table.rowCount()):
                    row_time_item = table.item(row, 0)
                    if not row_time_item:
                        continue

                    row_time = QTime.fromString(row_time_item.text(), "HH:mm")
                    if row_time.isValid() and start_time <= row_time < end_time:
                        item = QTableWidgetItem(f"{user_name}:\n{purpose}")
                        table.setItem(row, day_col, item)

            self.open_page(0)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
    
    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)
    
    def open_page(self, index):
        """Switch pages in the stacked widget."""
        self.ui.stackedWidget.setCurrentIndex(index)

    def convert_to_qtime(self, time_value):
        if isinstance(time_value, timedelta):
            total_seconds = int(time_value.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return QTime(hours, minutes)
        elif isinstance(time_value, str):
            return QTime.fromString(time_value, "HH:mm:ss")
        return QTime()  # fallback empty QTime

    def setup_schedule_time_column(self, table):
        table.setRowCount(14)  # for 7:00 to 20:00
        table.setColumnCount(6)
        table.setRowCount(14)
        table.setHorizontalHeaderLabels(["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
        for i in range(14):
            hour = 7 + i
            table.setItem(i, 0, QTableWidgetItem(f"{hour:02}:00"))
        return

    def clear_fields(self):
        self.ui.lineEdit.clear()
        self.ui.room_request_instructor.clear()
        self.ui.instructor_day_edit_comboBox.setCurrentIndex(0)
        self.ui.start_time_instructor.setTime(QTime(0, 0))
        self.ui.final_time_instructor.setTime(QTime(0, 0))

    def send_room_request(self):
        room = self.ui.lineEdit.text().strip()
        day = self.ui.instructor_day_edit_comboBox.currentText()
        start_time = self.ui.start_time_instructor.time().toString("HH:mm")
        end_time = self.ui.final_time_instructor.time().toString("HH:mm")
        reason = self.ui.room_request_instructor.toPlainText().strip()

        if not all([room, day, reason]):
            QMessageBox.warning(None, "Missing Info", "Please fill in all fields.")
            return

        try:
            insert_query = """
                INSERT INTO room_requests (
                    user_ID, requested_room, requested_day, requested_start,
                    requested_end, request_comp_message, time_submitted
                ) VALUES (%s, %s, %s, %s, %s, %s, NOW())
            """
            self.mycursor.execute(insert_query, (
                self.instructor_id,
                room,
                day,
                start_time,
                end_time,
                reason
            ))

            find_id_query = """
                SELECT request_id FROM room_requests
                WHERE user_ID = %s AND requested_room = %s AND requested_day = %s 
                AND requested_start = %s AND requested_end = %s AND request_comp_message = %s
            """

            self.mycursor.execute(find_id_query, (
                self.instructor_id,
                room,
                day,
                start_time,
                end_time,
                reason
            ))
            
            request_id = self.mycursor.fetchone()[0]

            insert_to_inbox_admin = """
                INSERT INTO request_inbox (request_id, user_type)
                VALUES (%s, %s)
            """
            self.mycursor.execute(insert_to_inbox_admin, (request_id, "admin"))

            insert_to_inbox_instructor = """
            INSERT INTO request_inbox (request_id, user_type)
            VALUES (%s, %s)
            """
            self.mycursor.execute(insert_to_inbox_instructor, (request_id, "instructor"))

            self.mydb.commit()

            QMessageBox.information(None, "Request Sent", "Your room request has been sent to admin.")
            self.close()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def search_room(self):
        pass

class RoomRequestStaff(QDialog):
    def __init__(self, staff_id, db_connection, db_cursor, parent=None):
        super().__init__(parent)
        self.staff_id = staff_id 
        self.mydb = db_connection
        self.mycursor = db_cursor
        self.ui = RoomRequestStaffUi()
        self.ui.setupUi(self)
        self.back_room_select_staff = self.ui.stackedWidget.widget(0).findChild(QPushButton, "back_room_select_staff")
        self.back_room_select_staff.clicked.connect(lambda: self.open_page(1))

        self.ui.room_list_request_staff.itemDoubleClicked.connect(self.view_schedule)
        self.ui.view_room_btn.clicked.connect(self.view_schedule)

        
        page = self.ui.stackedWidget.widget(1)
        self.send_button = page.findChild(QPushButton, "send_btn_composed_request_instructor")
        self.send_button.clicked.connect(self.send_room_request)
        self.staff_id = staff_id  
        self.ui.choose_rm_btn.clicked.connect(self.handle_selection)
        self.load_rooms_into_list()
        self.ui.start_time_staff.setMinimumTime(QTime(7, 0))
        self.ui.start_time_staff.setMaximumTime(QTime(20, 0))
        self.ui.final_time_staff.setMinimumTime(QTime(8, 0))
        self.ui.final_time_staff.setMaximumTime(QTime(20, 0))
        self.ui.start_time_staff.timeChanged.connect(lambda: self.correct_time_minutes('start_staff'))
        self.ui.final_time_staff.timeChanged.connect(lambda: self.correct_time_minutes('end_staff'))
        self.clear_fields()
    
    def correct_time_minutes(self, timeedit):
        if timeedit == "start_staff":
            time_edit = self.ui.start_time_staff
        else:
            time_edit = self.ui.final_time_staff
        current_time = time_edit.time()
        corrected_time = QTime(current_time.hour(), 0)
        if current_time.minute() != 0:
            time_edit.setTime(corrected_time)

    def handle_selection(self):
        selected_room = self.ui.room_list_request_staff.currentItem()
        if not selected_room:
            QMessageBox.warning(None, "No Room Selected", "Please select a room first.")
            return
        self.selected_room =  selected_room.text()
        self.ui.lineEdit.setText(self.selected_room)  

    def load_rooms_into_list(self):
        try:
            self.ui.room_list_request_staff.clear()
            self.mycursor.execute("SELECT room FROM tupc_rooms")
            for (room_name,) in self.mycursor.fetchall():
                item = QListWidgetItem(room_name)
                item.setTextAlignment(Qt.AlignCenter)
                font = QFont()
                font.setPointSize(12)
                item.setFont(font)

                item.setData(Qt.UserRole, room_name)  # Store original name
                self.ui.room_list_request_staff.addItem(item)
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def view_schedule(self):
        self.selected_room = self.ui.room_list_request_staff.currentItem().text()
        table = self.ui.staff_room_sched_table_request
        self.setup_schedule_time_column(table)

        if not self.selected_room:
            QMessageBox.warning(None, "No selected room", "Please select a room to view")
            return

        # Clear all cells except the time column (column 0)
        for row in range(table.rowCount()):
            for col in range(1, table.columnCount()):
                table.setItem(row, col, QTableWidgetItem(""))
        try:

            # Get the room_nameID from tupc_rooms using the selected room name
            room_name_query = "SELECT idroom_names FROM tupc_rooms WHERE room = %s"
            self.mycursor.execute(room_name_query, (self.selected_room,))
            result = self.mycursor.fetchone()

            if not result:
                QMessageBox.warning(None, "Error", f"Room '{self.selected_room}' not found in database.")
                return

            selected_room_id = result[0]  # Foreign key for room_schedule

            # Retrieve schedule details along with user's full name
            schedule_query = """
                SELECT rs.selected_day, rs.start_schedule, rs.end_schedule,
                    CONCAT(ua.First_Name, ' ', ua.Last_Name) AS full_name,
                    rs.subject_code_purpose
                FROM room_schedule rs
                INNER JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                WHERE rs.selected_room_ID = %s
            """
            self.mycursor.execute(schedule_query, (selected_room_id,))
            schedule_data = self.mycursor.fetchall()

            # Map days to columns
            day_column_map = {
                "Monday": 1,
                "Tuesday": 2,
                "Wednesday": 3,
                "Thursday": 4,
                "Friday": 5
            }
            for day, start_time_db, end_time_db, user_name, purpose in schedule_data:
                day_col = day_column_map.get(day)
                if day_col is None:
                    continue

                start_time = self.convert_to_qtime(start_time_db)
                end_time = self.convert_to_qtime(end_time_db)

                # Fill the table rows
                for row in range(table.rowCount()):
                    row_time_item = table.item(row, 0)
                    if not row_time_item:
                        continue

                    row_time = QTime.fromString(row_time_item.text(), "HH:mm")
                    if row_time.isValid() and start_time <= row_time < end_time:
                        item = QTableWidgetItem(f"{user_name}:\n{purpose}")
                        table.setItem(row, day_col, item)

            self.open_page(0)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
    
    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)
    
    def open_page(self, index):
        """Switch pages in the stacked widget."""
        self.ui.stackedWidget.setCurrentIndex(index)

    def convert_to_qtime(self, time_value):
        if isinstance(time_value, timedelta):
            total_seconds = int(time_value.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            return QTime(hours, minutes)
        elif isinstance(time_value, str):
            return QTime.fromString(time_value, "HH:mm:ss")
        return QTime()  # fallback empty QTime

    def setup_schedule_time_column(self, table):
        table.setRowCount(14)  # for 7:00 to 20:00
        table.setColumnCount(6)
        table.setRowCount(14)
        table.setHorizontalHeaderLabels(["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
        for i in range(14):
            hour = 7 + i
            table.setItem(i, 0, QTableWidgetItem(f"{hour:02}:00"))
        return

    def clear_fields(self):
        self.ui.lineEdit.clear()
        self.ui.room_request_staff.clear()
        self.ui.instructor_day_edit_comboBox.setCurrentIndex(0)
        self.ui.start_time_staff.setTime(QTime(0, 0))
        self.ui.final_time_staff.setTime(QTime(0, 0))

    def send_room_request(self):
        room = self.ui.lineEdit.text().strip()
        day = self.ui.instructor_day_edit_comboBox.currentText()
        start_time = self.ui.start_time_staff.time().toString("HH:mm")
        end_time = self.ui.final_time_staff.time().toString("HH:mm")
        reason = self.ui.room_request_staff.toPlainText().strip()

        if not all([room, day, reason]):
            QMessageBox.warning(None, "Missing Info", "Please fill in all fields.")
            return

        try:
            insert_query = """
                INSERT INTO room_requests (
                    user_ID, requested_room, requested_day, requested_start,
                    requested_end, request_comp_message, time_submitted
                ) VALUES (%s, %s, %s, %s, %s, %s, NOW())
            """
            self.mycursor.execute(insert_query, (
                self.staff_id,
                room,
                day,
                start_time,
                end_time,
                reason
            ))

            find_id_query = """
                SELECT request_id FROM room_requests
                WHERE user_ID = %s AND requested_room = %s AND requested_day = %s 
                AND requested_start = %s AND requested_end = %s AND request_comp_message = %s
            """

            self.mycursor.execute(find_id_query, (
                self.staff_id,
                room,
                day,
                start_time,
                end_time,
                reason
            ))
            
            request_id = self.mycursor.fetchone()[0]

            insert_to_inbox_admin = """
                INSERT INTO request_inbox (request_id, user_type)
                VALUES (%s, %s)
            """
            self.mycursor.execute(insert_to_inbox_admin, (request_id, "admin"))

            insert_to_inbox_staff = """
            INSERT INTO request_inbox (request_id, user_type)
            VALUES (%s, %s)
            """
            self.mycursor.execute(insert_to_inbox_staff, (request_id, "staff"))
            self.mydb.commit()

            QMessageBox.information(None, "Request Sent", "Your room request has been sent to admin.")
            self.close()

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

class ComposeReport(QDialog):
    def __init__(self, staff_id, db_connection, db_cursor, parent=None):
        super().__init__(parent)  
        self.staff_id = staff_id 
        self.mydb = db_connection
        self.mycursor = db_cursor
        self.ui = ComposeReportStaffUi()
        self.ui.setupUi(self)
        self.ui.message_report.clear()

        self.load_rooms_into_list()
        
        self.ui.choose_rm_btn.clicked.connect(self.handle_rooms)
        self.ui.send_btn_composed_msg.clicked.connect(self.compose_report)

    def handle_rooms(self):
        self.selected_room = self.ui.room_list_report_staff.currentItem()
        if not self.selected_room:
            QMessageBox.warning(None, "No Room Selected", "Please select a room first.")
            return
        self.selected_room =  self.selected_room.text()
        self.ui.selected_room.setText(self.selected_room)  
        
    def compose_report(self):
        report_type = self.ui.type_report.currentText()
        body = self.ui.message_report.toPlainText().strip()
        selected_room = self.ui.selected_room.text().strip()

        if not all([body, selected_room]):
            QMessageBox.warning(None, "Missing Values", "Please fill all necessary details for the report before sending.")
            return
        else:
            message_body = body
            try:
                insert_query = """
                    INSERT INTO room_reports (
                        staff_ID, report_type, composed_report, time_submitted
                    ) VALUES (%s, %s, %s, NOW())
                """
                self.mycursor.execute(insert_query, (
                    self.staff_id,
                    report_type,
                    message_body
                ))

                find_id_query = """
                    SELECT reports_id FROM room_reports
                    WHERE staff_id = %s AND report_type = %s AND composed_report = %s
                """

                self.mycursor.execute(find_id_query, (
                    self.staff_id,
                    report_type,
                    message_body
                ))
                
                report_id = self.mycursor.fetchone()[0]

                insert_to_inbox_admin = """
                    INSERT INTO report_inbox (report_id, user_type)
                    VALUES (%s, %s)
                """
                self.mycursor.execute(insert_to_inbox_admin, (report_id, "admin"))

                insert_to_inbox_staff = """
                    INSERT INTO report_inbox (report_id, user_type)
                    VALUES (%s, %s)
                """
                self.mycursor.execute(insert_to_inbox_staff, (report_id, "staff"))

                self.mydb.commit()

                QMessageBox.information(None, "Report Sent", "Your report has been successfully sent to the admin.")
                self.ui.message_report.clear()
                self.close()

            except mysql.connector.Error as err:
                self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        self.mydb.rollback()
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

    def load_rooms_into_list(self):
        try:
            self.ui.room_list_report_staff.clear()
            self.mycursor.execute("SELECT room FROM tupc_rooms")
            for (room_name,) in self.mycursor.fetchall():
                item = QListWidgetItem(room_name)
                item.setTextAlignment(Qt.AlignCenter)
                font = QFont()
                font.setPointSize(12)
                item.setFont(font)

                item.setData(Qt.UserRole, room_name)  # Store original name
                self.ui.room_list_report_staff.addItem(item)
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

class Export_sections(QDialog):
    def __init__(self, db_connection, db_cursor, parent=None):
        super().__init__(parent) 
        self.ui = SectionExportUi()
        self.ui.setupUi(self)
        self.mydb = db_connection
        self.mycursor = db_cursor

        self.ui.choose_btn_download.clicked.connect(self.fill_chosen_section_download)
        self.ui.choose_btn.clicked.connect(self.fill_chosen_section_export)

        self.load_sections_into_list()

        self.ui.send_btn_Excel.clicked.connect(lambda: self.verify_user("excel"))
        self.ui.send_btn_PDF.clicked.connect(lambda: self.verify_user("pdf"))

        self.ui.download_btn_excel.clicked.connect(self.download_excel)
        self.ui.download_btn_pdf.clicked.connect(self.download_pdf)

        self.email_sending_in_progress = False

    def get_selected_section_id(self):
        selected_item = self.ui.section_list.currentItem()
        if selected_item is None:
            return None

        selected_section = selected_item.text()

        try:
            course, section_year = selected_section.split(" - ")  # Split into section and the rest
            year = ''.join([char for char in section_year if char.isdigit()])  
            section = ''.join([char for char in section_year if not char.isdigit()])         
        except ValueError:
            QMessageBox.warning(None, "Error", "Invalid section format! Contact admin.")
            return
        
        try:
            self.mycursor.execute("SELECT sections_id FROM section WHERE course = %s AND year = %s AND section = %s", (course, year, section))
            result = self.mycursor.fetchone()
            return result[0] if result else None
        
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
    
    def get_students_by_section(self, section_id):
        try:
            self.mycursor.execute("""
                SELECT student_name, student_ID
                FROM section_junction
                WHERE section_ID = %s
            """, (section_id,))
            return self.mycursor.fetchall()
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
        
    def verify_user(self, file_type):
        # Just checking if user is existing and email is correct
        try:
            self.user_id = self.ui.user_id_line.text()
            self.email = self.ui.email_to_send_line.text()
            self.file = self.ui.chosen_section_line.text()

            if not self.user_id or not self.email:
                QMessageBox.warning(None, "Missing Information", "Please fill in all required fields.")
                return

            check_query = """
                SELECT user_type, real_ID, email
                FROM user_accounts
                WHERE real_ID = %s AND email = %s
                """
            self.mycursor.execute(check_query, (self.user_id, self.email))
            self.result = self.mycursor.fetchone()
            if not self.result:
                QMessageBox.warning(None, "Invalid User", "User ID and Email do not match our records.")
                return
            elif self.result[0] == "student" or self.result[0] == "staff":
                QMessageBox.warning(None, "Invalid User", "User must be an instructor or staff to recieve attachment.")
                return
            else:
                if file_type == "pdf":
                    self.export_and_email_sections_to_pdf(self.user_id, self.email)
                else:
                    self.export_and_email_sections_to_excel(self.user_id, self.email)

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
            return

    def load_section_data(self):
        try:
            self.mycursor.execute("SELECT course, year, section FROM section")
            self.result_sections = self.mycursor.fetchall()
            return self.result_sections
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def load_sections_into_list(self):
        """Load stored sections into all list widgets"""
        self.sections = self.load_section_data()
        if not self.sections:
            self.ui.section_list.addItem("No sections available")

        # Clear existing items first
        self.ui.section_list.clear()

        for course, year, section in self.sections:
            display_text = f"{course} - {year}{section}"

            # Add to all relevant list widgets
            self.ui.section_list.addItem(display_text)

    def fill_chosen_section_download(self):
        selected_section = self.ui.section_list.currentItem()
        if not selected_section:
            QMessageBox.warning(None, "No Section Selected", "Please select a section first.")
            return
        self.selected_section =  selected_section.text()
        self.ui.chosen_section_download.setText(self.selected_section)  

    def fill_chosen_section_export(self):
        selected_section = self.ui.section_list.currentItem()
        if not selected_section:
            QMessageBox.warning(None, "No Section Selected", "Please select a section first.")
            return
        self.selected_section =  selected_section.text()
        self.ui.chosen_section_line.setText(self.selected_section) 

    def errorDisplay(self, errno, sqlstate, msg):
        """Displays detailed error information to the user."""
        # Construct the error message
        error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

        # Create and show a critical error message box with the detailed error
        QMessageBox.critical(None, "Database Error", error_message)

    def export_and_email_sections_to_pdf(self, user_id, email):
        try:
            section_name = self.ui.section_list.currentItem().text()
            section_id = self.get_selected_section_id() 
            recipient_email = email
            if not section_id:
                QMessageBox.warning(None, "No Section", "Please select a valid section.")
                return

            students = self.get_students_by_section(section_id)
            if not students:
                QMessageBox.information(None, "No Students", f"No students found for section: {section_name}")
                return

            # Create a properly named temporary file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"Students_{section_name}_{timestamp}.pdf"
            temp_dir = tempfile.gettempdir()
            file_path = os.path.join(temp_dir, filename)
            
            print(f"Creating PDF at: {file_path}")

            doc = SimpleDocTemplate(file_path, pagesize=letter)
            elements = []
            styles = getSampleStyleSheet()

            # Title
            title = Paragraph(f"<b>Section:</b> {section_name}", styles['Title'])
            elements.append(title)
            elements.append(Spacer(1, 12))

            # Table data: header + student rows
            data = [["Student Name", "Student ID"]]
            for full_name, student_id in students:
                # formatted_id = f"TUPC-{str(student_id)[:2]}-{str(student_id)[2:].zfill(4)}"
                data.append([full_name, student_id])

            # Create table
            table = Table(data, colWidths=[250, 150])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 11),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ]))

            elements.append(table)
            doc.build(elements)
            
            # Verify the file was created
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"PDF file was not created at {file_path}")

            try:        
                # Create the progress dialog
                self.dialog = EmailSendingDialog(self)
                self.dialog.setModal(True)
                self.dialog.show()

                self.thread_worker = QThread()
                self.worker = EmailWorker(file_path, recipient_email, 
                                        subject=f"Student List - {section_name}",
                                        body=f"Please find attached the student list for section {section_name}.")

                self.worker.moveToThread(self.thread_worker)
                self.thread_worker.started.connect(self.worker.run)
                self.worker.finished.connect(self.thread_worker.quit)
                self.worker.finished.connect(self.worker.deleteLater)
                self.thread_worker.finished.connect(self.thread_worker.deleteLater)

                # Connect signals to properly defined handler methods
                self.worker.success.connect(self.handle_email_success)
                self.worker.error.connect(self.handle_email_error)
                
                # Start the thread
                self.email_sending_in_progress = True
                self.thread_worker.start()
                
                self.ui.send_btn_PDF.setDisabled(True)
                self.ui.send_btn_Excel.setDisabled(True)

            except Exception as err:
                QMessageBox.critical(None, "Unexpected Error", f"Error cause:{err}")

        except Exception as e:
            print(f"ERROR in export_to_pdf: {str(e)}")
            QMessageBox.critical(None, "Save Error", f"Could not save or send PDF: {str(e)}")
            self.ui.send_btn_PDF.setEnabled(True)
            self.ui.send_btn_Excel.setEnabled(True)
            return

    def export_and_email_sections_to_excel(self, user_id, email):
        try:
            section_name = self.ui.section_list.currentItem().text()
            recipient_email = email

            section_id = self.get_selected_section_id()
            if not section_id:
                QMessageBox.warning(None, "No Section", "Please select a valid section.")
                return

            # Get student data
            students = self.get_students_by_section(section_id)
            if not students:
                QMessageBox.information(None, "No Students", f"No students found for section: {section_name}")
                return

            # Create workbook
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = section_name

            # Header row
            ws.append([section_name])
            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
            ws["A1"].font = Font(bold=True, size=14)

            # Column headers
            ws.append(["Student Name", "Student ID"])
            ws["A2"].font = Font(bold=True)
            ws["B2"].font = Font(bold=True)

            # Student data
            for full_name, student_id in students:
                # Format student_id like TUPC-XX-XXXX
                # formatted_id = f"TUPC-{str(student_id)[:2]}-{str(student_id)[2:].zfill(4)}"
                ws.append([full_name, student_id])

            # Create a properly named temporary file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"Students_{section_name}_{timestamp}.xlsx"
            temp_dir = tempfile.gettempdir()
            file_path = os.path.join(temp_dir, filename)
            
            print(f"Creating Excel file at: {file_path}")

            try:
                wb.save(file_path)
                print(f"Excel file saved successfully: {file_path}, Size: {os.path.getsize(file_path)} bytes")
            except Exception as save_error:
                print(f"Error saving Excel file: {save_error}")
                QMessageBox.critical(None, "Save Error", f"Could not save Excel file: {save_error}")
                return

            # Verify the file was created
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Excel file was not created at {file_path}")

            try:
                # Create the progress dialog
                self.dialog = EmailSendingDialog(self)
                self.dialog.setModal(True)
                self.dialog.show()
                
                self.thread_worker = QThread()
                self.worker = EmailWorker(file_path, recipient_email, 
                                        subject=f"Student List Excel - {section_name}",
                                        body=f"Please find attached the Excel student list for section {section_name}.")

                self.worker.moveToThread(self.thread_worker)
                self.thread_worker.started.connect(self.worker.run)
                self.worker.finished.connect(self.thread_worker.quit)
                self.worker.finished.connect(self.worker.deleteLater)
                self.thread_worker.finished.connect(self.thread_worker.deleteLater)

                # Connect signals to properly defined handler methods
                self.worker.success.connect(self.handle_email_success)
                self.worker.error.connect(self.handle_email_error)
                
                # Start the thread
                self.email_sending_in_progress = True
                self.thread_worker.start()
                
                self.ui.send_btn_PDF.setDisabled(True)
                self.ui.send_btn_Excel.setDisabled(True)

            except Exception as err:
                QMessageBox.critical(None, "Unexpected Error", f"Error Cause: {err}")

        except Exception as e:
            print(f"ERROR in export_to_excel: {str(e)}")
            QMessageBox.critical(None, "Save Error", f"Could not save or send Excel file: {str(e)}")
            self.ui.send_btn_Excel.setEnabled(True)
            self.ui.send_btn_PDF.setEnabled(True)
            return

    def download_excel(self):
        try:
            # Prompt save location
            section_name = self.ui.section_list.currentItem().text()
            if not section_name:
                QMessageBox.warning(None, "Warning", "Please select a section to download the Excel file for.")
                return

            file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", f"{section_name}.xlsx", "Excel Files (*.xlsx)")
            if not file_path:
                return
            
            section_id = self.get_selected_section_id()
            if not section_id:
                QMessageBox.warning(None, "No Section", "Please select a valid section.")
                return

            # Get student data
            students = self.get_students_by_section(section_id)
            if not students:
                QMessageBox.information(None, "No Students", f"No students found for section: {section_name}")
                return

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = section_name

            # Header row
            ws.append([section_name])
            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
            ws["A1"].font = Font(bold=True, size=14)

            # Column headers
            ws.append(["Student Name", "Student ID"])
            ws["A2"].font = Font(bold=True)
            ws["B2"].font = Font(bold=True)

            # Student data
            for full_name, student_id in students:
                # # Format student_id like TUPC-XX-XXXX
                # formatted_id = f"TUPC-{str(student_id)[:2]}-{str(student_id)[2:].zfill(4)}"
                ws.append([full_name, student_id])

            try:
                wb.save(file_path)
                QMessageBox.information(None, "Success", "Excel file saved successfully.")
            except Exception as e:
                QMessageBox.critical(None, "Save Error", f"Could not save file: {e}")

        except Exception as e:
            QMessageBox.critical(None, "Save Error", f"Could not save file: {e}")

    def download_pdf(self):
        try:
            section_name = self.ui.section_list.currentItem().text()
            if not section_name:
                QMessageBox.warning(None, "No Section", "Please select a valid section.")
                return

            file_path, _ = QFileDialog.getSaveFileName(None, "Save PDF File", f"{section_name}.pdf", "PDF Files (*.pdf)")
            if not file_path:
                return

            section_id = self.get_selected_section_id()
            if not section_id:
                QMessageBox.warning(None, "No Section", "Please select a valid section.")
                return

            students = self.get_students_by_section(section_id)
            if not students:
                QMessageBox.information(None, "No Students", f"No students found for section: {section_name}")
                return

            doc = SimpleDocTemplate(file_path, pagesize=letter)
            elements = []
            styles = getSampleStyleSheet()

            # Title
            title = Paragraph(f"<b>Section:</b> {section_name}", styles['Title'])
            elements.append(title)
            elements.append(Spacer(1, 12))

            # Table data: header + student rows
            data = [["Student Name", "Student ID"]]
            for full_name, student_id in students:
                # formatted_id = f"TUPC-{str(student_id)[:2]}-{str(student_id)[2:].zfill(4)}"
                data.append([full_name, student_id])

            # Create table
            table = Table(data, colWidths=[250, 150])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 11),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ]))

            elements.append(table)
            doc.build(elements)

            QMessageBox.information(None, "Success", "PDF file saved successfully.")

        except Exception as e:
            QMessageBox.critical(None, "Save Error", f"Could not save PDF: {e}")

    def handle_email_success(self, message):
        self.dialog.close()
        self.email_sending_in_progress = False
        QMessageBox.information(None, "Email Success", message)
        self.ui.chosen_section_line.clear()
        self.ui.user_id_line.clear()
        self.ui.email_to_send_line.clear()
        self.ui.send_btn_PDF.setEnabled(True)
        self.ui.send_btn_Excel.setEnabled(True)
        return

    def handle_email_error(self, error):
        self.dialog.close()
        self.email_sending_in_progress = False
        QMessageBox.critical(None, "Email Error", error)
        self.ui.chosen_section_line.clear()
        self.ui.user_id_line.clear()
        self.ui.email_to_send_line.clear()
        self.ui.send_btn_PDF.setEnabled(True)
        self.ui.send_btn_Excel.setEnabled(True)
        return

    def closeEvent(self, event):
        try:
            if getattr(self, 'email_sending_in_progress', False):
                QMessageBox.warning(None, "Please wait", "Email is still being sent.")
                event.ignore()
            else:
                event.accept()
        except Exception as err:
            QMessageBox.critical(None, "Unexpected error", f"Error cause: {err}")

class Export_schedule(QDialog):
    def __init__(self, db_connection, db_cursor, parent=None):
        super().__init__(parent)  
        self.ui = RoomExportUi()
        self.ui.setupUi(self)
        self.mydb = db_connection
        self.mycursor = db_cursor
        self.load_rooms_into_list()

        self.ui.choose_btn_download.clicked.connect(self.fill_chose_rm_dl)

        self.ui.download_btn.clicked.connect(self.export_selected_schedules_to_pdf)
        # self.ui.send_btn.clicked.connect(self.verify_user)

    def load_rooms_into_list(self):
        try:
            self.ui.room_list.clear()
            self.mycursor.execute("SELECT room FROM tupc_rooms")
            for (room_name,) in self.mycursor.fetchall():
                item = QListWidgetItem(room_name)
                item.setTextAlignment(Qt.AlignCenter)
                font = QFont()
                font.setPointSize(12)
                item.setFont(font)

                item.setData(Qt.UserRole, room_name)  # Store original name
                self.ui.room_list.addItem(item)
        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)

    def errorDisplay(self, errno, sqlstate, msg):
            """Displays detailed error information to the user."""
            # Construct the error message
            error_message = f"Error Code: {errno}\nSQLSTATE: {sqlstate}\nMessage: {msg}"

            # Create and show a critical error message box with the detailed error
            QMessageBox.critical(None, "Database Error", error_message)

    def fill_chose_rm_dl(self):
        selected_room = self.ui.room_list.currentItem()
        if not selected_room:
            QMessageBox.warning(None, "No Room Selected", "Please select a room first.")
            return
        self.selected_room =  selected_room.text()
        self.ui.chosen_room_download.setText(self.selected_room)  

    # def verify_user(self):
    #     # Just checking if user is existing and email is correct
    #     try:
    #         self.user_id = self.ui.user_id_line.text()
    #         self.email = self.ui.email_to_send_line.text()

    #         if not self.user_id:
    #             QMessageBox.warning(None, "Missing Information", "Please fill in all required fields.")

    #         if not self.email:
    #             QMessageBox.warning(None, "Missing Information", "Please fill in all required fields.")

    #         check_query = """
    #             SELECT user_type, real_ID, email
    #             FROM user_accounts
    #             WHERE real_ID = %s AND email = %s
    #             """
    #         self.mycursor.execute(check_query, (self.user_id, self.email))
    #         self.result = self.mycursor.fetchone()
    #         if not self.result:
    #             QMessageBox.warning(None, "Invalid User", "User ID and Email do not match our records.")
    #             return
    #         elif self.result[0] == "student":
    #             QMessageBox.warning(None, "Invalid User", "User must be an instructor or staff to recieve attachment.")
    #             return
    #         else:
    #             self.export_and_email_schedules_to_pdf(self.user_id, self.email)
    #     except mysql.connector.Error as err:
    #         self.errorDisplay(err.errno, err.sqlstate, err.msg)
    
    # def export_and_email_schedules_to_pdf(None, user_ID, user_Email):
    #     try:
    #         data = self.get_selected_room_schedules()
    #         room_name = self.ui.chosen_room_line.text().strip()
    #         if not data:
    #             QMessageBox.warning(None, "No Data", "No schedule found for the selected room.")
    #             return

    #         self.export_thread = QThread()
    #         self.export_worker = RoomExportThread(room_name, user_Email, data)
    #         self.export_worker.moveToThread(self.export_thread)

    #         self.export_thread.started.connect(self.export_worker.run)
    #         self.export_worker.finished.connect(self.export_thread.quit)
    #         self.export_worker.finished.connect(self.export_worker.deleteLater)
    #         self.export_thread.finished.connect(self.export_thread.deleteLater)
    #         self.export_worker.error.connect(self.handle_email_error)
    #         self.export_worker.finished.connect(self.handle_email_success)
    #         self.export_thread.start()
    #         self.ui.send_btn.setDisabled(True)

    #     except Exception as e:
    #         QMessageBox.critical(None, "Email Failed", f"Could not send email: {str(e)}")
    #         self.ui.send_btn.setDisabled(False)

    def handle_email_error(self, message):
        QMessageBox.critical(None, "Email Failed", message)

    def handle_email_success(self, message):
        QMessageBox.information(None, "Success", message)
        self.ui.chosen_room_line.clear()
        self.ui.user_id_line.clear()
        self.ui.email_to_send_line.clear()
        QTimer.singleShot(3000, lambda: self.ui.send_btn.setDisabled(False))

    def get_selected_room_schedules(self):
        """
        Retrieves schedule data for all selected rooms.
        Returns a list of tuples: (Room, Subject, Day, Start, End, Full Name, User Type)
        """
        try:
            selected_items = self.ui.room_list.selectedItems()
            if not selected_items:
                QMessageBox.warning(None, "No Selection", "Please select one room.")
                return []

            if len(selected_items) > 1:
                QMessageBox.warning(None, "Too Many Selections", "Please select only one room.")
                return []

            selected_room = selected_items[0].text()
            query = """
                SELECT r.room, rs.subject_code_purpose, rs.selected_day, 
                    rs.start_schedule, rs.end_schedule,
                    CONCAT(ua.First_Name, ' ', ua.Last_Name) AS full_name,
                    ua.user_type
                FROM room_schedule rs
                JOIN user_accounts ua ON rs.user_room_ID = ua.real_ID
                JOIN tupc_rooms r ON rs.selected_room_ID = r.idroom_names
                WHERE r.room = %s AND (ua.user_type = 'instructor' OR ua.user_type = 'staff')
                ORDER BY r.room, rs.selected_day, rs.start_schedule
            """

            self.mycursor.execute(query, (selected_room,))
            results = self.mycursor.fetchall()

            return results  # This can be passed to an Excel writer

        except mysql.connector.Error as err:
            self.errorDisplay(err.errno, err.sqlstate, err.msg)
            return []
        
    def export_selected_schedules_to_pdf(self):
        # Get data and room name
        data = self.get_selected_room_schedules()
        room_name = self.ui.chosen_room_download.text().strip()

        """Export selected room schedules to PDF in a timetable layout."""
        # Ask user to select a filename
        filename, _ = QFileDialog.getSaveFileName(
            self, "Save PDF", "exported_schedules.pdf", "PDF Files (*.pdf)"
        )

        if not filename:  # If no filename is selected (cancelled or invalid)
            return

        # Ensure filename ends with .pdf
        if not filename.lower().endswith('.pdf'):
            filename += ".pdf"
        
        if not data:
            QMessageBox.warning(None, "No Data", "No schedule found for the selected room.")
            return
                
        print(f"Retrieved {len(data)} records for room {room_name}")

        try:
            # Define common variables
            time_slots = [f"{hour:02d}:00" for hour in range(7, 21)]
            schedule_by_day = {}
            days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
            
            # Process each row from the database - using the simplified approach from the email thread
            for row in data:
                # Unpack values from the database row
                _, subject, day, start, end, full_name, user_type = row
                
                # Ensure day exists in our data structure
                if day not in schedule_by_day:
                    schedule_by_day[day] = {}
                
                # Simplified time parsing approach (same as in email thread)
                try:
                    start_hour = start.hour if hasattr(start, 'hour') else int(str(start).split(':')[0])
                    end_hour = end.hour if hasattr(end, 'hour') else int(str(end).split(':')[0])
                    
                    # Ensure end_hour is not less than start_hour
                    if end_hour <= start_hour:
                        end_hour = start_hour + 1
                        
                    # For each hour this schedule spans
                    for hour in range(start_hour, end_hour):
                        hour_key = f"{hour:02d}:00"
                        if hour_key in time_slots:
                            if hour_key not in schedule_by_day[day]:
                                schedule_by_day[day][hour_key] = []
                            # Add this schedule to the appropriate time slot
                            schedule_by_day[day][hour_key].append(f"{subject}\n{full_name}")
                except Exception as e:
                    print(f"Error processing time for {subject} on {day}: {e}")
                    # Continue with next record
                    continue
            
            # Create PDF document - same as both methods
            doc = SimpleDocTemplate(filename, pagesize=landscape(letter))
            styles = getSampleStyleSheet()
            elements = []
            
            # Add title
            elements.append(Paragraph(f"{room_name} Schedule", styles['Title']))
            elements.append(Spacer(1, 20))  # 20 points spacing
            
            # Create timetable data
            table_data = [["Time"] + days]  # Header row
            
            # Add a row for each time slot
            for time_slot in time_slots:
                row = [time_slot]  # First column is the time
                
                # Add cell for each day
                for day in days:
                    cell_content = ""
                    if day in schedule_by_day and time_slot in schedule_by_day[day]:
                        cell_content = "\n".join(schedule_by_day[day][time_slot])
                    row.append(cell_content)
                
                table_data.append(row)
            
            # Calculate column widths - first column for time is narrower
            col_width = doc.width / (len(days) + 1)
            col_widths = [col_width * 0.5] + [col_width] * len(days)
            
            # Create table with the specified column widths
            table = Table(table_data, repeatRows=1, colWidths=col_widths)
            
            # Style the table - using the exact same style as the email method
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (0, -1), colors.lightgrey),
                ('ALIGN', (0, 1), (0, -1), 'CENTER'),
                ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
                ('BACKGROUND', (1, 1), (-1, -1), colors.white),
                ('VALIGN', (1, 1), (-1, -1), 'TOP'),
                ('ALIGN', (1, 1), (-1, -1), 'LEFT'),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('WORDWRAP', (1, 1), (-1, -1), True),
            ]))
            
            # Add the table to the PDF elements
            elements.append(table)
            
            # Add a footer with date
            elements.append(Spacer(1, 20))
            current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            elements.append(Paragraph(f"Generated on: {current_date}", styles['Normal']))
            
            # Build the PDF
            doc.build(elements)
            QMessageBox.information(None, "Success", f"PDF saved as {filename}")

            # Clear the room input field
            self.ui.chosen_room_download.clear()
            
        except Exception as e:
            print(f"Error creating PDF: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(None, "Error", f"Failed to save PDF: {e}")
            return


class EmailWorker(QObject):
    finished = Signal()
    error = Signal(str)
    success = Signal(str)

    def __init__(self, file_path, recipient_email, subject="Student List", body="Please find the attached file."):
        super().__init__()
        self.file_path = file_path
        self.recipient_email = recipient_email
        self.subject = subject
        self.body = body
        print(f"EmailWorker initialized with file: {file_path}")
        
        # Verify the file exists right from initialization
        if not os.path.exists(self.file_path):
            print(f"WARNING: File {self.file_path} does not exist at initialization")

    def run(self):
        print("EmailWorker.run() started")
        try:
            # Double-check that the file exists
            if not os.path.exists(self.file_path):
                raise FileNotFoundError(f"File {self.file_path} does not exist")
                
            print(f"File size: {os.path.getsize(self.file_path)} bytes")
            
            msg = EmailMessage()
            msg['Subject'] = self.subject
            msg['From'] = "tupcroomutilization@gmail.com"
            msg['To'] = self.recipient_email
            msg.set_content(self.body)

            # Attach file with proper content type detection
            file_name = os.path.basename(self.file_path)
            
            # Determine content type based on file extension
            if file_name.endswith('.pdf'):
                maintype, subtype = "application", "pdf"
            elif file_name.endswith('.xlsx'):
                maintype, subtype = "application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            else:
                maintype, subtype = "application", "octet-stream"
            
            print(f"Reading file: {self.file_path}")
            with open(self.file_path, 'rb') as f:
                file_data = f.read()
                print(f"Read {len(file_data)} bytes from file")
                
                msg.add_attachment(file_data, 
                                  maintype=maintype, 
                                  subtype=subtype, 
                                  filename=file_name)
            
            print("Email prepared, connecting to SMTP server...")
            
            # Try both SSL and STARTTLS methods
            try:
                # First try SSL on port 465
                with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
                    print("Connected via SSL")
                    smtp.login("tupcroomutilization@gmail.com", "mqfb surj molj joko")
                    print("Login successful")
                    smtp.send_message(msg)
                    print("Message sent successfully via SSL")
            except Exception as ssl_error:
                print(f"SSL connection failed: {ssl_error}")
                # If SSL fails, try STARTTLS on port 587
                with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
                    print("Connected via STARTTLS")
                    smtp.ehlo()
                    smtp.starttls()
                    smtp.ehlo()
                    smtp.login("tupcroomutilization@gmail.com", "mqfb surj molj joko")
                    print("Login successful")
                    smtp.send_message(msg)
                    print("Message sent successfully via STARTTLS")

            # Clean up temp file after successful sending
            try:
                if os.path.exists(self.file_path):
                    os.remove(self.file_path)
                    print(f"Temporary file removed: {self.file_path}")
            except Exception as cleanup_error:
                print(f"Warning: Could not remove temp file: {cleanup_error}")
            
            print("Emitting success signal")
            self.success.emit("Email sent successfully.")

        except Exception as e:
            print(f"ERROR in EmailWorker: {str(e)}")
            self.error.emit(f"Email error: {str(e)}")
        finally:
            print("Emitting finished signal")
            self.finished.emit()


class TUPC_ID:
    def __init__(self, raw_id):
        self.raw_id = str(raw_id).zfill(6)

    def get_id(self):
        raise NotImplementedError


class StudentID(TUPC_ID):
    def get_id(self):
        return f"TUPC-{self.raw_id[:2]}-{self.raw_id[2:]}"
    

class InstructorID(TUPC_ID):
    def get_id(self):
        return f"TUPC-1{self.raw_id[-3:]}"


class StaffID(TUPC_ID):
    def get_id(self):
        return f"TUPC-2{self.raw_id[-3:]}"


class EmailSendingDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sending Email...")
        self.setFixedSize(300, 100)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Sending email... Please wait."))
        progress = QProgressBar()
        progress.setRange(0, 0)  # Indeterminate
        layout.addWidget(progress)


class RoomAttendance(QDialog):
    def __init__(self, db_connection, cursor, room_id, selected_day, start_time, end_time):
        super().__init__()
        self.ui = AttendanceUi()
        self.ui.setupUi(self)

        self.db = db_connection
        self.cursor = cursor
        self.room_id = room_id
        self.day = selected_day
        self.start_time = start_time
        self.end_time = end_time

        # Setup attendance table
        self.ui.list_attendance.setColumnCount(3)
        self.ui.list_attendance.setHorizontalHeaderLabels(['ID', 'Last Name', 'First Name'])
        self.ui.list_attendance.setRowCount(0)  # Clear any existing rows

        self.load_registered_students()
        self.set_room_name()

        # Setup QR scan field
        self.filter = KeyFilter()  # Assuming this is defined elsewhere
        self.ui.users_scanned.installEventFilter(self.filter)
        self.ui.users_scanned.setFocus()
        self.ui.users_scanned.setReadOnly(True)
        self.ui.users_scanned.returnPressed.connect(self.on_qr_scanned)

        self.update_attendance_visualization()

    def update_attendance_visualization(self):
        # Get total students and scanned students
        total_students = self.get_total_registered_students()
        scanned_students = self.get_scanned_students_count()

        # Validate that these values are valid numbers
        if total_students is None or scanned_students is None:
            print("Error: Invalid data for total students or scanned students.")
            return

        # Calculate unscanned students
        unscanned_students = total_students - scanned_students

        # Handle case where data might be invalid or zero
        if total_students == 0:  # No students registered
            print("No students registered.")
            return

        # Prepare data for the pie chart
        data = [scanned_students, unscanned_students]
        labels = ['Scanned', 'Not Scanned']

        # Check for NaN values and prevent passing them to the pie chart
        if any(map(lambda x: x != x, data)):  # Check for NaN
            print("Error: NaN value detected in the data.")
            return

        # Create Pie chart
        fig, ax = plt.subplots(figsize=(3, 3), dpi=100)

        def format_int(pct, all_vals):
            total = sum(all_vals)
            count = int(round(pct / 100. * total))
            return f'{count}'

        colors = ['#4CAF50', '#F44336']  # Green for scanned, red for not scanned
        ax.pie(data, labels=labels, colors=colors, autopct=lambda pct: format_int(pct, data), startangle=90)
        ax.axis('equal')  # Equal aspect ratio ensures that pie chart is circular.

        # Create a canvas and add the chart to the existing QFrame
        canvas = FigureCanvas(fig)
        layout = self.ui.frame.layout()

        # If no layout exists, create a new one
        if not layout:
            layout = QVBoxLayout(self.ui.frame)
            self.ui.frame.setLayout(layout)
        
        # Clear any previous widget in the frame
        for i in reversed(range(layout.count())):
            widget = layout.itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()

        # Add the canvas (pie chart) to the frame
        layout.addWidget(canvas)
        self.ui.users_scanned.setFocus()

    def get_total_registered_students(self):
        # First, get the section ID for this room
        self.cursor.execute("""
            SELECT section_ID
            FROM room_schedule
            WHERE room_id = %s
        """, (self.room_id,))
        
        result = self.cursor.fetchone()
        if not result or result[0] is None:
            print("[DEBUG] No section_ID found for this room.")
            return 0

        section_id = result[0]

        # Then, count students from section_junction
        self.cursor.execute("""
            SELECT COUNT(*)
            FROM section_junction sj
            JOIN user_accounts ua ON sj.student_ID = ua.real_ID
            WHERE sj.section_ID = %s
        """, (section_id,))

        result = self.cursor.fetchone()
        return result[0] if result else 0
        
    def get_scanned_students_count(self):
        # Query to get the number of students who have scanned their attendance
        attendance_table = self.ui.list_attendance
        return attendance_table.rowCount()
    
    def verify_qr_code(self, scan_data):
        parts = scan_data.strip().split()

        if len(parts) < 3:
            return None, "Invalid QR format."

        real_ID, last_name, first_name = parts[:3]

        self.cursor.execute("SELECT * FROM user_accounts WHERE real_ID = %s", (real_ID,))
        user = self.cursor.fetchone()
        if not user:
            return None, "User not found."

        self.cursor.execute("SELECT section_ID FROM room_schedule WHERE room_id = %s", (self.room_id,))
        result = self.cursor.fetchone()
        if not result or not result[0]:
            return None, "No section assigned to this room."

        section_id = result[0]
        self.cursor.execute("""
            SELECT 1 FROM section_junction
            WHERE section_ID = %s AND student_ID = %s
        """, (section_id, real_ID))
        registered = self.cursor.fetchone()

        if not registered:
            return None, "Student is not registered in this section."

        return (real_ID, last_name, first_name), "OK"
    
    def on_qr_scanned(self):
        self.ui.users_scanned.setEnabled(False)  # Prevent double scan
        QTimer.singleShot(300, self.handle_delayed_scan)
        self.ui.users_scanned.setFocus()

    def handle_delayed_scan(self):
        self.process_scanned_user()
        self.ui.users_scanned.setEnabled(True)
        self.ui.users_scanned.setFocus()

    def process_scanned_user(self):
        scan_data = self.ui.users_scanned.text().strip()
        user_info, status = self.verify_qr_code(scan_data)

        if status != "OK":
            QMessageBox.warning(self, "Scan Error", status)
            self.ui.users_scanned.clear()
            self.ui.users_scanned.setFocus()
            return

        real_ID, last_name, first_name = user_info

        attendance_table = self.ui.list_attendance
        for row in range(attendance_table.rowCount()):
            if attendance_table.item(row, 0) and attendance_table.item(row, 0).text() == real_ID:
                QMessageBox.information(self, "Duplicate", "This student is already marked present.")
                self.ui.users_scanned.clear()
                self.ui.users_scanned.setFocus()
                return

        # Insert at top (row 0)
        attendance_table.insertRow(0)
        attendance_table.setItem(0, 0, QTableWidgetItem(real_ID))
        attendance_table.setItem(0, 1, QTableWidgetItem(last_name))
        attendance_table.setItem(0, 2, QTableWidgetItem(first_name))

        self.ui.users_scanned.clear()
        self.ui.users_scanned.setFocus()
        self.update_attendance_visualization()

    def set_room_name(self):
        self.cursor.execute("""
            SELECT tr.room
            FROM room_schedule rs
            JOIN tupc_rooms tr ON rs.selected_room_ID = tr.idroom_names
            WHERE rs.room_id = %s
        """, (self.room_id,))

        result = self.cursor.fetchone()
        if result:
            room_name = result[0]
            self.ui.accessed_room.setText(room_name)
            self.ui.accessed_room.setReadOnly(True)
            self.ui.accessed_room.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.ui.accessed_room.setText("Unknown Room")
            self.ui.accessed_room.setReadOnly(True)
            self.ui.accessed_room.setStyleSheet("color: red; font-weight: bold;")

    def load_registered_students(self):
        # Step 1: Get section_ID from room_schedule using room_id
        self.cursor.execute("""
            SELECT section_ID
            FROM room_schedule
            WHERE room_id = %s
        """, (self.room_id,))
        
        result = self.cursor.fetchone()
        print(f"[DEBUG] room_id: {self.room_id}")  # Debug print
        print(f"[DEBUG] section_ID result from room_schedule: {result}")  # Debug print

        if not result or result[0] is None:
            print("No section assigned to this schedule.")
            return

        section_id = result[0]
        print(f"[DEBUG] section_id to use: {section_id}")  # Debug print

        # Step 2: Get students from section_junction + user_accounts
        self.cursor.execute("""
            SELECT ua.real_ID, ua.last_name, ua.first_name
            FROM section_junction sj
            JOIN user_accounts ua ON sj.student_ID = ua.real_ID
            WHERE sj.section_ID = %s
        """, (section_id,))

        students = self.cursor.fetchall()
        print(f"[DEBUG] Number of students fetched: {len(students)}")  # Debug print
        for s in students:
            print(f"[DEBUG] Student fetched: {s}")  # Debug print

        # Step 3: Display in table
        table = self.ui.list_registered_stdnt_instructor_sched
        table.setRowCount(0)
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(['ID', 'Last Name', 'First Name'])

        for row_num, (real_ID, last_name, first_name) in enumerate(students):
            table.insertRow(row_num)
            table.setItem(row_num, 0, QTableWidgetItem(str(real_ID)))
            table.setItem(row_num, 1, QTableWidgetItem(last_name))
            table.setItem(row_num, 2, QTableWidgetItem(first_name))





        # self.db_connection = db_connection
        # self.db_cursor = db_cursor
        # db_connection, db_cursor, 

        # self.series = QPieSeries()

        # self.series.append('Jane', 1)
        # self.series.append('Joe', 2)
        # self.series.append('Andy', 3)
        # self.series.append('Barbara', 4)
        # self.series.append('Axel', 5)

        # self.slice = self.series.slices()[1]
        # self.slice.setExploded()
        # self.slice.setLabelVisible()
        # self.slice.setPen(QPen(Qt.darkGreen, 2))
        # self.slice.setBrush(Qt.green)

        # self.chart = QChart()
        # self.chart.addSeries(self.series)
        # self.chart.setTitle('Simple piechart example')
        # self.chart.legend().hide()

        # self._chart_view = QChartView(self.chart)
        # self._chart_view.setRenderHint(QPainter.Antialiasing)

        # self.ui.frame.addWidget

    # def update_attendance_visualization(self):
    #     total_students = self.get_total_registered_students()
    #     scanned_students = self.get_scanned_students_count()

    #     if total_students is None or scanned_students is None or total_students == 0:
    #         print("Invalid or no student data.")
    #         return

    #     unscanned_students = total_students - scanned_students

    #     # --- Create the pie chart series ---
    #     series = QPieSeries()
    #     scanned_slice = series.append("Scanned", scanned_students)
    #     unscanned_slice = series.append("Not Scanned", unscanned_students)

    #     # Customize slice appearance
    #     scanned_slice.setLabelVisible(True)
    #     scanned_slice.setBrush(Qt.green)

    #     unscanned_slice.setLabelVisible(True)
    #     unscanned_slice.setBrush(Qt.red)

    #     # --- Create the chart ---
    #     chart = QChart()
    #     chart.addSeries(series)
    #     chart.setTitle("Attendance Summary")
    #     chart.legend().setAlignment(Qt.AlignBottom)

    #     # --- Create chart view ---
    #     chart_view = QChartView(chart)
    #     chart_view.setRenderHint(QPainter.Antialiasing)
    #     chart_view.setMinimumSize(300, 300)

    #     # --- Create labels with matching colors ---
    #     scanned_label = QLabel(f"✅ Scanned: {scanned_students} / {total_students}")
    #     unscanned_label = QLabel(f"❌ Not Scanned: {unscanned_students}")

    #     scanned_label.setStyleSheet("color: green; font-weight: bold; font-size: 14px;")
    #     unscanned_label.setStyleSheet("color: red; font-weight: bold; font-size: 14px;")

    #     # --- Clear old layout/widgets ---
    #     layout = self.ui.frame.layout()
    #     if not layout:
    #         layout = QVBoxLayout()
    #         self.ui.frame.setLayout(layout)

    #     for i in reversed(range(layout.count())):
    #         widget = layout.itemAt(i).widget()
    #         if widget:
    #             widget.deleteLater()

    #     # --- Add chart and labels ---
    #     layout.addWidget(chart_view)
    #     layout.addWidget(scanned_label)
    #     layout.addWidget(unscanned_label)

    #     self.ui.users_scanned.setFocus()




if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())   